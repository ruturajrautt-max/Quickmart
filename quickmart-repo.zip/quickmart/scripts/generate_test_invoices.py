#!/usr/bin/env python3
"""
Generates synthetic-but-realistic grocery invoices (clean, skewed, noisy "phone photo", sideways, PDF) plus a
ground-truth JSON for each, into src/test/resources/invoices/. Used by the OCR tests.
Requires: pillow, numpy, opencv-python, reportlab.   Run:  python scripts/generate_test_invoices.py
These are renders, NOT photographs of real paper bills.
"""
import json, os, random
from decimal import Decimal, ROUND_HALF_UP
import numpy as np, cv2
from PIL import Image, ImageDraw, ImageFont

OUT = os.path.join(os.path.dirname(__file__), "..", "src", "test", "resources", "invoices")
os.makedirs(OUT, exist_ok=True)
SANS = "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"
SANSB = "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"
MONO = "/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf"
D = Decimal
def q2(x): return D(x).quantize(D("0.01"), rounding=ROUND_HALF_UP)

def gstin_with_checksum(base14):
    cs = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    s = 0
    for i, ch in enumerate(base14):
        p = cs.index(ch) * (1 if i % 2 == 0 else 2)
        s += p // 36 + p % 36
    return base14 + cs[(36 - s % 36) % 36]

GSTIN = gstin_with_checksum("27ABCDE1234F1Z")

# ───────────────────────── invoice A: distributor tax invoice (grid, HSN, discount, GST) ─────────────────────────
ITEMS_A = [  # name, hsn, qty, unit, rate, disc%
    ("Tata Salt 1 kg", "2501", 50, "Pcs", "24.00", 0),
    ("Aashirvaad Whole Wheat Atta 5 kg", "1101", 20, "Pcs", "255.00", 0),
    ("Amul Butter Pasteurised 500 g", "0405", 24, "Pcs", "268.00", 2),
    ("Tata Sampann Toor Dal 1 kg", "0713", 30, "Pcs", "164.50", 0),
    ("Fortune Sunflower Oil 1 L", "1512", 15, "Pcs", "138.00", 0),
    ("Parle-G Gold Biscuits 250 g", "1905", 40, "Pcs", "21.50", 0),
    ("Surf Excel Easy Wash 1 kg", "3402", 12, "Pcs", "118.00", 0),
]

def invoice_a():
    rows, sub = [], D(0)
    for i, (n, h, qty, u, rate, disc) in enumerate(ITEMS_A, 1):
        amt = q2(D(qty) * D(rate) * (D(100) - D(disc)) / D(100))
        sub += amt
        rows.append(dict(sr=i, name=n, hsn=h, qty=qty, unit=u, rate=rate, disc=disc, gst=5, amount=str(amt)))
    cgst = q2(sub * D("0.025")); sgst = cgst
    raw_total = sub + cgst + sgst
    grand = raw_total.quantize(D("1"), rounding=ROUND_HALF_UP)
    rnd = q2(grand - raw_total)
    truth = dict(supplier="SHREE GANESH DISTRIBUTORS", invoiceNumber="SGD/2026/0457", invoiceDate="2026-10-02", gstin=GSTIN,
                 subtotal=str(sub), cgst=str(cgst), sgst=str(sgst), roundOff=str(rnd), grandTotal=str(q2(grand)), lines=rows)
    W, H = 2000, 2000
    img = Image.new("L", (W, H), 255); d = ImageDraw.Draw(img)
    f, fb, fh = ImageFont.truetype(SANS, 30), ImageFont.truetype(SANSB, 30), ImageFont.truetype(SANSB, 52)
    d.text((80, 60), "SHREE GANESH DISTRIBUTORS", font=fh, fill=0)
    d.text((80, 130), "Plot 12, MIDC Industrial Area, Pune 411019", font=f, fill=0)
    d.text((80, 175), "GSTIN: %s    Phone: 9822012345" % GSTIN, font=f, fill=0)
    d.text((80, 240), "TAX INVOICE", font=fb, fill=0)
    d.text((900, 240), "Invoice No: SGD/2026/0457", font=f, fill=0)
    d.text((1450, 240), "Date: 02-10-2026", font=f, fill=0)
    d.text((80, 295), "Bill To: Sai Kirana Stores, Aundh, Pune     Buyer GSTIN: 27AAAPL1234C1ZV", font=f, fill=0)
    cols = [80, 150, 800, 920, 1030, 1130, 1290, 1400, 1520, 1920]   # sr, desc, hsn, qty, unit, rate, disc, gst, amount, end
    heads = ["Sr", "Description", "HSN", "Qty", "Unit", "Rate", "Disc%", "GST%", "Amount"]
    y = 380
    d.rectangle([cols[0], y, cols[-1], y + 50], outline=0, width=2)
    for x, h in zip(cols[:-1], heads): d.text((x + 8, y + 8), h, font=fb, fill=0)
    y += 50
    for r in rows:
        d.rectangle([cols[0], y, cols[-1], y + 56], outline=0, width=1)
        vals = [str(r["sr"]), r["name"], r["hsn"], str(r["qty"]), r["unit"], r["rate"], "%.1f%%" % r["disc"], "%d%%" % r["gst"], r["amount"]]
        for x, v in zip(cols[:-1], vals): d.text((x + 8, y + 10), v, font=f, fill=0)
        y += 56
    y += 40
    for label, val in [("Sub Total", sub), ("CGST 2.5%", cgst), ("SGST 2.5%", sgst), ("Round Off", rnd), ("Grand Total", q2(grand))]:
        d.text((1300, y), label, font=fb if label == "Grand Total" else f, fill=0)
        d.text((1700, y), str(val), font=fb if label == "Grand Total" else f, fill=0); y += 48
    d.text((80, y + 40), "Authorised Signatory", font=f, fill=0)
    return img, truth

# ───────────────────────── invoice B: thermal-style receipt (monospace, qty first columns) ─────────────────────────
ITEMS_B = [("Tata Salt 1kg", 6, "24.00"), ("TATA SALT 500g", 4, "13.00"), ("Amul Taaza Milk 1L", 10, "54.00"),
           ("Maggi 2-Minute Noodles 70g", 24, "14.00"), ("Cashew Nuts 250g", 2, "210.00")]

def invoice_b():
    rows, sub = [], D(0)
    for i, (n, qty, rate) in enumerate(ITEMS_B, 1):
        amt = q2(D(qty) * D(rate)); sub += amt
        rows.append(dict(sr=i, name=n, qty=qty, rate=rate, amount=str(amt)))
    truth = dict(supplier="SUPERSAVE WHOLESALE MART", invoiceNumber="SS-10458", invoiceDate="2026-11-04", gstin=None,
                 subtotal=None, grandTotal=str(q2(sub)), lines=rows)
    f = ImageFont.truetype(MONO, 30)
    img = Image.new("L", (900, 900), 255); d = ImageDraw.Draw(img)
    y = 30
    def ln(t, bold=False):
        nonlocal y
        d.text((30, y), t, font=f, fill=0); y += 42
    ln("SUPERSAVE WHOLESALE MART"); ln("Shop 4, Aundh Road, Pune"); ln("Bill No: SS-10458  Date: 04/11/2026"); ln("-" * 40)
    ln("Item                    Qty  Rate    Amt"); ln("-" * 40)
    for r in rows:
        ln("%-23s %3d %6s %8s" % (r["name"][:23], r["qty"], r["rate"], r["amount"]))
    ln("-" * 40); ln("Total                          %9s" % q2(sub)); ln("Thank you, visit again")
    return img, truth

# ───────────────────────── invoice C: loose goods, quantity + unit (KG) columns, no GST block ─────────────────────────
ITEMS_C = [("Sugar", 25, "KG", "44.00"), ("Basmati Rice India Gate 5 kg", 6, "BAG", "610.00"), ("Rajma Chitra", 10, "KG", "118.00")]

def invoice_c():
    rows, sub = [], D(0)
    for i, (n, qty, u, rate) in enumerate(ITEMS_C, 1):
        amt = q2(D(qty) * D(rate)); sub += amt
        rows.append(dict(sr=i, name=n, qty=qty, unit=u, rate=rate, amount=str(amt)))
    truth = dict(supplier="New Bharat Trading Co", invoiceNumber="NB-2291", invoiceDate="2026-09-18", gstin=None,
                 subtotal=None, grandTotal=str(q2(sub)), lines=rows)
    f, fb = ImageFont.truetype(SANS, 32), ImageFont.truetype(SANSB, 44)
    img = Image.new("L", (1700, 900), 255); d = ImageDraw.Draw(img)
    d.text((60, 40), "New Bharat Trading Co", font=fb, fill=0)
    d.text((60, 110), "Invoice No. NB-2291        Dated: 18-Sep-2026", font=f, fill=0)
    cols = [60, 170, 900, 1050, 1250, 1450]
    d.text((cols[1], 200), "Item", font=fb, fill=0); d.text((cols[2], 200), "Qty", font=fb, fill=0)
    d.text((cols[3], 200), "Unit", font=fb, fill=0); d.text((cols[4], 200), "Rate", font=fb, fill=0); d.text((cols[5], 200), "Amount", font=fb, fill=0)
    y = 270
    for r in rows:
        for x, v in zip(cols, [str(r["sr"]), r["name"], str(r["qty"]), r["unit"], r["rate"], r["amount"]]): d.text((x, y), v, font=f, fill=0)
        y += 60
    y += 30
    d.text((1050, y), "Total", font=fb, fill=0); d.text((1450, y), str(q2(sub)), font=fb, fill=0)
    return img, truth

# ───────────────────────── degradations ─────────────────────────
def skew(img, deg):
    a = np.array(img); h, w = a.shape
    M = cv2.getRotationMatrix2D((w / 2, h / 2), deg, 1.0)
    return Image.fromarray(cv2.warpAffine(a, M, (w, h), flags=cv2.INTER_CUBIC, borderValue=255))

def phone_photo(img, seed=1):
    """Grey paper on a darker table, uneven lighting gradient, sensor noise, slight blur, downscale, JPEG."""
    rnd = np.random.RandomState(seed)
    a = np.array(img).astype(np.float32)
    h, w = a.shape
    a = cv2.GaussianBlur(a, (0, 0), 1.1)
    yy, xx = np.mgrid[0:h, 0:w].astype(np.float32)
    light = 0.62 + 0.38 * (xx / w * 0.6 + (1 - yy / h) * 0.4)            # darker towards one corner
    a = a * light + 12
    a += rnd.normal(0, 9, a.shape)
    a = np.clip(a, 0, 255).astype(np.uint8)
    s = 1400.0 / w
    a = cv2.resize(a, (int(w * s), int(h * s)), interpolation=cv2.INTER_AREA)
    return Image.fromarray(a)

def save(name, img, truth, fmt="PNG", quality=None, **kw):
    path = os.path.join(OUT, name)
    img.convert("RGB" if fmt == "JPEG" else "L").save(path, fmt, **({"quality": quality} if quality else {}), **kw)
    return path

def pdf_from(img, name):
    from reportlab.pdfgen import canvas
    from reportlab.lib.utils import ImageReader
    path = os.path.join(OUT, name); w, h = img.size
    c = canvas.Canvas(path, pagesize=(w * 0.36, h * 0.36)); c.drawImage(ImageReader(img.convert("RGB")), 0, 0, w * 0.36, h * 0.36); c.save()

if __name__ == "__main__":
    a, ta = invoice_a(); b, tb = invoice_b(); c, tc = invoice_c()
    save("a_distributor_clean.png", a, ta); json.dump(ta, open(os.path.join(OUT, "a_distributor.json"), "w"), indent=1)
    save("a_distributor_skew3.png", skew(a, 3.0), ta)
    save("a_distributor_photo.jpg", phone_photo(skew(a, -2.0)), ta, "JPEG", 55)
    img90 = a.rotate(-90, expand=True, fillcolor=255)                                  # photo taken sideways
    save("a_distributor_sideways.png", img90, ta)
    pdf_from(a, "a_distributor.pdf")
    save("b_receipt_clean.png", b, tb); json.dump(tb, open(os.path.join(OUT, "b_receipt.json"), "w"), indent=1)
    save("b_receipt_photo.jpg", phone_photo(skew(b, 2.0), 7), tb, "JPEG", 60)
    save("c_loose_goods.png", c, tc); json.dump(tc, open(os.path.join(OUT, "c_loose.json"), "w"), indent=1)
    # not-an-invoice inputs for the invalid-upload tests
    open(os.path.join(OUT, "not_an_image.png"), "wb").write(b"this is plain text pretending to be a png\n")
    Image.new("L", (60, 40), 255).save(os.path.join(OUT, "tiny.png"))
    Image.new("L", (1200, 1600), 255).save(os.path.join(OUT, "blank.png"))
    print("GSTIN used:", GSTIN, "| written to", os.path.abspath(OUT))
