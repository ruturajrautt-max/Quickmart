package com.quickmart.ocr;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

/** Fixtures 1-2 are real Tesseract output from test bills; the rest are the layouts / OCR slips that broke the old regex. */
class BillTextParserTest {

    private static BillTextParser.Line find(BillTextParser.Result r, String part) {
        return r.items.stream().filter(l -> l.name.toLowerCase().contains(part.toLowerCase())).findFirst()
                .orElseThrow(() -> new AssertionError("no row containing '" + part + "' in " + r.items.stream().map(l -> l.name).toList()));
    }

    @Test
    void distributorInvoiceWithHsnAndUnitColumns() {
        String text = """
                SHREE GANESH DISTRIBUTORS
                Tax Invoice Invoice No: GD/2026/0457 Date: 02-10-2026
                GSTIN: 27ABCDE1234F1Z5
                SI Description                                          HSN        Qty      Unit Rate          Amount
                1     Amul Butter Salted 500 g                            0405        24        Pcs      268.00        6432.00
                2     Tata Sampann Unpolished Toor Dal 1 kg            0713       50       Pcs      104.50       5225.00
                3     Aashirvaad Shudh Chakki Wheat Atta 5 kg          1101       20       Pcs      255.00       5100.00
                6     Cashew Nuts Premium W320 250 g                 0801       12       BOX     210.00       2520.00
                7    Amul Taaza Fresh Milk 1 L                        0401       100     Pcs     54.00        5400.00
                Sub Total                             31882.00
                CGST 2.5%                       797.05
                Grand Total                     33476.10
                """;
        BillTextParser.Result r = BillTextParser.parse(text);
        assertEquals(5, r.items.size());
        assertEquals(24, find(r, "butter").qty);          // not the HSN 0405
        assertEquals(100, find(r, "milk").qty);           // 54 x 100 = 5400: qty is the 100, even though 54 comes first
        assertEquals(12, find(r, "cashew").qty);          // old regex dropped any line containing "cash"
        assertTrue(r.items.stream().allMatch(l -> l.verified));
        assertEquals("Amul Butter Salted 500 g", find(r, "butter").name);   // serial number stripped, size kept
    }

    @Test
    void strayOcrCharactersBeforeAmounts() {
        String text = """
                Item                      Qty Rate Amt
                TATA TOOR DAL 1KG          2 112.00 ?224.00
                CASHEW NUTS 250G           1 185.00 #?185.00
                Total                          Rs 1042.00
                """;
        BillTextParser.Result r = BillTextParser.parse(text);
        assertEquals(2, r.items.size());
        assertEquals(2, find(r, "toor").qty);
        assertTrue(find(r, "cashew").verified);
    }

    @Test
    void rateColumnBeforeQtyColumn() {
        String text = """
                Item                 Rate     Qty    Amount
                Toor Dal 1 kg       104.50    50     5225.00
                """;
        assertEquals(50, find(BillTextParser.parse(text), "toor").qty);
    }

    @Test
    void decimalAndThousandsCommas() {
        BillTextParser.Result r = BillTextParser.parse("Sugar 1kg 3 45,00 135,00\nBasmati Rice 5 kg 10 590.00 5,900.00\n");
        assertEquals(3, find(r, "sugar").qty);
        assertEquals(10, find(r, "basmati").qty);
        assertTrue(find(r, "basmati").verified);
    }

    @Test
    void quantityTimesRateWritten2x120() {
        assertEquals(2, find(BillTextParser.parse("Toor Dal 1kg 2 x 112.00 224.00"), "toor").qty);
    }

    @Test
    void ocrConfusedLettersInsideNumbers() {
        // "1O0.00" / "l20.00": letter O and l read instead of digits
        BillTextParser.Line l = find(BillTextParser.parse("Sugar 1kg 2 1O0.00 200.00"), "sugar");
        assertEquals(2, l.qty);
        assertTrue(l.verified);
    }

    @Test
    void discountColumnIsNowVerifiedWhenTheArithmeticWorksOut() {
        // 10 x 40.00 = 400.00, minus 5% = 380.00: the discount explains the amount exactly (this used to be left unverified)
        BillTextParser.Line l = find(BillTextParser.parse("Dettol Soap 75 g 0401 10 40.00 5% 380.00"), "dettol");
        assertEquals(10, l.qty);
        assertTrue(l.verified);
        assertEquals("DISCOUNT", l.check);
        assertEquals(0, new java.math.BigDecimal("5").compareTo(l.discountPct));
    }

    @Test
    void discountThatDoesNotExplainTheAmountStaysUnverified() {
        BillTextParser.Line l = find(BillTextParser.parse("Dettol Soap 75 g 0401 10 40.00 5% 390.00"), "dettol");
        assertFalse(l.verified, "390 is neither 400 nor 380: the user must check it");
    }

    @Test
    void unitHsnAndPackSizeAreCaptured() {
        BillTextParser.Line l = find(BillTextParser.parse("Amul Butter 500 g 0405 24 Pcs 268.00 6432.00"), "butter");
        assertEquals("pcs", l.unit);
        assertEquals("0405", l.hsn);
        assertEquals("500 g", l.packSize.label());
        assertEquals(24, l.qty);
    }

    @Test
    void quantityWithAMeasureUnitColumnIsNotMistakenForAPackSize() {
        // "25 KG" here is the quantity (unit column), not a pack size: 25 x 44.00 = 1100.00
        BillTextParser.Line l = find(BillTextParser.parse("Sugar 25 KG 44.00 1100.00"), "sugar");
        assertEquals(25, l.qty);
        assertEquals("kg", l.unit);
        assertTrue(l.verified);
    }

    @Test
    void droppedDecimalPointIsRepairedOnlyWhenArithmeticProvesIt() {
        // OCR read 164.50 as 16450; 30 x 164.50 = 4935.00
        BillTextParser.Line l = find(BillTextParser.parse("Tata Sampann Toor Dal 1 kg 0713 30 Pcs 16450 4935.00"), "toor");
        assertEquals(30, l.qty);
        assertEquals(0, new java.math.BigDecimal("164.50").compareTo(l.rate));
        assertFalse(l.verified, "a repaired value is still flagged for the vendor");
        assertEquals("REPAIRED", l.check);
    }

    @Test
    void percentSignReadAsLetterSIsRecovered() {
        assertEquals(1, BillTextParser.percents("Tata Salt 50 24.00 0.0% S% 1200.00").stream().filter(p -> p.intValue() == 5).count());
    }

    @Test
    void quantityFirstReceiptIsNotMistakenForSerialNumbers() {
        BillTextParser.Result r = BillTextParser.parse("2 Amul Butter 500g 556.00\n3 Britannia White Bread 120.00\n");
        assertEquals(2, find(r, "butter").qty);
        assertEquals(3, find(r, "bread").qty);
    }

    @Test
    void productNameStartingWithNumberKeepsIt() {
        BillTextParser.Result r = BillTextParser.parse("7 Up 2.25 L 1 40.00 40.00\nLays Magic Masala 2 20.00 40.00\n");
        assertTrue(find(r, "up").name.startsWith("7 Up"));
    }

    @Test
    void headerFooterAndAddressAreNotItems() {
        String text = """
                SUPERSAVE AUNDH
                Plot 12, MIDC Road
                Item   Qty  Rate  Amt
                Amul Taaza Milk 1L  2 54.00 108.00
                Total  108.00
                Thank you, visit again
                """;
        BillTextParser.Result r = BillTextParser.parse(text);
        assertEquals(1, r.items.size());
        assertEquals(2, r.items.get(0).qty);
    }
}
