package com.quickmart.ocr;

import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

/**
 * End-to-end OCR on rendered invoices (clean, skewed, shaded phone-photo, sideways, receipt, loose goods).
 * Uses real Tesseract; skipped automatically when it is not installed. The images are renders made by
 * scripts/generate_test_invoices.py, not photographs of real paper bills.
 */
class OcrExtractionTest {
    private static final String GSTIN = "27ABCDE1234F1Z0";

    private record Row(String nameContains, double qty, String rate, String amount) {}

    private static final List<Row> DISTRIBUTOR = List.of(
            new Row("tata salt", 50, "24.00", "1200.00"),
            new Row("atta", 20, "255.00", "5100.00"),
            new Row("butter", 24, "268.00", "6303.36"),
            new Row("toor", 30, "164.50", "4935.00"),
            new Row("oil", 15, "138.00", "2070.00"),
            new Row("biscuit", 40, "21.50", "860.00"),
            new Row("surf", 12, "118.00", "1416.00"));

    private static BillTextParser.Line row(BillScanner.Scan s, String key) {
        return s.parsed.items.stream().filter(l -> l.name.toLowerCase().contains(key)).findFirst()
                .orElseThrow(() -> new AssertionError("no row containing '" + key + "' in " + s.parsed.items.stream().map(l -> l.name).toList()));
    }

    private static void assertRows(BillScanner.Scan s, List<Row> expected) {
        for (Row e : expected) {
            BillTextParser.Line l = row(s, e.nameContains);
            assertEquals(e.qty, l.qty, e.nameContains + " qty");
            assertEquals(0, new BigDecimal(e.rate).compareTo(l.rate), e.nameContains + " rate " + l.rate);
            assertEquals(0, new BigDecimal(e.amount).compareTo(l.amount), e.nameContains + " amount " + l.amount);
            assertTrue(l.verified, e.nameContains + " should pass the arithmetic check");
        }
    }

    private static void assertDistributorHeader(BillScanner.Scan s) {
        InvoiceHeader h = s.header;
        assertEquals("SHREE GANESH DISTRIBUTORS", h.supplierName);
        assertEquals("SGD/2026/0457", h.invoiceNumber);
        assertEquals(LocalDate.of(2026, 10, 2), h.invoiceDate);
        assertEquals(GSTIN, h.gstin, "the supplier GSTIN, not the buyer's");
        assertTrue(h.gstinChecksumValid);
        assertEquals(0, new BigDecimal("21884.36").compareTo(h.subtotal));
        assertEquals(0, new BigDecimal("22979.00").compareTo(h.grandTotal));
    }

    @Test void cleanDistributorInvoice() throws Exception {
        BillScanner.Scan s = BillScanner.scan(OcrTestSupport.image("a_distributor_clean.png"), OcrTestSupport.realEngineOrSkip());
        assertEquals(7, s.parsed.items.size());
        assertRows(s, DISTRIBUTOR);
        assertDistributorHeader(s);
        assertTrue(s.confidence() > 75, "mean OCR confidence " + s.confidence());
        assertEquals("pcs", row(s, "butter").unit);
        assertEquals("0405", row(s, "butter").hsn);
        assertEquals(0, new BigDecimal("2").compareTo(row(s, "butter").discountPct), "2% discount recognised");
    }

    @Test void skewedScanIsStraightenedBeforeReading() throws Exception {
        BillScanner.Scan s = BillScanner.scan(OcrTestSupport.image("a_distributor_skew3.png"), OcrTestSupport.realEngineOrSkip());
        assertEquals(7, s.parsed.items.size());
        assertRows(s, DISTRIBUTOR);
        assertDistributorHeader(s);
    }

    @Test void sidewaysPhotoIsRotatedUpright() throws Exception {
        BillScanner.Scan s = BillScanner.scan(OcrTestSupport.image("a_distributor_sideways.png"), OcrTestSupport.realEngineOrSkip());
        assertNotEquals(0, s.rotation, "the scanner had to turn the page");
        assertRows(s, DISTRIBUTOR);
        assertDistributorHeader(s);
    }

    @Test void shadedNoisyPhoneJpegWithTableBorders() throws Exception {
        BillScanner.Scan s = BillScanner.scan(OcrTestSupport.image("a_distributor_photo.jpg"), OcrTestSupport.realEngineOrSkip());
        assertEquals(ImagePreprocessor.Variant.BINARIZED, s.variant, "shadows/noise need the adaptive-threshold variant");
        assertRows(s, DISTRIBUTOR);
        assertDistributorHeader(s);
    }

    @Test void thermalStyleReceipt() throws Exception {
        BillScanner.Scan s = BillScanner.scan(OcrTestSupport.image("b_receipt_clean.png"), OcrTestSupport.realEngineOrSkip());
        assertEquals(5, s.parsed.items.size());
        assertRows(s, List.of(new Row("tata salt 1kg", 6, "24.00", "144.00"), new Row("500g", 4, "13.00", "52.00"),
                new Row("milk", 10, "54.00", "540.00"), new Row("maggi", 24, "14.00", "336.00"), new Row("cashew", 2, "210.00", "420.00")));
        assertEquals("SUPERSAVE WHOLESALE MART", s.header.supplierName);
        assertEquals("SS-10458", s.header.invoiceNumber);
        assertEquals(LocalDate.of(2026, 11, 4), s.header.invoiceDate);
        assertEquals(0, new BigDecimal("1492.00").compareTo(s.header.grandTotal));
    }

    @Test void receiptPhotoNeverAcceptsAGarbledRowSilently() throws Exception {
        BillScanner.Scan s = BillScanner.scan(OcrTestSupport.image("b_receipt_photo.jpg"), OcrTestSupport.realEngineOrSkip());
        assertRows(s, List.of(new Row("tata salt 1kg", 6, "24.00", "144.00"), new Row("500g", 4, "13.00", "52.00"),
                new Row("milk", 10, "54.00", "540.00"), new Row("maggi", 24, "14.00", "336.00")));
        BillTextParser.Line cashew = row(s, "cashew");
        if (cashew.qty != 2 || cashew.rate == null || cashew.rate.compareTo(new BigDecimal("210.00")) != 0) {
            assertFalse(cashew.verified, "a misread row must be flagged, never marked verified");
        }
    }

    @Test void looseGoodsWithQuantityAndKgUnitColumns() throws Exception {
        BillScanner.Scan s = BillScanner.scan(OcrTestSupport.image("c_loose_goods.png"), OcrTestSupport.realEngineOrSkip());
        assertEquals(3, s.parsed.items.size());
        BillTextParser.Line sugar = row(s, "sugar");
        assertEquals(25, sugar.qty);
        assertEquals("kg", sugar.unit);
        assertEquals(0, new BigDecimal("1100.00").compareTo(sugar.amount));
        assertEquals("bag", row(s, "basmati").unit);
        assertEquals("5 kg", row(s, "basmati").packSize.label());
        assertEquals("New Bharat Trading Co", s.header.supplierName);
    }

    @Test void blankPageYieldsNothingInsteadOfInventedRows() throws Exception {
        BillScanner.Scan s = BillScanner.scan(OcrTestSupport.image("blank.png"), OcrTestSupport.realEngineOrSkip());
        assertEquals(0, s.parsed.items.size());
        assertNull(s.header.grandTotal);
    }
}
