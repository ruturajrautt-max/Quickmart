package com.quickmart.ocr;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class PackSizeAndUnitTest {
    @Test void kilogramsAndGramsAreNormalised() {
        assertTrue(PackSize.find("Tata Salt 1kg").sameAs(PackSize.find("TATA SALT 1 KG")));
        assertTrue(PackSize.find("Sugar 1 kg").sameAs(PackSize.find("Sugar 1000 g")));
        assertTrue(PackSize.find("Oil 0.5 L").sameAs(PackSize.find("Oil 500 ml")));
        assertEquals("500 g", PackSize.find("Tata Salt 500g").label());
        assertEquals("1 kg", PackSize.find("TATA SALT 1 KG").label());
    }

    @Test void differentPacksAreDifferent() {
        assertFalse(PackSize.find("Tata Salt 500g").sameAs(PackSize.find("Tata Salt 1kg")));
        assertFalse(PackSize.find("Milk 1 L").sameAs(PackSize.find("Flour 1 kg")), "volume and mass never equal");
    }

    @Test void ocrReadsDigitOneAsLetterL() {
        assertEquals("1 kg", PackSize.find("Tata Salt lkg").label());
        assertEquals("1 kg", PackSize.find("Tata Salt Ikg").label());
    }

    @Test void unitMustNotRunIntoALongerWord() {
        assertNull(PackSize.find("Lifebuoy 2 LIFEBUOY soap"));
        assertNull(PackSize.find("Dettol 3 in 1"));
    }

    @Test void stripRemovesOnlyTheSize() { assertEquals("Tata Salt", PackSize.strip("Tata Salt 1 kg")); }

    @Test void unitSpellingsAreCanonical() {
        assertEquals("pcs", UnitNormalizer.canonical("Pcs"));
        assertEquals("pcs", UnitNormalizer.canonical("NOS"));
        assertEquals("pcs", UnitNormalizer.canonical("Pes"), "common OCR misreading of Pcs");
        assertEquals("kg", UnitNormalizer.canonical("Kgs."));
        assertEquals("l", UnitNormalizer.canonical("LTR"));
        assertNull(UnitNormalizer.canonical("Salt"));
    }
}
