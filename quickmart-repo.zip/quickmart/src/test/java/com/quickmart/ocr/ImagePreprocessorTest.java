package com.quickmart.ocr;

import org.junit.jupiter.api.Test;

import java.awt.*;
import java.awt.image.BufferedImage;
import java.awt.image.DataBufferByte;
import java.util.Random;

import static org.junit.jupiter.api.Assertions.*;

class ImagePreprocessorTest {

    private static BufferedImage textLike(int w, int h, double skewDegrees) {
        BufferedImage img = new BufferedImage(w, h, BufferedImage.TYPE_INT_RGB);
        Graphics2D g = img.createGraphics();
        g.setColor(Color.WHITE); g.fillRect(0, 0, w, h);
        g.setColor(Color.BLACK);
        g.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 22));
        g.rotate(Math.toRadians(skewDegrees), w / 2.0, h / 2.0);
        for (int y = 60; y < h - 40; y += 36) g.drawString("Tata Salt 1 kg   50   24.00   1200.00", 40, y);
        g.dispose();
        return img;
    }

    private static byte[] px(BufferedImage b) { return ((DataBufferByte) b.getRaster().getDataBuffer()).getData(); }

    @Test void convertsToGrayscaleAndUpscalesSmallImages() {
        BufferedImage out = ImagePreprocessor.prepare(textLike(900, 500, 0));
        assertEquals(BufferedImage.TYPE_BYTE_GRAY, out.getType());
        assertTrue(out.getWidth() > 2000, "a 900 px photo is enlarged towards ~2400 px, got " + out.getWidth());
    }

    @Test void hugePhotosAreShrunk() {
        BufferedImage out = ImagePreprocessor.prepare(new BufferedImage(6000, 400, BufferedImage.TYPE_INT_RGB));
        assertTrue(out.getWidth() < 3800);
    }

    @Test void transparentPngBackgroundBecomesWhiteNotBlack() {
        BufferedImage argb = new BufferedImage(600, 300, BufferedImage.TYPE_INT_ARGB);   // fully transparent
        assertTrue(ImagePreprocessor.isBlank(argb));
        assertEquals(255, px(ImagePreprocessor.toGray(argb))[1000] & 0xFF);
    }

    @Test void skewIsEstimatedAndCorrected() {
        BufferedImage skewed = textLike(1600, 900, 4.0);
        double est = ImagePreprocessor.estimateSkew(ImagePreprocessor.toGray(skewed));
        assertEquals(4.0, est, 0.6, "text drawn rotated clockwise by 4 degrees runs downhill = positive skew, got " + est);
        BufferedImage fixed = ImagePreprocessor.rotateByAngle(ImagePreprocessor.toGray(skewed), -est);
        assertEquals(0.0, ImagePreprocessor.estimateSkew(fixed), 0.6, "after correction the text is level");
    }

    @Test void straightTextIsLeftAlone() {
        assertEquals(0.0, ImagePreprocessor.estimateSkew(ImagePreprocessor.toGray(textLike(1600, 900, 0))), 0.3);
    }

    @Test void rotationByQuarterTurnsSwapsDimensions() {
        BufferedImage g = ImagePreprocessor.toGray(textLike(800, 300, 0));
        BufferedImage r = ImagePreprocessor.rotate(g, 90);
        assertEquals(300, r.getWidth());
        assertEquals(800, r.getHeight());
        assertEquals(800, ImagePreprocessor.rotate(g, 180).getWidth());
    }

    @Test void medianFilterRemovesSaltAndPepperNoise() {
        BufferedImage g = new BufferedImage(200, 200, BufferedImage.TYPE_BYTE_GRAY);
        byte[] p = px(g);
        java.util.Arrays.fill(p, (byte) 200);
        Random r = new Random(1);
        for (int i = 0; i < 300; i++) p[r.nextInt(p.length)] = (byte) (r.nextBoolean() ? 0 : 255);
        ImagePreprocessor.medianFilter3(g);
        int off = 0;
        for (int y = 1; y < 199; y++) for (int x = 1; x < 199; x++) if ((p[y * 200 + x] & 0xFF) != 200) off++;
        assertTrue(off < 5, "isolated noise pixels disappear, " + off + " left");
    }

    @Test void adaptiveThresholdKeepsTextDarkEvenInsideAShadow() {
        BufferedImage g = new BufferedImage(400, 100, BufferedImage.TYPE_BYTE_GRAY);   // left half in shadow, right half bright
        byte[] p = px(g);
        for (int y = 0; y < 100; y++) for (int x = 0; x < 400; x++) {
            boolean text = (y / 6) % 3 == 0 && (x / 5) % 2 == 0 && y > 10 && y < 90 && x % 200 > 10 && x % 200 < 190;
            p[y * 400 + x] = (byte) (x < 200 ? (text ? 20 : 90) : (text ? 120 : 230));
        }
        ImagePreprocessor.adaptiveThreshold(g);
        int blackLeft = 0, blackRight = 0;
        for (int y = 0; y < 100; y++) for (int x = 0; x < 400; x++) if ((p[y * 400 + x] & 0xFF) == 0) { if (x < 200) blackLeft++; else blackRight++; }
        assertTrue(blackLeft > 200 && blackRight > 200, "text survives in both halves (" + blackLeft + " / " + blackRight + ")");
        for (byte b : p) assertTrue(b == 0 || b == (byte) 255, "output is strictly black or white");
    }

    @Test void tableRulingLinesAreErased() {
        int w = 1200, h = 400;
        byte[] bin = new byte[w * h];
        java.util.Arrays.fill(bin, (byte) 255);
        for (int x = 50; x < 1150; x++) for (int t = 0; t < 3; t++) bin[(100 + t) * w + x] = 0;
        for (int y = 100; y < 350; y++) for (int t = 0; t < 3; t++) bin[y * w + 400 + t] = 0;
        for (int x = 600; x < 612; x++) for (int y = 200; y < 214; y++) bin[y * w + x] = 0;
        byte[] marks = ImagePreprocessor.rulingLines(bin, w, h);
        assertEquals(1, marks[100 * w + 500]);
        assertEquals(1, marks[200 * w + 401]);
        assertEquals(0, marks[205 * w + 605], "a letter is not a line");
    }

    @Test void blankPagesAreDetected() {
        BufferedImage white = new BufferedImage(800, 800, BufferedImage.TYPE_INT_RGB);
        Graphics2D g = white.createGraphics(); g.setColor(Color.WHITE); g.fillRect(0, 0, 800, 800); g.dispose();
        assertTrue(ImagePreprocessor.isBlank(white));
        assertFalse(ImagePreprocessor.isBlank(textLike(800, 400, 0)));
    }
}
