package com.quickmart.ocr;

import org.junit.jupiter.api.Assumptions;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.InputStream;

/** Shared helpers: load a sample invoice, and get a real Tesseract engine or skip the test when none is installed. */
public final class OcrTestSupport {
    private OcrTestSupport() {}

    public static BufferedImage image(String name) throws IOException {
        try (InputStream in = OcrTestSupport.class.getResourceAsStream("/invoices/" + name)) {
            if (in == null) throw new IOException("missing test resource /invoices/" + name);
            return ImageIO.read(in);
        }
    }

    public static byte[] bytes(String name) throws IOException {
        try (InputStream in = OcrTestSupport.class.getResourceAsStream("/invoices/" + name)) {
            if (in == null) throw new IOException("missing test resource /invoices/" + name);
            return in.readAllBytes();
        }
    }

    /** Real Tesseract via the command line. Override with -Dtesseract.command=... / -Dtesseract.datapath=... on Windows. */
    public static TesseractCliEngine realEngineOrSkip() {
        TesseractCliEngine e = new TesseractCliEngine(System.getProperty("tesseract.command", "tesseract"),
                System.getProperty("tesseract.datapath"), "eng", 6, 120);
        TesseractCliEngine.Diagnosis d = e.diagnose();
        Assumptions.assumeTrue(d.problem.isEmpty(), "Tesseract is not usable here, skipping real-OCR test: " + d.problem);
        return e;
    }
}
