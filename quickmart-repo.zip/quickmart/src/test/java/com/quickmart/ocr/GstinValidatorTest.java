package com.quickmart.ocr;

import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class GstinValidatorTest {
    // widely published example GSTIN with a valid check digit
    private static final String VALID = "27AAPFU0939F1ZV";

    @Test void checksumAcceptsValidAndRejectsAlteredGstin() {
        assertTrue(GstinValidator.hasValidChecksum(VALID));
        assertFalse(GstinValidator.hasValidChecksum("27AAPFU0939F1ZW"));
        assertFalse(GstinValidator.hasValidChecksum("27AAPFU0938F1ZV"));
    }

    @Test void formatRejectsGarbageAndBadStateCodes() {
        assertFalse(GstinValidator.hasValidFormat("HELLO"));
        assertFalse(GstinValidator.hasValidFormat("99AAPFU0939F1ZV".replace("99", "50")), "no state 50");
    }

    @Test void findsGstinInsideALine() {
        List<GstinValidator.Found> f = GstinValidator.findAll("GSTIN: " + VALID + "  Phone: 9822012345");
        assertEquals(1, f.size());
        assertEquals(VALID, f.get(0).gstin);
        assertTrue(f.get(0).checksumValid);
    }

    @Test void repairsOcrConfusionsByPositionAndCheckDigit() {
        // 'O' for '0' in the digits, and 'S' for '5'
        List<GstinValidator.Found> f = GstinValidator.findAll("GSTIN " + "27AAPFUO939F1ZV");
        assertEquals(VALID, f.get(0).gstin);
        assertTrue(f.get(0).repaired);
        assertTrue(f.get(0).checksumValid);
        // last character misread: expected check digit is V, OCR gave a confusable only when same class; a clearly different one stays invalid
        assertFalse(GstinValidator.findAll("27AAPFU0939F1ZX").get(0).checksumValid);
    }
}
