package com.quickmart.ocr;

import org.junit.jupiter.api.Test;

import java.awt.image.BufferedImage;

import static org.junit.jupiter.api.Assertions.*;

class OcrEngineTest {
    private static final BufferedImage IMG = new BufferedImage(400, 200, BufferedImage.TYPE_BYTE_GRAY);

    @Test void tsvIsGroupedIntoLinesWithConfidence() {
        String tsv = "level\tpage_num\tblock_num\tpar_num\tline_num\tword_num\tleft\ttop\twidth\theight\tconf\ttext\n"
                + "5\t1\t1\t1\t1\t1\t10\t10\t50\t20\t96.5\tTata\n"
                + "5\t1\t1\t1\t1\t2\t65\t10\t40\t20\t90.0\tSalt\n"
                + "5\t1\t1\t1\t1\t3\t300\t10\t60\t20\t80.0\t24.00\n"
                + "5\t1\t1\t1\t2\t1\t10\t50\t50\t20\t-1\t\n"
                + "5\t1\t1\t1\t2\t2\t10\t50\t50\t20\t70\tOil\n";
        OcrPage p = TesseractCliEngine.parseTsv(tsv, "t");
        assertEquals(2, p.lines.size());
        assertEquals("Tata Salt   24.00", p.lines.get(0).text, "a wide gap between columns is kept visible");
        assertEquals((96.5 + 90 + 80) / 3, p.lines.get(0).confidence, 0.01);
        assertEquals("Oil", p.lines.get(1).text);
    }

    @Test void missingTesseractGivesAnActionableError() {
        TesseractCliEngine e = new TesseractCliEngine("definitely-not-a-real-tesseract-binary", null, "eng", 6, 10);
        OcrException ex = assertThrows(OcrException.class, () -> e.read(IMG));
        assertEquals(OcrException.Reason.ENGINE_UNAVAILABLE, ex.reason);
        assertTrue(ex.getMessage().contains("tesseract.command"), ex.getMessage());
        assertFalse(e.diagnose().problem.isEmpty());
    }

    @Test void missingLanguageDataIsReportedAsSuch() {
        TesseractCliEngine real = OcrTestSupport.realEngineOrSkip();
        TesseractCliEngine bad = new TesseractCliEngine(System.getProperty("tesseract.command", "tesseract"), System.getProperty("tesseract.datapath"), "zzz", 6, 60);
        OcrException ex = assertThrows(OcrException.class, () -> bad.read(IMG));
        assertEquals(OcrException.Reason.LANGUAGE_DATA_MISSING, ex.reason);
        assertTrue(ex.getMessage().contains("zzz"));
        assertTrue(bad.diagnose().problem.contains("zzz"));
        assertTrue(real.diagnose().languages.contains("eng"));
    }

    private static OcrEngine engine(String name, OcrPage page, OcrException ex, Error err) {
        return new OcrEngine() {
            int calls;
            @Override public String name() { return name; }
            @Override public OcrPage read(BufferedImage i) throws OcrException {
                calls++;
                if (err != null) throw err;
                if (ex != null) throw ex;
                return page;
            }
        };
    }

    @Test void fallbackUsedWhenNativeLibraryCannotLoad() throws Exception {
        OcrPage ok = OcrPage.ofText("hello", 90, "cli");
        FallbackOcrEngine f = new FallbackOcrEngine(engine("Tess4J", null, null, new UnsatisfiedLinkError("libtesseract")), engine("cli", ok, null, null));
        assertSame(ok, f.read(IMG));
        assertTrue(f.primaryBroken(), "a broken native library is not retried on every image");
        assertEquals("cli", f.name());
        assertTrue(f.primaryProblem().contains("UnsatisfiedLinkError"));
    }

    @Test void ordinaryPerImageFailureFallsBackWithoutDisablingPrimary() throws Exception {
        OcrPage ok = OcrPage.ofText("hello", 90, "cli");
        FallbackOcrEngine f = new FallbackOcrEngine(engine("Tess4J", null, new OcrException(OcrException.Reason.FAILED, "bad image"), null), engine("cli", ok, null, null));
        assertSame(ok, f.read(IMG));
        assertFalse(f.primaryBroken());
    }

    @Test void bothEnginesFailingReportsBothProblems() {
        FallbackOcrEngine f = new FallbackOcrEngine(engine("Tess4J", null, new OcrException(OcrException.Reason.ENGINE_UNAVAILABLE, "no jna"), null),
                engine("cli", null, new OcrException(OcrException.Reason.ENGINE_UNAVAILABLE, "no tesseract.exe"), null));
        OcrException ex = assertThrows(OcrException.class, () -> f.read(IMG));
        assertEquals(OcrException.Reason.ENGINE_UNAVAILABLE, ex.reason);
        assertTrue(ex.getMessage().contains("no tesseract.exe") && ex.getMessage().contains("no jna"), ex.getMessage());
    }
}
