package com.quickmart.ocr;

import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.*;

class InvoiceHeaderParserTest {
    private static final String GSTIN = "27AAPFU0939F1ZV";

    @Test void readsAFullTaxInvoiceHeader() {
        String t = "SHREE GANESH DISTRIBUTORS\nPlot 12, MIDC Industrial Area, Pune 411019\nGSTIN: " + GSTIN + "   Phone: 9822012345\n"
                + "TAX INVOICE   Invoice No: SGD/2026/0457   Date: 02-10-2026\nBill To: Sai Kirana Stores   Buyer GSTIN: 27AAAPL1234C1ZV\n"
                + "Sub Total   21884.36\nCGST 2.5%   547.11\nSGST 2.5%   547.11\nRound Off   0.42\nGrand Total   22979.00\n";
        InvoiceHeader h = InvoiceHeaderParser.parse(t);
        assertEquals("SHREE GANESH DISTRIBUTORS", h.supplierName);
        assertEquals("SGD/2026/0457", h.invoiceNumber);
        assertEquals(LocalDate.of(2026, 10, 2), h.invoiceDate);
        assertEquals(GSTIN, h.gstin, "supplier GSTIN, not the buyer's");
        assertTrue(h.gstinChecksumValid);
        assertEquals(1, h.otherGstins.size());
        assertEquals(0, new BigDecimal("21884.36").compareTo(h.subtotal));
        assertEquals(0, new BigDecimal("547.11").compareTo(h.cgst));
        assertEquals(0, new BigDecimal("2.5").compareTo(h.cgstRate));
        assertEquals(0, new BigDecimal("22979.00").compareTo(h.grandTotal));
        assertEquals(0, new BigDecimal("0.42").compareTo(h.roundOff));
    }

    @Test void differentDateAndNumberStyles() {
        assertEquals(LocalDate.of(2026, 9, 18), InvoiceHeaderParser.parse("New Bharat Trading\nInvoice No. NB-2291   Dated: 18-Sep-2026").invoiceDate);
        assertEquals("NB-2291", InvoiceHeaderParser.parse("Invoice No. NB-2291").invoiceNumber);
        assertEquals("SS-10458", InvoiceHeaderParser.parse("Bill No: SS-10458  Date: 04/11/2026").invoiceNumber);
        assertEquals(LocalDate.of(2026, 11, 4), InvoiceHeaderParser.parse("Bill No: SS-10458  Date: 04/11/2026").invoiceDate);
        assertEquals(LocalDate.of(2026, 3, 7), InvoiceHeaderParser.parse("Date 7.3.26").invoiceDate);
    }

    @Test void impossibleDatesAreNotInvented() {
        assertNull(InvoiceHeaderParser.parse("Date: 31-02-2026").invoiceDate);
    }

    @Test void totalsWithoutLabelsAreNotGuessed() {
        InvoiceHeader h = InvoiceHeaderParser.parse("Tata Salt 1kg 6 24.00 144.00");
        assertNull(h.grandTotal);
        assertNull(h.invoiceNumber);
        assertNull(h.gstin);
    }

    @Test void supplierIsNotTheWordInvoiceOrAnAddress() {
        InvoiceHeader h = InvoiceHeaderParser.parse("TAX INVOICE\nOriginal for Recipient\nNew Bharat Trading Co\nShop 4, Aundh Road, Pune\n");
        assertEquals("New Bharat Trading Co", h.supplierName);
    }
}
