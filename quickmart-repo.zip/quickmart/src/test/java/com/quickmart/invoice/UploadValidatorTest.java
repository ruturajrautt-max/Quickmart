package com.quickmart.invoice;

import com.quickmart.ocr.OcrTestSupport;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

/** Invalid image uploads are refused with the right status before any OCR runs. */
class UploadValidatorTest {
    private static int statusOf(byte[] data, long max) {
        return assertThrows(InvalidBillUploadException.class, () -> UploadValidator.check(data, max)).status;
    }

    @Test void validJpegPngAndPdfAreRecognisedByContent() throws Exception {
        assertEquals(UploadValidator.Kind.PNG, UploadValidator.check(OcrTestSupport.bytes("a_distributor_clean.png"), UploadValidator.MAX_BYTES));
        assertEquals(UploadValidator.Kind.JPEG, UploadValidator.check(OcrTestSupport.bytes("a_distributor_photo.jpg"), UploadValidator.MAX_BYTES));
        assertEquals(UploadValidator.Kind.PDF, UploadValidator.check(OcrTestSupport.bytes("a_distributor.pdf"), UploadValidator.MAX_BYTES));
    }

    @Test void textFileRenamedToPngIsRejected() throws Exception { assertEquals(415, statusOf(OcrTestSupport.bytes("not_an_image.png"), UploadValidator.MAX_BYTES)); }
    @Test void emptyFileIsRejected() { assertEquals(400, statusOf(new byte[0], UploadValidator.MAX_BYTES)); assertEquals(400, statusOf(null, UploadValidator.MAX_BYTES)); }
    @Test void oversizedFileIsRejected() throws Exception { assertEquals(413, statusOf(OcrTestSupport.bytes("a_distributor_clean.png"), 1000)); }
    @Test void thumbnailSizedImageIsRejected() throws Exception { assertEquals(422, statusOf(OcrTestSupport.bytes("tiny.png"), UploadValidator.MAX_BYTES)); }
    @Test void gifAndOtherFormatsAreRejected() { assertEquals(415, statusOf("GIF89a....................".getBytes(), UploadValidator.MAX_BYTES)); }

    @Test void truncatedImageIsRejectedAsDamaged() throws Exception {
        byte[] png = OcrTestSupport.bytes("a_distributor_clean.png");
        byte[] cut = java.util.Arrays.copyOf(png, 20);                       // valid signature, no usable header
        assertEquals(422, statusOf(cut, UploadValidator.MAX_BYTES));
    }

    @Test void sha256IsStableAndSensitive() {
        assertEquals(Hashing.sha256("abc"), Hashing.sha256("abc".getBytes()));
        assertEquals("ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad", Hashing.sha256("abc"));
        assertNotEquals(Hashing.sha256("abc"), Hashing.sha256("abd"));
    }

    @Test void invoiceKeyIgnoresFormattingButNotTheNumber() {
        String a = Hashing.invoiceKey("27AAPFU0939F1ZV", "X", "SGD/2026/0457"), b = Hashing.invoiceKey("27aapfu0939f1zv", "Y", "sgd 2026 0457");
        assertEquals(a, b);
        assertNotEquals(a, Hashing.invoiceKey("27AAPFU0939F1ZV", "X", "SGD/2026/0458"));
        assertNull(Hashing.invoiceKey(null, null, "SGD/1"), "not enough information to fingerprint");
    }
}
