package com.quickmart.invoice;

import com.quickmart.dto.*;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

/** Inventory updates, quantity/unit normalisation, duplicate detection and all-or-nothing behaviour. */
class BillConfirmationTest {
    private static final LocalDate TODAY = LocalDate.of(2026, 11, 16);
    private static final String GSTIN = "27AAPFU0939F1ZV";

    private static InMemoryShop shop() {
        return new InMemoryShop().item(1, "Tata Salt", "Tata", "1 kg", 10, "28.00").item(2, "Tata Salt", "Tata", "500 g", null, "0")
                .item(3, "Sugar", "", "1 kg", 5, "48.00");
    }

    private static InvoiceLineDto add(int id, String name, long itemId, String qty) {
        InvoiceLineDto l = new InvoiceLineDto();
        l.lineId = id; l.name = name; l.qty = new BigDecimal(qty); l.action = "ADD"; l.itemId = itemId;
        return l;
    }

    private static InvoiceEdit edit(InvoiceLineDto... lines) {
        InvoiceEdit e = new InvoiceEdit();
        e.header = new InvoiceHeaderDto();
        e.header.supplierName = "Shree Ganesh"; e.header.invoiceNumber = "SGD/2026/0457"; e.header.invoiceDate = "2026-11-10"; e.header.gstin = GSTIN;
        e.lines = List.of(lines);
        e.acknowledgeWarnings = true;
        return e;
    }

    @Test void confirmedBillAddsStockToExistingProducts() {
        InMemoryShop s = shop();
        ConfirmResult r = BillConfirmation.confirm(edit(add(1, "Tata Salt 1 kg", 1, "50"), add(2, "Sugar 1 kg", 3, "20")), "hash1", TODAY, s, s);
        assertEquals(60, s.stock.get(1L));
        assertEquals(25, s.stock.get(3L));
        assertEquals(2, r.productsUpdated);
        assertEquals(70, r.unitsAdded);
        assertEquals(10, r.changes.get(0).oldStock);
        assertEquals(60, r.changes.get(0).newStock);
        assertEquals(new BigDecimal("28.00"), s.price.get(1L), "the bill's cost rate never overwrites the selling price");
    }

    @Test void newProductNeedsCategoryAndSellingPriceThenIsCreated() {
        InMemoryShop s = shop();
        InvoiceLineDto n = new InvoiceLineDto(); n.lineId = 1; n.name = "Surf Excel Easy Wash 1 kg"; n.qty = new BigDecimal("12"); n.action = "CREATE";
        BillValidationException ex = assertThrows(BillValidationException.class, () -> BillConfirmation.confirm(edit(n), "h", TODAY, s, s));
        assertTrue(ex.issues.stream().anyMatch(i -> i.code.equals("CATEGORY_REQUIRED")));
        assertTrue(ex.issues.stream().anyMatch(i -> i.code.equals("PRICE_REQUIRED")));
        assertEquals(0, s.writes);
        n.newCategory = "Household"; n.sellingPrice = new BigDecimal("135");
        ConfirmResult r = BillConfirmation.confirm(edit(n), "h", TODAY, s, s);
        assertEquals(1, r.productsCreated);
        long id = r.changes.get(0).itemId;
        assertEquals(12, s.stock.get(id));
        assertEquals("1 kg", s.items.get(id).unitSize(), "pack size is taken from the bill row");
        assertEquals(0, new BigDecimal("135.00").compareTo(s.price.get(id)));
    }

    @Test void existingProductNewToThisShopNeedsASellingPrice() {
        InMemoryShop s = shop();
        BillValidationException ex = assertThrows(BillValidationException.class, () -> BillConfirmation.confirm(edit(add(1, "Tata Salt 500 g", 2, "10")), "h", TODAY, s, s));
        assertTrue(ex.issues.stream().anyMatch(i -> i.code.equals("PRICE_REQUIRED")));
        InvoiceLineDto l = add(1, "Tata Salt 500 g", 2, "10"); l.sellingPrice = new BigDecimal("15");
        BillConfirmation.confirm(edit(l), "h", TODAY, s, s);
        assertEquals(10, s.stock.get(2L));
    }

    @Test void measureUnitsAreConvertedIntoPacks() {
        InMemoryShop s = shop();
        InvoiceLineDto kg = add(1, "Sugar", 3, "25"); kg.unit = "KG";                 // 25 kg of a 1 kg product
        BillConfirmation.confirm(edit(kg), "h", TODAY, s, s);
        assertEquals(30, s.stock.get(3L));
        InMemoryShop s2 = shop();
        InvoiceLineDto grams = add(1, "Tata Salt", 2, "5000"); grams.unit = "g"; grams.sellingPrice = new BigDecimal("15");   // 5000 g of 500 g packs
        BillConfirmation.confirm(edit(grams), "h2", TODAY, s2, s2);
        assertEquals(10, s2.stock.get(2L));
    }

    @Test void quantityThatIsNotAWholeNumberOfPacksIsRefused() {
        InMemoryShop s = shop();
        InvoiceLineDto half = add(1, "Sugar", 3, "2.5"); half.unit = "pcs";
        BillValidationException ex = assertThrows(BillValidationException.class, () -> BillConfirmation.confirm(edit(half), "h", TODAY, s, s));
        assertTrue(ex.issues.stream().anyMatch(i -> i.code.equals("QTY_NOT_WHOLE") && i.isError()));
        assertEquals(0, s.writes);
        assertEquals(5, s.stock.get(3L));
    }

    @Test void dozenCountsAsTwelvePieces() {
        InMemoryShop s = shop().item(4, "Eggs", "", "1 pcs", 0, "6");
        InvoiceLineDto d = add(1, "Eggs", 4, "2"); d.unit = "dozen";
        BillConfirmation.confirm(edit(d), "h", TODAY, s, s);
        assertEquals(24, s.stock.get(4L));
    }

    @Test void packSizeMismatchBlocksUnlessTheVendorOverrides() {
        InMemoryShop s = shop();
        InvoiceLineDto l = add(1, "Tata Salt 500 g", 1, "10");                         // bill says 500 g, product 1 chosen is 1 kg
        BillValidationException ex = assertThrows(BillValidationException.class, () -> BillConfirmation.confirm(edit(l), "h", TODAY, s, s));
        assertTrue(ex.issues.stream().anyMatch(i -> i.code.equals("PACK_MISMATCH") && i.isError()));
        assertEquals(10, s.stock.get(1L));
        l.packOverride = true;
        BillConfirmation.confirm(edit(l), "h", TODAY, s, s);
        assertEquals(20, s.stock.get(1L));
    }

    @Test void unmappedRowsMustBeResolvedOrSkipped() {
        InMemoryShop s = shop();
        InvoiceLineDto un = new InvoiceLineDto(); un.lineId = 1; un.name = "Mystery Item"; un.qty = BigDecimal.TEN; un.action = "";
        BillValidationException ex = assertThrows(BillValidationException.class, () -> BillConfirmation.confirm(edit(un, add(2, "Sugar", 3, "1")), "h", TODAY, s, s));
        assertTrue(ex.issues.stream().anyMatch(i -> i.code.equals("UNMAPPED") && i.lineId == 1));
        assertEquals(0, s.writes, "the valid second row was NOT applied: all or nothing");
        un.action = "SKIP";
        BillConfirmation.confirm(edit(un, add(2, "Sugar", 3, "1")), "h", TODAY, s, s);
        assertEquals(6, s.stock.get(3L));
    }

    @Test void sameProductOnTwoRowsIsMerged() {
        InMemoryShop s = shop();
        BillConfirmation.confirm(edit(add(1, "Sugar", 3, "4"), add(2, "Sugar", 3, "6")), "h", TODAY, s, s);
        assertEquals(15, s.stock.get(3L));
    }

    @Test void warningsRequireAcknowledgement() {
        InMemoryShop s = shop();
        InvoiceLineDto l = add(1, "Sugar", 3, "5"); l.rate = new BigDecimal("40"); l.amount = new BigDecimal("999");   // arithmetic does not hold
        InvoiceEdit e = edit(l); e.acknowledgeWarnings = false;
        BillValidationException ex = assertThrows(BillValidationException.class, () -> BillConfirmation.confirm(e, "h", TODAY, s, s));
        assertTrue(ex.needsAcknowledgement);
        assertEquals(0, s.writes);
        e.acknowledgeWarnings = true;
        BillConfirmation.confirm(e, "h", TODAY, s, s);
        assertEquals(10, s.stock.get(3L));
    }

    @Test void theSameFileCannotBeAddedTwice() {
        InMemoryShop s = shop();
        BillConfirmation.confirm(edit(add(1, "Sugar", 3, "5")), "SAMEHASH", TODAY, s, s);
        DuplicateBillException ex = assertThrows(DuplicateBillException.class, () -> BillConfirmation.confirm(edit(add(1, "Sugar", 3, "5")), "SAMEHASH", TODAY, s, s));
        assertEquals("FILE", ex.kind);
        assertEquals(10, s.stock.get(3L), "stock was not added a second time");
    }

    @Test void aDifferentPhotoOfTheSameInvoiceIsAlsoCaught() {
        InMemoryShop s = shop();
        BillConfirmation.confirm(edit(add(1, "Sugar", 3, "5")), "PHOTO-1", TODAY, s, s);
        InvoiceEdit again = edit(add(1, "Sugar", 3, "5"));
        again.header.invoiceNumber = "sgd 2026 0457";                                 // same invoice, different formatting
        DuplicateBillException ex = assertThrows(DuplicateBillException.class, () -> BillConfirmation.confirm(again, "PHOTO-2", TODAY, s, s));
        assertEquals("INVOICE", ex.kind);
        assertEquals(10, s.stock.get(3L));
        again.header.invoiceNumber = "SGD/2026/0458";                                 // a genuinely different invoice goes through
        BillConfirmation.confirm(again, "PHOTO-3", TODAY, s, s);
        assertEquals(15, s.stock.get(3L));
    }

    @Test void rowsMustBeSentToConfirm() {
        InMemoryShop s = shop();
        assertThrows(IllegalArgumentException.class, () -> BillConfirmation.confirm(new InvoiceEdit(), "h", TODAY, s, s));
    }
}
