package com.quickmart.invoice;

import com.quickmart.dto.*;
import com.quickmart.ocr.BillScanner;
import com.quickmart.ocr.OcrTestSupport;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

/**
 * The whole workflow minus HTTP and MySQL: photo -> OCR -> extraction -> catalog matching -> issues -> (nothing changes)
 * -> vendor corrections -> confirmation -> inventory -> duplicate upload refused. Real Tesseract; skipped if absent.
 */
class InvoicePipelineTest {
    private static final LocalDate TODAY = LocalDate.of(2026, 11, 16);

    private static InMemoryShop shop() {
        return new InMemoryShop()
                .item(1, "Tata Salt", "Tata", "1 kg", 100, "28.00")
                .item(2, "Aashirvaad Whole Wheat Atta", "Aashirvaad", "5 kg", 40, "290.00")
                .item(3, "Amul Butter Pasteurised", "Amul", "500 g", 12, "285.00")
                .item(4, "Tata Sampann Toor Dal", "Tata Sampann", "1 kg", 30, "185.00")
                .item(5, "Fortune Sunflower Oil", "Fortune", "1 L", 20, "155.00")
                .item(6, "Parle-G Gold Biscuits", "Parle", "250 g", 60, "25.00");
    }

    private static InvoiceView scan(String image, InMemoryShop s) throws Exception {
        BillScanner.Scan scan = BillScanner.scan(OcrTestSupport.image(image), OcrTestSupport.realEngineOrSkip());
        return InvoiceAssembler.fromScans(List.of(scan), s.matcher(), s, TODAY);
    }

    private static InvoiceLineDto lineLike(InvoiceView v, String key) {
        return v.lines.stream().filter(l -> l.name.toLowerCase().contains(key)).findFirst().orElseThrow(() -> new AssertionError("no row " + key + " in " + v.lines.stream().map(l -> l.name).toList()));
    }

    /** What the browser sends back: the same rows as NEW objects (so server-side "what changed" comparisons are real). */
    private static InvoiceEdit editFrom(InvoiceView v) {
        InvoiceEdit e = new InvoiceEdit();
        e.header = new InvoiceHeaderDto();
        InvoiceHeaderDto h = v.header;
        e.header.supplierName = h.supplierName; e.header.invoiceNumber = h.invoiceNumber; e.header.invoiceDate = h.invoiceDate; e.header.gstin = h.gstin;
        e.header.subtotal = h.subtotal; e.header.cgst = h.cgst; e.header.sgst = h.sgst; e.header.igst = h.igst; e.header.cgstRate = h.cgstRate;
        e.header.sgstRate = h.sgstRate; e.header.igstRate = h.igstRate; e.header.roundOff = h.roundOff; e.header.grandTotal = h.grandTotal;
        for (InvoiceLineDto o : v.lines) {
            InvoiceLineDto l = new InvoiceLineDto();
            l.lineId = o.lineId; l.name = o.name; l.qty = o.qty; l.unit = o.unit; l.packSize = o.packSize; l.rate = o.rate; l.amount = o.amount;
            l.discountPct = o.discountPct; l.gstPct = o.gstPct; l.hsn = o.hsn; l.action = o.action; l.itemId = o.itemId; l.newCategory = o.newCategory;
            l.newBrand = o.newBrand; l.newUnitSize = o.newUnitSize; l.sellingPrice = o.sellingPrice; l.packOverride = o.packOverride;
            e.lines.add(l);
        }
        return e;
    }

    @Test void uploadMatchesKnownProductsFlagsTheUnknownOneAndChangesNothing() throws Exception {
        InMemoryShop s = shop();
        InvoiceView v = scan("a_distributor_photo.jpg", s);

        assertEquals(7, v.lines.size());
        assertEquals(0, s.writes, "scanning alone must never touch inventory or the import ledger");
        assertEquals(100, s.stock.get(1L));
        for (String key : List.of("tata salt", "atta", "butter", "toor", "oil", "biscuit")) {
            InvoiceLineDto l = lineLike(v, key);
            assertEquals("MATCHED", l.matchStatus, key + " -> " + l.itemName + " " + l.matchConfidence);
            assertEquals("ADD", l.action);
            assertTrue(l.matchConfidence >= 85);
            assertNotNull(l.ocrConfidence);
            assertNotNull(l.currentStock);
        }
        assertEquals(1L, lineLike(v, "tata salt").itemId);
        assertEquals(50, lineLike(v, "tata salt").stockUnits);

        InvoiceLineDto surf = lineLike(v, "surf");
        assertEquals("UNMATCHED", surf.matchStatus);
        assertNull(surf.itemId);
        assertTrue(v.issues.stream().anyMatch(i -> i.code.equals("UNMAPPED") && i.isError() && i.lineId.equals(surf.lineId)));
        assertFalse(v.canConfirm, "an unmapped row blocks confirmation");
        assertEquals("SHREE GANESH DISTRIBUTORS", v.header.supplierName);
        assertEquals("SGD/2026/0457", v.header.invoiceNumber);
        assertTrue(v.ocrConfidence > 60);
    }

    @Test void vendorCorrectsAndConfirmsThenInventoryChangesExactlyOnce() throws Exception {
        InMemoryShop s = shop();
        InvoiceView v = scan("a_distributor_photo.jpg", s);

        InvoiceEdit vendorEdit = editFrom(v);
        InvoiceLineDto surf = vendorEdit.lines.stream().filter(l -> l.name.toLowerCase().contains("surf")).findFirst().orElseThrow();
        surf.action = "CREATE"; surf.newCategory = "Household"; surf.sellingPrice = new BigDecimal("135");
        InvoiceView edited = InvoiceAssembler.applyEdit(v, vendorEdit, s.matcher(), s, TODAY);
        assertEquals(0, edited.errorCount, edited.issues.toString());
        assertTrue(edited.canConfirm);
        assertEquals(0, s.writes, "saving edits does not touch inventory either");

        InvoiceEdit confirm = editFrom(edited);
        confirm.acknowledgeWarnings = true;
        String hash = Hashing.sha256(OcrTestSupport.bytes("a_distributor_photo.jpg"));
        ConfirmResult r = BillConfirmation.confirm(confirm, hash, TODAY, s, s);

        assertEquals(6, r.productsUpdated);
        assertEquals(1, r.productsCreated);
        assertEquals(150, s.stock.get(1L));        // 100 + 50
        assertEquals(60, s.stock.get(2L));         // 40 + 20
        assertEquals(36, s.stock.get(3L));         // 12 + 24
        assertEquals(60, s.stock.get(4L));         // 30 + 30
        assertEquals(35, s.stock.get(5L));         // 20 + 15
        assertEquals(100, s.stock.get(6L));        // 60 + 40
        long newId = r.changes.stream().filter(c -> c.created).findFirst().orElseThrow().itemId;
        assertEquals(12, s.stock.get(newId));
        assertEquals(new BigDecimal("28.00"), s.price.get(1L), "selling prices untouched");

        int stockBefore = s.stock.values().stream().mapToInt(Integer::intValue).sum();
        assertThrows(DuplicateBillException.class, () -> BillConfirmation.confirm(confirm, hash, TODAY, s, s));
        assertEquals(stockBefore, s.stock.values().stream().mapToInt(Integer::intValue).sum(), "re-submitting adds nothing");
    }

    @Test void aWrongPackInTheCatalogIsNotMatchedAutomatically() throws Exception {
        InMemoryShop s = new InMemoryShop().item(1, "Tata Salt", "Tata", "500 g", 10, "15.00");   // the bill has Tata Salt 1 kg
        InvoiceView v = scan("a_distributor_clean.png", s);
        InvoiceLineDto salt = lineLike(v, "tata salt");
        assertEquals("UNMATCHED", salt.matchStatus);
        assertNull(salt.itemId);
        assertEquals("MISMATCH", salt.suggestions.get(0).pack);
        assertTrue(v.issues.stream().anyMatch(i -> i.code.equals("PACK_SIZE_DIFFERS")));
    }

    @Test void editingAProductNameRematchesIt() throws Exception {
        InMemoryShop s = shop();
        InvoiceView v = scan("a_distributor_clean.png", s);
        int saltId = lineLike(v, "tata salt").lineId;
        assertEquals(1L, lineLike(v, "tata salt").itemId);
        InvoiceEdit vendorEdit = editFrom(v);
        vendorEdit.lines.stream().filter(l -> l.lineId == saltId).findFirst().orElseThrow().name = "Fortune Sunflower Oil 1 L";   // vendor fixes the text
        InvoiceView edited = InvoiceAssembler.applyEdit(v, vendorEdit, s.matcher(), s, TODAY);
        InvoiceLineDto row = edited.lines.stream().filter(l -> l.lineId == saltId).findFirst().orElseThrow();
        assertEquals(5L, row.itemId.longValue(), "the changed text is matched again, not left on the old product");
        assertEquals("MATCHED", row.matchStatus);
    }

    @Test void looseGoodsInKilogramsBecomePacks() throws Exception {
        InMemoryShop s = new InMemoryShop().item(1, "Sugar", "", "1 kg", 5, "48.00").item(2, "Rajma Chitra", "", "1 kg", 5, "130.00")
                .item(3, "Basmati Rice India Gate", "India Gate", "5 kg", 3, "650.00");
        InvoiceView v = scan("c_loose_goods.png", s);
        assertEquals(25, lineLike(v, "sugar").stockUnits, "25 kg of a 1 kg product = 25 packs");
        assertEquals(10, lineLike(v, "rajma").stockUnits);
        assertEquals(6, lineLike(v, "basmati").stockUnits, "6 bags of 5 kg = 6 packs");
    }
}
