package com.quickmart.invoice;

import com.quickmart.dto.InvoiceHeaderDto;
import com.quickmart.dto.InvoiceLineDto;
import com.quickmart.dto.IssueDto;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class InvoiceValidatorTest {
    private static final LocalDate TODAY = LocalDate.of(2026, 11, 16);
    private static final String GSTIN = "27AAPFU0939F1ZV";

    private static InvoiceLineDto line(int id, String name, String qty, String rate, String amount) {
        InvoiceLineDto l = new InvoiceLineDto();
        l.lineId = id; l.name = name; l.qty = new BigDecimal(qty); l.rate = rate == null ? null : new BigDecimal(rate);
        l.amount = amount == null ? null : new BigDecimal(amount);
        return l;
    }

    private static InvoiceHeaderDto header() {
        InvoiceHeaderDto h = new InvoiceHeaderDto();
        h.supplierName = "Shree Ganesh"; h.invoiceNumber = "INV-1"; h.invoiceDate = "2026-11-10"; h.gstin = GSTIN;
        return h;
    }

    private static boolean has(List<IssueDto> issues, String code) { return issues.stream().anyMatch(i -> i.code.equals(code)); }
    private static boolean has(List<IssueDto> issues, String code, Integer lineId) { return issues.stream().anyMatch(i -> i.code.equals(code) && java.util.Objects.equals(i.lineId, lineId)); }

    @Test void consistentInvoiceHasNoWarningsOrErrors() {
        InvoiceHeaderDto h = header();
        h.subtotal = new BigDecimal("1344.00"); h.cgst = new BigDecimal("33.60"); h.cgstRate = new BigDecimal("2.5");
        h.sgst = new BigDecimal("33.60"); h.sgstRate = new BigDecimal("2.5"); h.grandTotal = new BigDecimal("1411.20");
        List<IssueDto> r = InvoiceValidator.validate(h, List.of(line(1, "Tata Salt 1 kg", "6", "24.00", "144.00"), line(2, "Oil 1 L", "10", "120.00", "1200.00")), TODAY);
        assertTrue(r.stream().noneMatch(i -> i.isError() || i.isWarning()), r.toString());
    }

    @Test void quantityTimesRateMustEqualAmount() {
        List<IssueDto> r = InvoiceValidator.validate(header(), List.of(line(1, "Tata Salt", "6", "24.00", "150.00")), TODAY);
        assertTrue(has(r, "ARITHMETIC", 1));
    }

    @Test void discountAndGstExplainDifferences() {
        InvoiceLineDto d = line(1, "Butter", "24", "268.00", "6303.36"); d.discountPct = new BigDecimal("2");
        assertFalse(has(InvoiceValidator.validate(header(), List.of(d), TODAY), "ARITHMETIC"));
        InvoiceLineDto g = line(1, "Butter", "10", "100.00", "1050.00"); g.gstPct = new BigDecimal("5");
        assertFalse(has(InvoiceValidator.validate(header(), List.of(g), TODAY), "ARITHMETIC"));
    }

    @Test void invalidAndMissingProductInformationIsAnError() {
        InvoiceLineDto noName = line(1, "", "1", "10", "10"), zero = line(2, "Salt", "0", "10", "0"), huge = line(3, "Salt", "999999", "1", "999999");
        List<IssueDto> r = InvoiceValidator.validate(header(), List.of(noName, zero, huge), TODAY);
        assertTrue(has(r, "NAME_MISSING", 1));
        assertTrue(has(r, "QTY_INVALID", 2));
        assertTrue(has(r, "QTY_INVALID", 3));
        assertTrue(InvoiceValidator.validate(header(), List.of(), TODAY).stream().anyMatch(i -> i.code.equals("NO_LINES") && i.isError()));
    }

    @Test void skippedRowsAreNotValidated() {
        InvoiceLineDto junk = line(1, "", "0", null, null); junk.action = "SKIP";
        assertTrue(InvoiceValidator.validate(header(), List.of(junk), TODAY).stream().noneMatch(i -> i.lineId != null));
    }

    @Test void subtotalMustMatchTheRows() {
        InvoiceHeaderDto h = header(); h.subtotal = new BigDecimal("500.00");
        assertTrue(has(InvoiceValidator.validate(h, List.of(line(1, "Salt", "6", "24.00", "144.00")), TODAY), "SUBTOTAL_MISMATCH"));
    }

    @Test void grandTotalMustMatchSubtotalPlusTax() {
        InvoiceHeaderDto h = header(); h.subtotal = new BigDecimal("1000.00"); h.cgst = new BigDecimal("25.00"); h.sgst = new BigDecimal("25.00");
        h.cgstRate = new BigDecimal("2.5"); h.sgstRate = new BigDecimal("2.5"); h.grandTotal = new BigDecimal("1150.00");
        List<IssueDto> r = InvoiceValidator.validate(h, List.of(line(1, "Salt", "10", "100.00", "1000.00")), TODAY);
        assertTrue(has(r, "TOTAL_MISMATCH"));
        h.grandTotal = new BigDecimal("1050.00");
        assertFalse(has(InvoiceValidator.validate(h, List.of(line(1, "Salt", "10", "100.00", "1000.00")), TODAY), "TOTAL_MISMATCH"));
    }

    @Test void gstAmountsAreRecomputedFromRateAndTaxableValue() {
        InvoiceHeaderDto h = header(); h.subtotal = new BigDecimal("1000.00"); h.cgst = new BigDecimal("30.00"); h.cgstRate = new BigDecimal("2.5");
        List<IssueDto> r = InvoiceValidator.validate(h, List.of(line(1, "Salt", "10", "100.00", "1000.00")), TODAY);
        assertTrue(has(r, "GST_CALC"), "2.5% of 1000 is 25.00, not 30.00");
        h.cgst = new BigDecimal("25.00"); h.sgst = new BigDecimal("20.00"); h.sgstRate = new BigDecimal("2.5");
        assertTrue(has(InvoiceValidator.validate(h, List.of(line(1, "Salt", "10", "100.00", "1000.00")), TODAY), "GST_SPLIT"));
        h.cgstRate = new BigDecimal("7.3");
        assertTrue(has(InvoiceValidator.validate(h, List.of(line(1, "Salt", "10", "100.00", "1000.00")), TODAY), "GST_RATE"));
    }

    @Test void gstinFormatAndChecksumAreChecked() {
        InvoiceHeaderDto h = header(); h.gstin = "27AAPFU0939F1ZW";
        assertTrue(has(InvoiceValidator.validate(h, List.of(line(1, "Salt", "1", "1", "1")), TODAY), "GSTIN_CHECKSUM"));
        h.gstin = "NOTAGSTIN";
        assertTrue(has(InvoiceValidator.validate(h, List.of(line(1, "Salt", "1", "1", "1")), TODAY), "GSTIN_FORMAT"));
    }

    @Test void datesAreChecked() {
        InvoiceHeaderDto h = header();
        h.invoiceDate = "2027-02-01"; assertTrue(has(InvoiceValidator.validate(h, List.of(line(1, "Salt", "1", "1", "1")), TODAY), "DATE_FUTURE"));
        h.invoiceDate = "2024-01-01"; assertTrue(has(InvoiceValidator.validate(h, List.of(line(1, "Salt", "1", "1", "1")), TODAY), "DATE_OLD"));
        h.invoiceDate = "31/02/2026"; assertTrue(has(InvoiceValidator.validate(h, List.of(line(1, "Salt", "1", "1", "1")), TODAY), "DATE_INVALID"));
        h.invoiceDate = null; assertTrue(has(InvoiceValidator.validate(h, List.of(line(1, "Salt", "1", "1", "1")), TODAY), "DATE_MISSING"));
    }

    @Test void lowOcrConfidenceAndRepairedValuesAreFlagged() {
        InvoiceLineDto l = line(1, "Toor Dal", "30", "164.50", "4935.00"); l.ocrConfidence = 41.0; l.check = "REPAIRED";
        List<IssueDto> r = InvoiceValidator.validate(header(), List.of(l), TODAY);
        assertTrue(has(r, "LOW_OCR_CONFIDENCE", 1));
        assertTrue(has(r, "DECIMAL_REPAIRED", 1));
    }
}
