package com.quickmart.invoice;

import java.math.BigDecimal;
import java.util.*;

/** A tiny in-memory catalog + one shop's inventory + import ledger, used to test confirm logic without a database. */
public class InMemoryShop implements BillConfirmation.InventoryPort, BillConfirmation.ImportLedger {
    public final Map<Long, StockPlanner.ItemInfo> items = new LinkedHashMap<>();
    public final Map<Long, Integer> stock = new HashMap<>();
    public final Map<Long, BigDecimal> price = new HashMap<>();
    public final Map<String, String> files = new HashMap<>(), invoices = new HashMap<>();
    public int writes;                    // every mutation counts, so tests can assert "nothing was written"
    private long nextId = 100;

    public InMemoryShop item(long id, String name, String brand, String unitSize, Integer stockQty, String sellPrice) {
        items.put(id, new StockPlanner.ItemInfo(id, name, "Grocery", brand, unitSize));
        if (stockQty != null) { stock.put(id, stockQty); price.put(id, new BigDecimal(sellPrice)); }
        return this;
    }

    public ProductMatcher matcher() {
        List<ProductMatcher.Candidate> c = new ArrayList<>();
        for (StockPlanner.ItemInfo i : items.values()) c.add(new ProductMatcher.Candidate(i.id(), i.name(), i.brand(), i.unitSize(), i.category(), stock.containsKey(i.id()), stock.get(i.id())));
        return new ProductMatcher(c);
    }

    @Override public Optional<StockPlanner.ItemInfo> item(long id) { return Optional.ofNullable(items.get(id)); }
    @Override public Optional<StockPlanner.ItemInfo> byNormalizedName(String n) {
        return items.values().stream().filter(i -> StockPlanner.normalize(i.name()).equals(n)).findFirst();
    }
    @Override public Integer stockOf(long id) { return stock.get(id); }
    @Override public long createItem(String name, String category, String brand, String unitSize) {
        long id = nextId++; writes++;
        items.put(id, new StockPlanner.ItemInfo(id, name, category, brand, unitSize));
        return id;
    }
    @Override public void addStock(long id, int units) { writes++; stock.merge(id, units, Integer::sum); }
    @Override public void createStockRow(long id, BigDecimal p, int units) { writes++; stock.put(id, units); price.put(id, p); }
    @Override public void setPrice(long id, BigDecimal p) { writes++; price.put(id, p); }
    @Override public Optional<String> fileImportedOn(String h) { return Optional.ofNullable(files.get(h)); }
    @Override public Optional<String> invoiceImportedOn(String k) { return Optional.ofNullable(invoices.get(k)); }
    @Override public void record(String fileHash, String invoiceKey, String summary) {
        writes++;
        files.put(fileHash, "2026-11-16");
        if (invoiceKey != null) invoices.put(invoiceKey, "2026-11-16");
    }
}
