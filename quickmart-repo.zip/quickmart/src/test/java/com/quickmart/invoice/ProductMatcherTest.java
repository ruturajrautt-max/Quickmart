package com.quickmart.invoice;

import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class ProductMatcherTest {
    private static ProductMatcher.Candidate c(long id, String name, String brand, String unit) { return new ProductMatcher.Candidate(id, name, brand, unit, "Grocery", false, null); }

    private final ProductMatcher both = new ProductMatcher(List.of(c(1, "Tata Salt", "Tata", "1 kg"), c(2, "Tata Salt", "Tata", "500 g"),
            c(3, "Tata Sampann Unpolished Toor Dal", "Tata Sampann", "1 kg"), c(4, "Amul Butter Pasteurised", "Amul", "500 g"),
            c(5, "Parle-G Gold Biscuits", "Parle", "250 g"), c(6, "Tata Tea Gold", "Tata", "250 g")));
    private final ProductMatcher onlyOneKg = new ProductMatcher(List.of(c(1, "Tata Salt", "Tata", "1 kg")));

    @Test void caseSpacingAndPunctuationDoNotMatter() {
        ProductMatcher.Result a = both.match("Tata Salt 1kg", null), b = both.match("TATA SALT 1 KG", null), c = both.match("tata  salt, 1 Kg.", null);
        for (ProductMatcher.Result r : List.of(a, b, c)) {
            assertEquals(ProductMatcher.Status.MATCHED, r.status);
            assertEquals(1, r.best.candidate.id());
            assertTrue(r.best.confidence >= 0.99);
        }
    }

    @Test void halfKilogramPicksTheHalfKilogramProduct() {
        ProductMatcher.Result r = both.match("Tata Salt 500g", null);
        assertEquals(2, r.best.candidate.id());
        assertEquals("MATCH", r.best.pack);
    }

    @Test void halfKilogramMustNeverMatchTheOneKilogramProduct() {
        ProductMatcher.Result r = onlyOneKg.match("Tata Salt 500g", null);
        assertEquals(ProductMatcher.Status.UNMATCHED, r.status);
        assertNull(r.best, "a pack-size mismatch is never selected");
        assertEquals(1, r.suggestions.size(), "but it is offered as a suggestion...");
        assertEquals("MISMATCH", r.suggestions.get(0).pack);
        assertTrue(r.suggestions.get(0).confidence <= 0.5, "...with capped confidence");
        assertTrue(r.suggestions.get(0).reason.contains("500 g") && r.suggestions.get(0).reason.contains("1 kg"));
    }

    @Test void gramsAndKilogramsAreComparedByAmount() {
        assertEquals(ProductMatcher.Status.MATCHED, onlyOneKg.match("Tata Salt 1000 g", null).status);
    }

    @Test void packSizeFromASeparateColumnIsUsed() {
        ProductMatcher.Result r = both.match("Tata Salt", "500 g");
        assertEquals(2, r.best.candidate.id());
    }

    @Test void ocrSlipsInWordsAndSizesStillMatch() {
        assertEquals(5, both.match("Parie-G Gold Biscuits 250 g", null).best.candidate.id());
        assertEquals(1, both.match("Tata Salt lkg", null).best.candidate.id());
    }

    @Test void extraCatalogWordsAndWordOrderAreTolerated() {
        ProductMatcher.Result r = both.match("Tata Toor Dal 1 kg", null);
        assertEquals(3, r.best.candidate.id());
        assertEquals(ProductMatcher.Status.MATCHED, r.status);
        assertEquals(4, both.match("Butter Amul 500 g", null).best.candidate.id());
    }

    @Test void missingPackSizeOnOneSideRequiresReview() {
        ProductMatcher.Result r = onlyOneKg.match("Tata Salt", null);
        assertEquals(ProductMatcher.Status.REVIEW, r.status);
        assertEquals("UNKNOWN", r.best.pack);
        assertTrue(r.best.confidence < ProductMatcher.MATCHED_MIN);
    }

    @Test void aSingleCommonWordIsNeverAnAutomaticMatch() {
        assertNotEquals(ProductMatcher.Status.MATCHED, both.match("Salt", null).status);
    }

    @Test void similarSoundingDifferentProductsAreNotConfused() {
        ProductMatcher m = new ProductMatcher(List.of(c(1, "Malt Drink", "", "")));
        assertEquals(ProductMatcher.Status.UNMATCHED, m.match("Salt", null).status);
        assertEquals(ProductMatcher.Status.UNMATCHED, both.match("Surf Excel Easy Wash 1 kg", null).status);
    }

    @Test void unmatchedProductsStillGetSuggestions() {
        ProductMatcher.Result r = both.match("Tata Gold Tea Leaf 250 g", null);
        assertFalse(r.suggestions.isEmpty());
        assertEquals(6, r.suggestions.get(0).candidate.id());
    }

    @Test void levenshteinDistance() {
        assertEquals(0, ProductMatcher.levenshtein("salt", "salt"));
        assertEquals(1, ProductMatcher.levenshtein("parle", "parie"));
        assertEquals(3, ProductMatcher.levenshtein("kitten", "sitting"));
        assertEquals(4, ProductMatcher.levenshtein("", "abcd"));
    }
}
