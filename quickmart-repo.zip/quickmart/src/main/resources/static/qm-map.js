/* QuickMart map helpers: Leaflet (tiles from OpenStreetMap) + OSRM public server for road routes.
 * Needs Leaflet loaded first. Exposes window.QMMap. */
(function () {
  const OSRM = 'https://router.project-osrm.org/route/v1/driving/';
  const routeCache = {};                    // "lat,lng>lat,lng" -> { pts, km, min }  (so the 5 s refresh does not re-ask OSRM)
  const PUNE = [18.5204, 73.8567];

  const css = document.createElement('style');
  css.textContent = `
    .qm-pin span { display:flex; align-items:center; justify-content:center; width:32px; height:32px; border-radius:50%;
      background:#fff; border:2px solid #0c831f; font-size:17px; box-shadow:0 2px 6px rgba(0,0,0,.35); }
    .qm-pin.store span { width:24px; height:24px; font-size:13px; border-color:#94a3b8; opacity:.9; }
    .qm-pin.pick span { border-color:#ff8800; border-width:3px; }
    .qm-pin.rider span { border-color:#2563eb; }
    .qm-pin.me span { border-color:#ef4444; }
    .qm-pin.sel span { border-color:#ff8800; border-width:3px; width:36px; height:36px; }
    .qm-legend { font-size:12px; margin:6px 0 0; }
    .qm-legend i { display:inline-block; width:18px; height:0; border-top:4px solid; vertical-align:middle; margin:0 4px 0 8px; }
    .qm-legend i.o { border-color:#ff8800; border-top-style:dashed; } .qm-legend i.g { border-color:#0c831f; }`;
  document.head.appendChild(css);

  const esc = t => String(t ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const icon = (emoji, cls, size) => L.divIcon({ className: 'qm-pin ' + (cls || ''), html: `<span>${emoji}</span>`,
    iconSize: size || [32, 32], iconAnchor: [(size || [32, 32])[0] / 2, (size || [32, 32])[1] / 2] });
  const has = (a, b) => typeof a === 'number' && typeof b === 'number';

  function baseMap(el) {
    const map = L.map(el, { zoomControl: true, scrollWheelZoom: false }).setView(PUNE, 12);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', { maxZoom: 19, attribution: '&copy; OpenStreetMap' }).addTo(map);
    setTimeout(() => map.invalidateSize(), 0);   // modal / freshly inserted card may not have its final size yet
    return map;
  }

  /** Road route between two [lat,lng] points via OSRM; null if the server is unreachable. */
  async function osrmRoute(a, b) {
    const key = a.join(',') + '>' + b.join(',');
    if (routeCache[key]) return routeCache[key];
    try {
      const r = await fetch(`${OSRM}${a[1]},${a[0]};${b[1]},${b[0]}?overview=full&geometries=geojson`);
      const j = await r.json();
      if (j.code === 'OK' && j.routes && j.routes[0]) {
        const rt = { pts: j.routes[0].geometry.coordinates.map(c => [c[1], c[0]]), km: j.routes[0].distance / 1000, min: j.routes[0].duration / 60 };
        return (routeCache[key] = rt);
      }
    } catch (_) { /* offline / blocked -> straight line fallback */ }
    return null;
  }

  async function leg(map, a, b, style) {
    const rt = await osrmRoute(a, b);
    if (map._qmDead) return null;
    L.polyline(rt ? rt.pts : [a, b], Object.assign({ weight: 5, opacity: .85 }, style, rt ? {} : { dashArray: '2 8' })).addTo(map);
    return rt;
  }

  /**
   * One order: every active store (grey), the pickup store (orange ring), the customer's drop point,
   * the delivery partner, and road routes partner -> store (dashed orange) and store -> customer (green).
   * `o` is an OrderView from /api/orders. Returns the Leaflet map.
   */
  function drawDelivery(el, o, allStores) {
    const map = baseMap(el);
    const pts = [];
    (allStores || []).forEach(s => {
      if (!has(s.lat, s.lng)) return;
      const isPick = has(o.storeLat, o.storeLng) && Math.abs(s.lat - o.storeLat) < 1e-9 && Math.abs(s.lng - o.storeLng) < 1e-9;
      if (isPick) return;
      L.marker([s.lat, s.lng], { icon: icon('🏪', 'store', [24, 24]) }).addTo(map)
        .bindPopup(`<b>${esc(s.name)}</b><br>${esc(s.address || '')}`);
    });
    const store = has(o.storeLat, o.storeLng) ? [o.storeLat, o.storeLng] : null;
    const cust = has(o.custLat, o.custLng) ? [o.custLat, o.custLng] : null;
    const rider = has(o.partnerLat, o.partnerLng) && o.partnerName ? [o.partnerLat, o.partnerLng] : null;
    const toStore = !['PICKED_UP', 'DELIVERED', 'CANCELLED'].includes(o.status);

    if (store) { L.marker(store, { icon: icon('🏪', 'pick'), zIndexOffset: 500 }).addTo(map).bindPopup(`<b>Pick up: ${esc(o.storeName)}</b>`); pts.push(store); }
    if (cust) { L.marker(cust, { icon: icon('🏠'), zIndexOffset: 500 }).addTo(map).bindPopup(`<b>Deliver to ${esc(o.customerName)}</b><br>${esc(o.address)}`); pts.push(cust); }
    if (rider && o.status !== 'DELIVERED') {
      const at = toStore ? rider : (store || rider);                 // after pickup the rider is at the store, heading to the customer
      L.marker(at, { icon: icon('🛵', 'rider'), zIndexOffset: 800 }).addTo(map).bindPopup(`<b>${esc(o.partnerName)}</b><br>${toStore ? 'Heading to the store' : 'On the way to you'}`);
      pts.push(at);
    }
    if (pts.length) map.fitBounds(pts, { padding: [30, 30], maxZoom: 15 });

    const info = document.getElementById(el.id + '-info');
    const parts = [];
    const redraw = () => { if (info) info.innerHTML = parts.join(' · ') + `<div class="qm-legend">${rider && toStore ? '<i class="o"></i>partner → store' : ''}<i class="g"></i>store → you</div>`; };
    if (rider && store && toStore) leg(map, rider, store, { color: '#ff8800', dashArray: '10 8' }).then(r => { if (r) { parts.unshift(`🛵→🏪 ${r.km.toFixed(1)} km (~${Math.max(1, Math.round(r.min))} min)`); redraw(); } });
    if (store && cust && o.status !== 'CANCELLED') leg(map, store, cust, { color: '#0c831f' }).then(r => { if (r) { parts.push(`🏪→🏠 ${r.km.toFixed(1)} km (~${Math.max(1, Math.round(r.min))} min)`); redraw(); } });
    redraw();
    return map;
  }

  /** Store locator map. Returns { map, show(list), select(id) }; onPick(storeId) fires when a pin is clicked. */
  function storesMap(el, onPick, me) {
    const map = baseMap(el);
    let layer = L.layerGroup().addTo(map);
    const markers = {};
    if (me) L.marker(me, { icon: icon('📍', 'me') }).addTo(map).bindPopup('Your delivery area');
    function show(list, fit) {
      layer.clearLayers();
      Object.keys(markers).forEach(k => delete markers[k]);
      const pts = [];
      list.forEach(s => {
        if (!has(s.lat, s.lng)) return;
        const m = L.marker([s.lat, s.lng], { icon: icon('🏪', ''), title: s.name }).addTo(layer);
        m.bindPopup(`<b>${esc(s.name)}</b><br>${esc(s.address || '')}`);
        m.on('click', () => onPick && onPick(s.storeId));
        markers[s.storeId] = m; pts.push([s.lat, s.lng]);
      });
      if (me) pts.push(me);
      if (fit !== false && pts.length) map.fitBounds(pts, { padding: [30, 30], maxZoom: 15 });
    }
    function select(id) {
      Object.entries(markers).forEach(([k, m]) => m.setIcon(icon('🏪', String(k) === String(id) ? 'sel' : '', String(k) === String(id) ? [36, 36] : [32, 32])));
      if (markers[id]) { map.panTo(markers[id].getLatLng()); markers[id].openPopup(); }
    }
    return { map, show, select, refresh: () => map.invalidateSize() };
  }

  function destroy(map) { if (map) { map._qmDead = true; try { map.remove(); } catch (_) {} } }

  window.QMMap = { drawDelivery, storesMap, destroy, esc };
})();
