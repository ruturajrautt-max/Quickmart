package com.quickmart.repository;

import com.quickmart.model.Store;
import org.springframework.data.jpa.repository.JpaRepository;

public interface StoreRepository extends JpaRepository<Store, Long> {
    java.util.Optional<Store> findFirstByName(String name);
}
