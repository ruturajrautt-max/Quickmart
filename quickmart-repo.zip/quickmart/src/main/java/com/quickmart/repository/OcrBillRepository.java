package com.quickmart.repository;

import com.quickmart.model.OcrBill;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface OcrBillRepository extends JpaRepository<OcrBill, Long> {
    /** Every lookup carries the store id: a bill of another shop simply does not exist for this vendor. */
    Optional<OcrBill> findByBillIdAndStoreId(Long billId, Long storeId);
    Optional<OcrBill> findFirstByStoreIdAndFileHashOrderByBillIdDesc(Long storeId, String fileHash);
    List<OcrBill> findTop30ByStoreIdOrderByBillIdDesc(Long storeId);
}
