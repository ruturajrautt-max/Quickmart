package com.quickmart.repository;

import com.quickmart.model.StoreInventory;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.math.BigDecimal;

import java.util.List;

public interface StoreInventoryRepository
        extends JpaRepository<StoreInventory, StoreInventory.StoreInventoryId> {

    List<StoreInventory> findByItemIdAndStockQtyGreaterThan(Long itemId, Integer minQty);

    List<StoreInventory> findByStoreId(Long storeId);

    /** Atomic "stock = stock + n" in the database, so two bills or an order arriving at once cannot overwrite each other. Returns rows changed. */
    @Modifying(clearAutomatically = true, flushAutomatically = true)
    @Query("update StoreInventory s set s.stockQty = coalesce(s.stockQty, 0) + :units where s.storeId = :storeId and s.itemId = :itemId")
    int addStock(@Param("storeId") Long storeId, @Param("itemId") Long itemId, @Param("units") int units);

    @Modifying(clearAutomatically = true, flushAutomatically = true)
    @Query("update StoreInventory s set s.price = :price where s.storeId = :storeId and s.itemId = :itemId")
    int setPrice(@Param("storeId") Long storeId, @Param("itemId") Long itemId, @Param("price") BigDecimal price);
}
