package com.quickmart.repository;

import com.quickmart.model.PurchaseHistory;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface PurchaseHistoryRepository extends JpaRepository<PurchaseHistory, Long> {

    @Query(value = "SELECT item_id, quantity FROM purchase_history " +
            "WHERE user_id = :userId AND purchased_at >= DATE_SUB(NOW(), INTERVAL :days DAY)",
            nativeQuery = true)
    List<Object[]> findItemIdsByUserSince(@Param("userId") Long userId, @Param("days") int days);

    @Query(value = "SELECT item_id, quantity FROM purchase_history " +
            "WHERE user_id = :userId AND store_id = :storeId " +
            "AND purchased_at >= DATE_SUB(NOW(), INTERVAL :days DAY)",
            nativeQuery = true)
    List<Object[]> findItemIdsByUserAndStoreSince(@Param("userId") Long userId,
                                                    @Param("storeId") Long storeId,
                                                    @Param("days") int days);
}
