package com.quickmart.repository;

import com.quickmart.model.OrderStatusEvent;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface OrderStatusEventRepository extends JpaRepository<OrderStatusEvent, Long> {
    List<OrderStatusEvent> findByOrderIdOrderByEventIdAsc(Long orderId);
}
