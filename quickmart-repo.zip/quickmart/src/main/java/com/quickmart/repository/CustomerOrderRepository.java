package com.quickmart.repository;

import com.quickmart.model.CustomerOrder;
import com.quickmart.model.OrderStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Collection;
import java.util.List;

public interface CustomerOrderRepository extends JpaRepository<CustomerOrder, Long> {
    List<CustomerOrder> findByCustomerPhoneOrderByCreatedAtDesc(String phone);
    List<CustomerOrder> findByStoreIdOrderByCreatedAtDesc(Long storeId);
    List<CustomerOrder> findByPartnerIdOrderByCreatedAtDesc(Long partnerId);
    List<CustomerOrder> findByStatusOrderByCreatedAtAsc(OrderStatus status);
    List<CustomerOrder> findByPartnerIdIsNullAndStatusIn(Collection<OrderStatus> statuses);
}
