package com.quickmart.repository;

import com.quickmart.model.ApplicationStatus;
import com.quickmart.model.Vendor;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import java.util.Optional;

public interface VendorRepository extends JpaRepository<Vendor, Long> {
    Optional<Vendor> findByPhone(String phone);
    Optional<Vendor> findByStoreId(Long storeId);
    List<Vendor> findByStatus(ApplicationStatus status);
}
