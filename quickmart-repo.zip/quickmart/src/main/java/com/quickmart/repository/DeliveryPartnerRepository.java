package com.quickmart.repository;

import com.quickmart.model.ApplicationStatus;
import com.quickmart.model.DeliveryPartner;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import java.util.Optional;

public interface DeliveryPartnerRepository extends JpaRepository<DeliveryPartner, Long> {
    Optional<DeliveryPartner> findByPhone(String phone);
    List<DeliveryPartner> findByStatus(ApplicationStatus status);
    List<DeliveryPartner> findByStatusAndOnlineTrueAndBusyFalse(ApplicationStatus status);
}
