package com.quickmart.repository;

import com.quickmart.model.BillImport;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface BillImportRepository extends JpaRepository<BillImport, Long> {
    Optional<BillImport> findByStoreIdAndBillHash(Long storeId, String billHash);
    Optional<BillImport> findByStoreIdAndInvoiceKey(Long storeId, String invoiceKey);
}
