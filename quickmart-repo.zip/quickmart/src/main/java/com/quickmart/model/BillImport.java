package com.quickmart.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

/** One distributor bill that a vendor already added to their stock (stops the same bill being added twice). */
@Entity
@Table(name = "bill_imports", uniqueConstraints = {@UniqueConstraint(columnNames = {"store_id", "bill_hash"}),
        @UniqueConstraint(name = "uk_bill_imports_invoice", columnNames = {"store_id", "invoice_key"})})
public class BillImport {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "import_id")
    public Long importId;
    @Column(name = "store_id", nullable = false)
    public Long storeId;
    @Column(name = "bill_hash", nullable = false, length = 64)
    public String billHash;
    @Column(name = "imported_at")
    public LocalDateTime importedAt = LocalDateTime.now();
    public String summary;
    /** SHA-256 of supplier (GSTIN or name) + invoice number: catches a second PHOTO of an invoice already added. Null when unknown. */
    @Column(name = "invoice_key", length = 64)
    public String invoiceKey;
    /** The reviewed OCR bill this import came from (null for imports made with the older scan/apply endpoints). */
    @Column(name = "ocr_bill_id")
    public Long ocrBillId;
}
