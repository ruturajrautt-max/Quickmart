package com.quickmart.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import java.time.LocalDateTime;

/** A local shop that applied to sell on QuickMart. Once approved it gets a row in `stores`. */
@Entity
@Table(name = "vendors")
public class Vendor {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "vendor_id")
    public Long vendorId;
    public String shopName, ownerName, phone, email, address;
    public Double latitude, longitude;
    @JsonIgnore public String pinHash;
    @Enumerated(EnumType.STRING)
    public ApplicationStatus status = ApplicationStatus.PENDING;
    @Column(name = "store_id")
    public Long storeId;                       // set when approved
    public LocalDateTime appliedAt = LocalDateTime.now();
}
