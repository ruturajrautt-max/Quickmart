package com.quickmart.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "delivery_partners")
public class DeliveryPartner {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "partner_id")
    public Long partnerId;
    public String name, phone, vehicle;
    @JsonIgnore public String pinHash;
    @Enumerated(EnumType.STRING)
    public ApplicationStatus status = ApplicationStatus.PENDING;
    public Boolean online = false;
    public Boolean busy = false;               // true while holding an active delivery
    public Double latitude, longitude;         // last known location
    public LocalDateTime appliedAt = LocalDateTime.now();
}
