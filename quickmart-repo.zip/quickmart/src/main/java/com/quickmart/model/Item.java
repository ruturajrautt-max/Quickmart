package com.quickmart.model;

import jakarta.persistence.*;

@Entity
@Table(name = "items")
public class Item {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "item_id")
    private Long itemId;

    private String name;

    @Column(name = "normalized_name")
    private String normalizedName;

    private String category;
    private String brand;

    @Column(name = "unit_size")
    private String unitSize;

    public Item() {}

    public Item(String name, String category, String brand, String unitSize) {
        this.name = name;
        this.normalizedName = normalize(name);
        this.category = category;
        this.brand = brand;
        this.unitSize = unitSize;
    }

    public static String normalize(String raw) {
        return raw == null ? "" : raw.trim().toLowerCase().replaceAll("\\s+", " ");
    }

    // getters/setters
    public Long getItemId() { return itemId; }
    public void setItemId(Long itemId) { this.itemId = itemId; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; this.normalizedName = normalize(name); }
    public String getNormalizedName() { return normalizedName; }
    public String getCategory() { return category; }
    public void setCategory(String category) { this.category = category; }
    public String getBrand() { return brand; }
    public void setBrand(String brand) { this.brand = brand; }
    public String getUnitSize() { return unitSize; }
    public void setUnitSize(String unitSize) { this.unitSize = unitSize; }
}
