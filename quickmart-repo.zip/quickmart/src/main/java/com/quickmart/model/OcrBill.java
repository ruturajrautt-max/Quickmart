package com.quickmart.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

/**
 * One uploaded distributor bill and what OCR read from it. The vendor reviews and corrects it (view_json) and only a
 * confirmation turns it into stock: status EXTRACTED -> CONFIRMED. Scoped to one store, so a vendor can never see or
 * confirm another shop's bill.
 */
@Entity
@Table(name = "ocr_bills", indexes = @Index(name = "idx_ocr_bills_store_hash", columnList = "store_id, file_hash"))
public class OcrBill {
    public static final String EXTRACTED = "EXTRACTED", CONFIRMED = "CONFIRMED";

    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "bill_id")
    public Long billId;
    @Column(name = "store_id", nullable = false)
    public Long storeId;
    @Column(name = "vendor_id", nullable = false)
    public Long vendorId;
    @Column(name = "file_hash", nullable = false, length = 64)
    public String fileHash;                       // SHA-256 of the uploaded file
    @Column(name = "file_name", length = 255)
    public String fileName;
    @Column(name = "file_type", length = 8)
    public String fileType;                       // JPEG | PNG | PDF
    @Column(nullable = false, length = 16)
    public String status = EXTRACTED;
    @Column(name = "ocr_engine", length = 40)
    public String ocrEngine;
    @Column(name = "ocr_confidence")
    public Double ocrConfidence;
    @Column(name = "raw_text", columnDefinition = "LONGTEXT")
    public String rawText;
    @Column(name = "view_json", columnDefinition = "LONGTEXT")
    public String viewJson;                       // the latest (possibly vendor-edited) InvoiceView as JSON
    @Column(name = "created_at")
    public LocalDateTime createdAt = LocalDateTime.now();
    @Column(name = "updated_at")
    public LocalDateTime updatedAt = LocalDateTime.now();
    @Column(name = "confirmed_at")
    public LocalDateTime confirmedAt;
}
