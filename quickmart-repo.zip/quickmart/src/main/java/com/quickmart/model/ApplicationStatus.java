package com.quickmart.model;

public enum ApplicationStatus { PENDING, APPROVED, REJECTED }
