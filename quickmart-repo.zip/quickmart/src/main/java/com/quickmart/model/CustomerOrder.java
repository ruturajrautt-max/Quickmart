package com.quickmart.model;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;

/** One order = the items a customer buys from ONE store (a multi-store cart becomes several orders). */
@Entity
@Table(name = "customer_orders")
public class CustomerOrder {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "order_id")
    public Long orderId;
    public String customerName, customerPhone, address;
    public Double latitude, longitude;                       // drop location
    @Column(name = "store_id") public Long storeId;
    public String storeName;
    @Column(name = "partner_id") public Long partnerId;
    public Boolean partnerAccepted = false;
    public String declinedPartners = "";                     // CSV of partner ids that declined this order
    @Enumerated(EnumType.STRING)
    public OrderStatus status = OrderStatus.PLACED;
    public BigDecimal total = BigDecimal.ZERO;
    public Double pickupKm, routeKm;                         // partner -> store, store -> customer (Dijkstra)
    public String routePath;                                 // e.g. "FreshMart Kothrud > QuickBasket Deccan > Customer"
    public LocalDateTime createdAt = LocalDateTime.now();
}
