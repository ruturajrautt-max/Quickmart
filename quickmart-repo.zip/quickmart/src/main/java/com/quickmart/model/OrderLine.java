package com.quickmart.model;

import jakarta.persistence.*;
import java.math.BigDecimal;

@Entity
@Table(name = "order_lines")
public class OrderLine {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    public Long lineId;
    @Column(name = "order_id") public Long orderId;
    @Column(name = "item_id") public Long itemId;
    public String itemName;
    public Integer quantity;
    public BigDecimal price;
}
