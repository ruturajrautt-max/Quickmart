package com.quickmart.model;

public enum OrderStatus { PLACED, CONFIRMED, PREPARING, READY, PICKED_UP, DELIVERED, CANCELLED }
