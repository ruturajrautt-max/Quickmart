package com.quickmart.model;

import jakarta.persistence.*;
import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Objects;

@Entity
@Table(name = "store_inventory")
@IdClass(StoreInventory.StoreInventoryId.class)
public class StoreInventory {

    @Id
    @Column(name = "store_id")
    private Long storeId;

    @Id
    @Column(name = "item_id")
    private Long itemId;

    private BigDecimal price;

    @Column(name = "stock_qty")
    private Integer stockQty;

    @Column(name = "expiry_date")
    private LocalDate expiryDate;

    public StoreInventory() {}

    public StoreInventory(Long storeId, Long itemId, BigDecimal price, Integer stockQty, LocalDate expiryDate) {
        this.storeId = storeId;
        this.itemId = itemId;
        this.price = price;
        this.stockQty = stockQty;
        this.expiryDate = expiryDate;
    }

    // Composite primary key class
    public static class StoreInventoryId implements Serializable {
        private Long storeId;
        private Long itemId;

        public StoreInventoryId() {}
        public StoreInventoryId(Long storeId, Long itemId) {
            this.storeId = storeId;
            this.itemId = itemId;
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (!(o instanceof StoreInventoryId)) return false;
            StoreInventoryId that = (StoreInventoryId) o;
            return Objects.equals(storeId, that.storeId) && Objects.equals(itemId, that.itemId);
        }

        @Override
        public int hashCode() { return Objects.hash(storeId, itemId); }
    }

    // getters/setters
    public Long getStoreId() { return storeId; }
    public void setStoreId(Long storeId) { this.storeId = storeId; }
    public Long getItemId() { return itemId; }
    public void setItemId(Long itemId) { this.itemId = itemId; }
    public BigDecimal getPrice() { return price; }
    public void setPrice(BigDecimal price) { this.price = price; }
    public Integer getStockQty() { return stockQty; }
    public void setStockQty(Integer stockQty) { this.stockQty = stockQty; }
    public LocalDate getExpiryDate() { return expiryDate; }
    public void setExpiryDate(LocalDate expiryDate) { this.expiryDate = expiryDate; }
}
