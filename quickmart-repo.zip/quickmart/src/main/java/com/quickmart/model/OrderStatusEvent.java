package com.quickmart.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

/** One status change of an order; the rows are loaded into a StatusStack to read/undo history. */
@Entity
@Table(name = "order_status_events")
public class OrderStatusEvent {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    public Long eventId;
    @Column(name = "order_id") public Long orderId;
    @Enumerated(EnumType.STRING)
    public OrderStatus status;
    public String note;
    @Column(name = "event_at") public LocalDateTime at = LocalDateTime.now();

    public OrderStatusEvent() {}
    public OrderStatusEvent(Long orderId, OrderStatus status, String note) {
        this.orderId = orderId; this.status = status; this.note = note;
    }
}
