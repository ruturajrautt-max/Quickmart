package com.quickmart.invoice;

import com.quickmart.ocr.PackSize;

import java.util.*;

/**
 * Matches a product name read from a bill to the catalog. Pure Java, no Spring.
 *
 * Text score (0-1): bill words and catalog words are compared as sets (word order and extra catalog words such as
 * "Sampann Unpolished" must not matter). A word matches exactly, or approximately when it is within 1-2 edits
 * (Levenshtein, to absorb OCR slips like "Parie-G"), at reduced credit. Whole-name edit distance is a small tie-breaker.
 *
 * Pack size is a HARD rule, not a score tweak: "Tata Salt 500 g" and "Tata Salt 1 kg" are different products.
 *   same pack      -> bonus, may be auto-matched
 *   different pack -> never selected; offered only as a flagged suggestion with confidence capped at 50
 *   one side unknown -> capped below the auto-match threshold, so the vendor must look at it
 */
public final class ProductMatcher {

    public static final double MATCHED_MIN = 0.85, REVIEW_MIN = 0.55, SUGGEST_MIN = 0.35;
    private static final Set<String> STOP = Set.of("pack", "packet", "pkt", "pcs", "pc", "nos", "mrp", "rs", "inr", "net", "wt", "the", "of", "and", "with");

    public record Candidate(long id, String name, String brand, String unitSize, String category, boolean inStore, Integer stock) {}

    public enum Status { MATCHED, REVIEW, UNMATCHED }

    public static final class Suggestion {
        public final Candidate candidate;
        public final double confidence;           // 0-1
        public final String pack;                 // MATCH | MISMATCH | UNKNOWN
        public final String reason;
        Suggestion(Candidate c, double conf, String pack, String reason) { this.candidate = c; this.confidence = conf; this.pack = pack; this.reason = reason; }
    }

    public static final class Result {
        public final Suggestion best;             // null unless MATCHED or REVIEW
        public final Status status;
        public final List<Suggestion> suggestions;   // best first, at most 5
        Result(Suggestion best, Status status, List<Suggestion> s) { this.best = best; this.status = status; this.suggestions = s; }
    }

    private static final class Entry {
        final Candidate c; final List<String> tokens; final PackSize pack; final Set<String> brandTokens;
        Entry(Candidate c) {
            this.c = c;
            this.tokens = tokens(c.name());
            PackSize p = PackSize.find(c.unitSize());
            this.pack = p != null ? p : PackSize.find(c.name());
            this.brandTokens = c.brand() == null ? Set.of() : new HashSet<>(tokens(c.brand()));
        }
    }

    private final List<Entry> entries = new ArrayList<>();

    public ProductMatcher(Collection<Candidate> catalog) { for (Candidate c : catalog) entries.add(new Entry(c)); }

    /** @param packHint a pack size from a separate column ("500 g"); the name's own pack size is used when null */
    public Result match(String billName, String packHint) {
        List<String> bill = tokens(billName);
        PackSize billPack = PackSize.find(packHint);
        if (billPack == null) billPack = PackSize.find(billName);
        if (bill.isEmpty()) return new Result(null, Status.UNMATCHED, List.of());

        List<Suggestion> all = new ArrayList<>();
        for (Entry e : entries) {
            double text = textScore(bill, e);
            if (text < SUGGEST_MIN) continue;
            all.add(withPack(e, text, billPack, bill.size()));
        }
        all.sort(Comparator.comparingDouble((Suggestion s) -> -s.confidence).thenComparing(s -> s.candidate.name()));
        List<Suggestion> top = all.size() > 5 ? new ArrayList<>(all.subList(0, 5)) : all;

        Suggestion best = null;
        for (Suggestion s : all) if (!"MISMATCH".equals(s.pack)) { best = s; break; }     // a pack mismatch is never the answer
        Status st = best == null || best.confidence < REVIEW_MIN ? Status.UNMATCHED
                : best.confidence >= MATCHED_MIN ? Status.MATCHED : Status.REVIEW;
        if (st == Status.UNMATCHED) best = null;
        return new Result(best, st, top);
    }

    private Suggestion withPack(Entry e, double text, PackSize billPack, int billTokens) {
        double conf = text;
        String pack, reason;
        if (billPack != null && e.pack != null) {
            if (billPack.sameAs(e.pack)) { pack = "MATCH"; reason = "same pack size (" + e.pack.label() + ")"; conf = Math.min(1.0, conf + 0.06); }
            else { pack = "MISMATCH"; reason = "different pack size (bill " + billPack.label() + ", catalog " + e.pack.label() + ")"; conf = Math.min(conf, 0.5); }
        } else if (billPack == null && e.pack == null) {
            pack = "UNKNOWN"; reason = "no pack size on either side";
        } else {
            pack = "UNKNOWN";
            reason = billPack == null ? "bill has no pack size; catalog item is " + e.pack.label() : "catalog item has no pack size; bill says " + billPack.label();
            conf = Math.min(conf, 0.84);
        }
        if (billTokens < 2) conf = Math.min(conf, 0.84);                 // one word ("Salt") is never enough for an automatic match
        if (e.c.inStore() && !"MISMATCH".equals(pack)) conf = Math.min(1.0, conf + 0.02);
        return new Suggestion(e.c, conf, pack, reason);
    }

    // ───────────────────────── text similarity ─────────────────────────

    private static double textScore(List<String> bill, Entry e) {
        List<String> cat = e.tokens;
        if (cat.isEmpty()) return 0;
        boolean[] used = new boolean[cat.size()];
        double sum = 0;
        for (String b : bill) {
            int bestJ = -1; double bestSim = 0;
            for (int j = 0; j < cat.size(); j++) {
                if (used[j]) continue;
                double s = tokenSim(b, cat.get(j));
                if (s > bestSim) { bestSim = s; bestJ = j; }
            }
            if (bestJ >= 0) { used[bestJ] = true; sum += bestSim; }
        }
        double covBill = sum / bill.size(), covCat = sum / cat.size();
        double score = 0.72 * covBill + 0.28 * covCat;
        String a = String.join(" ", bill), b = String.join(" ", cat);
        score = 0.9 * score + 0.1 * (1.0 - (double) levenshtein(a, b) / Math.max(a.length(), b.length()));
        if (!e.brandTokens.isEmpty() && bill.containsAll(e.brandTokens)) score += 0.03;
        return Math.min(1.0, score);
    }

    static double tokenSim(String a, String b) {
        if (a.equals(b)) return 1.0;
        if (a.chars().allMatch(Character::isDigit) || b.chars().allMatch(Character::isDigit)) return 0;   // numbers must be exact ("7 Up")
        int len = Math.max(a.length(), b.length());
        if (len < 4 || Math.abs(a.length() - b.length()) > 2) return 0;
        int d = levenshtein(a, b);
        int allowed = len <= 7 ? 1 : 2;
        if (d > allowed) return 0;
        if (len == 4 && a.charAt(0) != b.charAt(0)) return 0;           // "salt" vs "malt"
        return d == 1 ? 0.88 : 0.78;
    }

    /** Lower-case words of the text without its pack size, stop words and punctuation. */
    static List<String> tokens(String text) {
        List<String> out = new ArrayList<>();
        if (text == null) return out;
        String t = PackSize.strip(text).toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]+", " ").trim();
        for (String w : t.split(" ")) if (!w.isEmpty() && !STOP.contains(w) && (w.length() >= 2 || Character.isDigit(w.charAt(0)))) out.add(w);
        return out;
    }

    /** Classic DP edit distance, O(n*m) time, two rows of memory. */
    public static int levenshtein(String a, String b) {
        int[] prev = new int[b.length() + 1], cur = new int[b.length() + 1];
        for (int j = 0; j <= b.length(); j++) prev[j] = j;
        for (int i = 1; i <= a.length(); i++) {
            cur[0] = i;
            for (int j = 1; j <= b.length(); j++) {
                int cost = a.charAt(i - 1) == b.charAt(j - 1) ? 0 : 1;
                cur[j] = Math.min(Math.min(cur[j - 1] + 1, prev[j] + 1), prev[j - 1] + cost);
            }
            int[] t = prev; prev = cur; cur = t;
        }
        return prev[b.length()];
    }
}
