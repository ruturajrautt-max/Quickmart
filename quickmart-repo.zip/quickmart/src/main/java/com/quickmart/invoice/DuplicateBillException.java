package com.quickmart.invoice;

/** This bill (same file, or same supplier + invoice number) was already added to the stock. */
public class DuplicateBillException extends RuntimeException {
    public final String kind;                     // FILE | INVOICE
    public final String importedOn;
    public DuplicateBillException(String kind, String importedOn, String message) { super(message); this.kind = kind; this.importedOn = importedOn; }
}
