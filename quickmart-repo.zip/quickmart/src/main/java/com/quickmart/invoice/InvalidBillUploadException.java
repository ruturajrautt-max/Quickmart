package com.quickmart.invoice;

/** The uploaded file cannot be processed as a bill. Carries the HTTP status that describes why. */
public class InvalidBillUploadException extends RuntimeException {
    public final int status;      // 400 empty, 413 too large, 415 wrong type, 422 unreadable / too small / blank
    public InvalidBillUploadException(int status, String message) { super(message); this.status = status; }
}
