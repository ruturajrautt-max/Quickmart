package com.quickmart.invoice;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.HexFormat;
import java.util.Locale;

/** SHA-256 helpers for duplicate-bill detection. */
public final class Hashing {
    private Hashing() {}

    public static String sha256(byte[] data) {
        try { return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(data)); }
        catch (java.security.NoSuchAlgorithmException e) { throw new IllegalStateException("SHA-256 is not available", e); }
    }

    public static String sha256(String s) { return sha256(s.getBytes(StandardCharsets.UTF_8)); }

    /**
     * Fingerprint of the INVOICE (not the file): supplier (GSTIN, else name) + invoice number. A second photo of the
     * same bill has a different file hash but the same key. Null when there is not enough information to say.
     */
    public static String invoiceKey(String gstin, String supplierName, String invoiceNumber) {
        String no = invoiceNumber == null ? "" : invoiceNumber.toUpperCase(Locale.ROOT).replaceAll("[^A-Z0-9]", "");
        String who = gstin != null && !gstin.isBlank() ? gstin.trim().toUpperCase(Locale.ROOT)
                : supplierName == null ? "" : supplierName.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]", "");
        if (no.length() < 3 || who.length() < 4) return null;
        return sha256(who + "|" + no);
    }
}
