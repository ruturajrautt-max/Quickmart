package com.quickmart.invoice;

import com.quickmart.dto.*;
import com.quickmart.ocr.BillScanner;
import com.quickmart.ocr.BillTextParser;
import com.quickmart.ocr.InvoiceHeader;
import com.quickmart.ocr.PackSize;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.*;

/** Builds and refreshes the vendor's editable view of a bill: header, rows, product matches, stock units, issues. */
public final class InvoiceAssembler {
    private InvoiceAssembler() {}

    /** OCR result -> view. Every row is matched against the catalog; nothing touches inventory. */
    public static InvoiceView fromScans(List<BillScanner.Scan> scans, ProductMatcher matcher, StockPlanner.Catalog catalog, LocalDate today) {
        InvoiceView v = new InvoiceView();
        InvoiceHeader merged = scans.get(0).header;
        for (int i = 1; i < scans.size(); i++) merged.fillFrom(scans.get(i).header);
        v.header = headerDto(merged);
        double conf = 0; int n = 0;
        int id = 1;
        for (BillScanner.Scan s : scans) {
            conf += s.confidence(); n++;
            for (BillTextParser.Line l : s.parsed.items) {
                InvoiceLineDto d = new InvoiceLineDto();
                d.lineId = id++;
                d.sourceText = l.source;
                d.name = l.name;
                d.qty = qty(l.qty);
                d.unit = l.unit;
                d.packSize = l.packSize == null ? null : l.packSize.label();
                d.rate = l.rate; d.amount = l.amount; d.discountPct = l.discountPct; d.gstPct = l.gstPct; d.hsn = l.hsn;
                d.check = l.check; d.arithmeticVerified = l.verified;
                d.ocrConfidence = round1(s.confidenceOf(l.source));
                matchLine(d, matcher, catalog, true);
                v.lines.add(d);
            }
            v.unreadable.addAll(s.parsed.unreadable);
        }
        v.ocrConfidence = round1(n == 0 ? 0 : conf / n);
        finish(v, catalog, today);
        return v;
    }

    /** The vendor's edits -> a fresh view with re-matched rows and re-run validation. Server-computed fields from the client are ignored. */
    public static InvoiceView applyEdit(InvoiceView current, InvoiceEdit edit, ProductMatcher matcher, StockPlanner.Catalog catalog, LocalDate today) {
        if (edit.header != null) {
            InvoiceHeaderDto h = edit.header;
            h.gstinChecksumValid = null;
            h.notes = current.header.notes;
            current.header = h;
        }
        Map<Integer, InvoiceLineDto> old = new HashMap<>();
        for (InvoiceLineDto l : current.lines) old.put(l.lineId, l);
        List<InvoiceLineDto> out = new ArrayList<>();
        int nextId = old.keySet().stream().max(Integer::compare).orElse(0) + 1;
        for (InvoiceLineDto e : edit.lines) {
            InvoiceLineDto prev = e.lineId == null ? null : old.get(e.lineId);
            InvoiceLineDto d = new InvoiceLineDto();
            d.lineId = prev != null ? prev.lineId : nextId++;                      // rows added by the vendor get new ids
            d.sourceText = prev == null ? null : prev.sourceText;
            d.ocrConfidence = prev == null ? null : prev.ocrConfidence;
            d.check = prev == null ? "MANUAL" : prev.check;
            d.name = trim(e.name); d.unit = trim(e.unit); d.packSize = trim(e.packSize); d.hsn = trim(e.hsn);
            d.qty = e.qty; d.rate = e.rate; d.amount = e.amount; d.discountPct = e.discountPct; d.gstPct = e.gstPct;
            d.action = trim(e.action); d.itemId = e.itemId; d.newCategory = trim(e.newCategory); d.newBrand = trim(e.newBrand);
            d.newUnitSize = trim(e.newUnitSize); d.sellingPrice = e.sellingPrice; d.packOverride = e.packOverride;
            d.arithmeticVerified = prev != null && prev.arithmeticVerified && Objects.equals(prev.qty, e.qty) && Objects.equals(prev.rate, e.rate)
                    && Objects.equals(prev.amount, e.amount);
            boolean nameEdited = prev != null && !Objects.equals(prev.name, d.name);
            if (nameEdited && Objects.equals(prev.packSize, d.packSize)) d.packSize = null;   // stale size of the OLD product text: read it from the new name
            boolean nameChanged = nameEdited || prev != null && !Objects.equals(prev.packSize, d.packSize);
            if (nameChanged && prev != null && Objects.equals(prev.itemId, e.itemId) && "ADD".equals(prev.action) && !"MANUAL".equals(prev.matchStatus)) {
                d.itemId = null; d.action = "";                                   // product text changed under an automatic match: match again
            }
            matchLine(d, matcher, catalog, false);
            out.add(d);
        }
        current.lines = out;
        finish(current, catalog, today);
        return current;
    }

    /** Suggestions for free text typed by the vendor ("search the catalog"). */
    public static List<SuggestionDto> suggest(String text, String packHint, ProductMatcher matcher, StockPlanner.Catalog catalog) {
        List<SuggestionDto> out = new ArrayList<>();
        for (ProductMatcher.Suggestion s : matcher.match(text, packHint).suggestions) out.add(toDto(s, catalog));
        return out;
    }

    // ───────────────────────── internals ─────────────────────────

    private static void matchLine(InvoiceLineDto d, ProductMatcher matcher, StockPlanner.Catalog catalog, boolean automaticDefaults) {
        ProductMatcher.Result r = matcher.match(d.name == null ? "" : d.name, d.packSize);
        d.suggestions = new ArrayList<>();
        for (ProductMatcher.Suggestion s : r.suggestions) d.suggestions.add(toDto(s, catalog));
        d.itemName = null; d.itemUnitSize = null; d.currentStock = null; d.matchConfidence = null;

        boolean skip = "SKIP".equalsIgnoreCase(d.action), create = "CREATE".equalsIgnoreCase(d.action);
        if (!skip && !create && d.itemId == null && (automaticDefaults || d.action == null || d.action.isBlank())) {
            if (r.best != null) {                                                 // automatic mapping, the vendor still reviews it
                d.itemId = r.best.candidate.id();
                d.action = "ADD";
                d.matchStatus = r.status.name();
                d.matchConfidence = round1(r.best.confidence * 100);
            } else {
                d.action = "";
                d.matchStatus = "UNMATCHED";
            }
        } else if (d.itemId != null && !skip && !create) {                       // the vendor chose a product: respect it
            d.action = "ADD";
            d.matchStatus = "MANUAL";
            for (ProductMatcher.Suggestion s : r.suggestions) if (s.candidate.id() == d.itemId) d.matchConfidence = round1(s.confidence * 100);
        } else {
            d.matchStatus = skip ? "SKIPPED" : create ? "NEW" : "UNMATCHED";
        }
        if (d.itemId != null) {
            StockPlanner.ItemInfo it = catalog.item(d.itemId).orElse(null);
            if (it != null) {
                d.itemName = it.name(); d.itemUnitSize = it.unitSize();
                d.currentStock = catalog.stockOf(it.id());
            }
        }
    }

    private static SuggestionDto toDto(ProductMatcher.Suggestion s, StockPlanner.Catalog catalog) {
        SuggestionDto x = new SuggestionDto();
        x.itemId = s.candidate.id(); x.name = s.candidate.name(); x.unitSize = s.candidate.unitSize();
        x.category = s.candidate.category(); x.brand = s.candidate.brand();
        x.confidence = round1(s.confidence * 100); x.pack = s.pack; x.reason = s.reason;
        x.currentStock = catalog.stockOf(s.candidate.id());
        return x;
    }

    /** Recomputes stock units and the full issue list. */
    public static void revalidate(InvoiceView v, StockPlanner.Catalog catalog, LocalDate today) { finish(v, catalog, today); }

    private static void finish(InvoiceView v, StockPlanner.Catalog catalog, LocalDate today) {
        StockPlanner.Plan plan = StockPlanner.plan(v.lines, catalog);
        for (InvoiceLineDto l : v.lines) l.stockUnits = plan.unitsByLine.get(l.lineId);
        List<IssueDto> all = new ArrayList<>(InvoiceValidator.validate(v.header, v.lines, today));
        all.addAll(plan.errors);
        for (InvoiceLineDto l : v.lines) {
            if ("REVIEW".equals(l.matchStatus)) {
                all.add(IssueDto.warn("REVIEW_MATCH", l.lineId, "itemId", "'" + l.name + "' was matched to '" + l.itemName + "' with only " + l.matchConfidence.intValue() + "% confidence. Check it is the right product."));
            }
            if ("UNMATCHED".equals(l.matchStatus)) {
                for (SuggestionDto s : l.suggestions) {
                    if ("MISMATCH".equals(s.pack)) {
                        all.add(IssueDto.info("PACK_SIZE_DIFFERS", l.lineId, "itemId", "The catalog has '" + s.name + "' (" + s.unitSize + ") but the bill's pack size is different, so it was not matched automatically."));
                        break;
                    }
                }
            }
        }
        if (v.ocrConfidence != null && v.ocrConfidence < 50) {
            all.add(IssueDto.warn("OCR_POOR", null, null, String.format("The text on this bill was read with only %.0f%% confidence. Check every row, or upload a sharper, well-lit, straight-on photo.", v.ocrConfidence)));
        }
        LinkedHashMap<String, IssueDto> dedup = new LinkedHashMap<>();
        for (IssueDto i : all) dedup.putIfAbsent(i.code + "|" + i.lineId + "|" + i.field, i);
        v.issues = new ArrayList<>(dedup.values());
        v.issues.sort(Comparator.comparingInt(i -> i.isError() ? 0 : i.isWarning() ? 1 : 2));
        v.errorCount = (int) v.issues.stream().filter(IssueDto::isError).count();
        v.warningCount = (int) v.issues.stream().filter(IssueDto::isWarning).count();
        v.canConfirm = v.errorCount == 0 && !"CONFIRMED".equals(v.status);
    }

    static InvoiceHeaderDto headerDto(InvoiceHeader h) {
        InvoiceHeaderDto d = new InvoiceHeaderDto();
        d.supplierName = h.supplierName; d.invoiceNumber = h.invoiceNumber;
        d.invoiceDate = h.invoiceDate == null ? null : h.invoiceDate.toString();
        d.gstin = h.gstin; d.gstinChecksumValid = h.gstin == null ? null : h.gstinChecksumValid;
        d.subtotal = h.subtotal; d.discountTotal = h.discountTotal; d.cgst = h.cgst; d.sgst = h.sgst; d.igst = h.igst; d.cess = h.cess;
        d.taxTotal = h.taxTotal; d.roundOff = h.roundOff; d.grandTotal = h.grandTotal;
        d.cgstRate = h.cgstRate; d.sgstRate = h.sgstRate; d.igstRate = h.igstRate;
        d.notes = new ArrayList<>(h.notes);
        return d;
    }

    private static BigDecimal qty(double q) { return BigDecimal.valueOf(q).stripTrailingZeros().scale() < 0 ? BigDecimal.valueOf(q).setScale(0) : BigDecimal.valueOf(q).stripTrailingZeros(); }
    private static Double round1(double d) { return Math.round(d * 10) / 10.0; }
    private static String trim(String s) { return s == null ? null : s.trim(); }
}
