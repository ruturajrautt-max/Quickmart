package com.quickmart.invoice;

import com.quickmart.dto.InvoiceHeaderDto;
import com.quickmart.dto.InvoiceLineDto;
import com.quickmart.dto.IssueDto;
import com.quickmart.ocr.GstinValidator;
import com.quickmart.ocr.UnitNormalizer;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

/**
 * Cross-checks what OCR read. Nothing is silently "fixed": every inconsistency becomes an issue.
 * ERROR blocks confirming; WARNING must be acknowledged by the vendor; INFO is just a remark.
 */
public final class InvoiceValidator {
    private InvoiceValidator() {}

    private static final Set<Double> GST_RATES = Set.of(0.0, 0.125, 0.25, 0.75, 1.0, 1.5, 2.5, 3.0, 5.0, 6.0, 9.0, 12.0, 14.0, 18.0, 20.0, 28.0, 40.0);
    public static final double LOW_OCR_CONFIDENCE = 70;

    public static List<IssueDto> validate(InvoiceHeaderDto h, List<InvoiceLineDto> lines, LocalDate today) {
        List<IssueDto> out = new ArrayList<>();
        if (lines == null || lines.isEmpty()) {
            out.add(IssueDto.error("NO_LINES", null, null, "No item rows were found on the bill. Add the rows by hand or upload a clearer photo."));
        } else {
            for (InvoiceLineDto l : lines) line(l, out);
        }
        header(h == null ? new InvoiceHeaderDto() : h, today, out);
        if (h != null && lines != null) totals(h, lines, out);
        return out;
    }

    // ───────────────────────── rows ─────────────────────────

    private static void line(InvoiceLineDto l, List<IssueDto> out) {
        if ("SKIP".equals(l.action)) return;
        Integer id = l.lineId;
        long letters = l.name == null ? 0 : l.name.chars().filter(Character::isLetter).count();
        if (letters < 2) out.add(IssueDto.error("NAME_MISSING", id, "name", "Product name is missing or unreadable."));
        if (l.qty == null || l.qty.signum() <= 0) out.add(IssueDto.error("QTY_INVALID", id, "qty", "Quantity must be greater than 0."));
        else {
            if (l.qty.compareTo(BigDecimal.valueOf(100_000)) > 0) out.add(IssueDto.error("QTY_INVALID", id, "qty", "Quantity " + l.qty.stripTrailingZeros().toPlainString() + " is not plausible."));
            else if (l.qty.compareTo(BigDecimal.valueOf(5_000)) > 0) out.add(IssueDto.warn("QTY_UNLIKELY", id, "qty", "Quantity " + l.qty.stripTrailingZeros().toPlainString() + " is unusually large; check for an OCR slip."));
        }
        String unit = UnitNormalizer.canonical(l.unit);
        if (l.unit != null && !l.unit.isBlank() && unit == null) out.add(IssueDto.info("UNIT_UNKNOWN", id, "unit", "Unit '" + l.unit + "' is not recognised and is ignored."));
        if ("box".equals(unit) || "case".equals(unit)) {
            out.add(IssueDto.warn("UNIT_AMBIGUOUS", id, "unit", "Unit is '" + unit + "'. Confirm the quantity counts packs of this product, not items inside the " + unit + "."));
        }
        if (l.rate == null || l.rate.signum() <= 0) out.add(IssueDto.warn("RATE_MISSING", id, "rate", "Rate is missing, so quantity x rate cannot be checked."));
        if ("REPAIRED".equals(l.check)) out.add(IssueDto.warn("DECIMAL_REPAIRED", id, "rate", "A decimal point was missing in the OCR text and was inserted because it made quantity x rate match. Please check the rate."));
        if (l.ocrConfidence != null && l.ocrConfidence < LOW_OCR_CONFIDENCE) {
            out.add(IssueDto.warn("LOW_OCR_CONFIDENCE", id, null, String.format("OCR confidence for this row is only %.0f%%. Check every value.", l.ocrConfidence)));
        }
        arithmetic(l, out);
    }

    private static void arithmetic(InvoiceLineDto l, List<IssueDto> out) {
        if (l.qty == null || l.rate == null || l.amount == null || l.qty.signum() <= 0 || l.rate.signum() <= 0) {
            if (l.amount == null && l.qty != null && l.rate != null) out.add(IssueDto.info("AMOUNT_MISSING", l.lineId, "amount", "Line amount was not read."));
            return;
        }
        BigDecimal base = l.qty.multiply(l.rate);
        BigDecimal disc = pct(l.discountPct), gst = pct(l.gstPct);
        BigDecimal[] candidates = {
                base,
                base.multiply(BigDecimal.ONE.subtract(disc)),
                base.multiply(BigDecimal.ONE.add(gst)),
                base.multiply(BigDecimal.ONE.subtract(disc)).multiply(BigDecimal.ONE.add(gst))};
        BigDecimal tol = l.amount.abs().multiply(new BigDecimal("0.005")).max(new BigDecimal("0.05"));
        for (BigDecimal c : candidates) if (c.subtract(l.amount).abs().compareTo(tol) <= 0) return;
        out.add(IssueDto.warn("ARITHMETIC", l.lineId, "amount", "Quantity x rate = " + money(base.multiply(BigDecimal.ONE.subtract(disc)))
                + " but the amount is " + money(l.amount) + ". One of quantity, rate or amount was probably misread."));
    }

    // ───────────────────────── header + totals ─────────────────────────

    private static void header(InvoiceHeaderDto h, LocalDate today, List<IssueDto> out) {
        if (blank(h.supplierName)) out.add(IssueDto.warn("SUPPLIER_MISSING", null, "supplierName", "Supplier name was not found."));
        if (blank(h.invoiceNumber)) out.add(IssueDto.warn("INVOICE_NUMBER_MISSING", null, "invoiceNumber", "Invoice number was not found. Without it the same invoice cannot be recognised if it is uploaded again as a different photo."));
        if (blank(h.invoiceDate)) out.add(IssueDto.warn("DATE_MISSING", null, "invoiceDate", "Invoice date was not found."));
        else {
            try {
                LocalDate d = LocalDate.parse(h.invoiceDate);
                if (d.isAfter(today.plusDays(1))) out.add(IssueDto.warn("DATE_FUTURE", null, "invoiceDate", "Invoice date " + d + " is in the future."));
                else if (d.isBefore(today.minusDays(400))) out.add(IssueDto.warn("DATE_OLD", null, "invoiceDate", "Invoice date " + d + " is more than a year old."));
            } catch (RuntimeException e) {
                out.add(IssueDto.warn("DATE_INVALID", null, "invoiceDate", "Invoice date '" + h.invoiceDate + "' is not a valid date (use yyyy-mm-dd)."));
            }
        }
        if (blank(h.gstin)) out.add(IssueDto.info("GSTIN_MISSING", null, "gstin", "Supplier GSTIN was not found."));
        else if (!GstinValidator.hasValidFormat(h.gstin.trim().toUpperCase())) out.add(IssueDto.warn("GSTIN_FORMAT", null, "gstin", "GSTIN '" + h.gstin + "' is not a valid GSTIN format."));
        else if (!GstinValidator.hasValidChecksum(h.gstin.trim().toUpperCase())) out.add(IssueDto.warn("GSTIN_CHECKSUM", null, "gstin", "GSTIN " + h.gstin + " fails its check digit, so a character is probably misread."));
        if (h.notes != null) for (String n : h.notes) out.add(IssueDto.info("HEADER_NOTE", null, null, n));
    }

    private static void totals(InvoiceHeaderDto h, List<InvoiceLineDto> lines, List<IssueDto> out) {
        BigDecimal lineSum = BigDecimal.ZERO;
        int counted = 0;
        for (InvoiceLineDto l : lines) if (l.amount != null) { lineSum = lineSum.add(l.amount); counted++; }
        BigDecimal one = BigDecimal.ONE;

        if (h.subtotal != null && counted > 0 && lineSum.subtract(h.subtotal).abs().compareTo(one) > 0) {
            out.add(IssueDto.warn("SUBTOTAL_MISMATCH", null, "subtotal", "Row amounts add up to " + money(lineSum) + " but the bill's sub-total is "
                    + money(h.subtotal) + " (difference " + money(lineSum.subtract(h.subtotal).abs()) + "). A row may be missing or misread."));
        }

        BigDecimal taxable = h.subtotal != null ? h.subtotal : (counted > 0 ? lineSum : null);
        BigDecimal tax = h.taxTotal != null ? h.taxTotal : zero(h.cgst).add(zero(h.sgst)).add(zero(h.igst)).add(zero(h.cess));
        boolean haveTax = h.taxTotal != null || h.cgst != null || h.sgst != null || h.igst != null || h.cess != null;

        if (h.grandTotal == null) {
            out.add(IssueDto.info("TOTAL_MISSING", null, "grandTotal", "Invoice total was not found."));
        } else if (taxable != null) {
            BigDecimal expected = taxable.add(tax).add(zero(h.roundOff)).subtract(h.subtotal != null ? zero(h.discountTotal) : BigDecimal.ZERO);
            boolean ok = expected.subtract(h.grandTotal).abs().compareTo(one) <= 0
                    || lineSum.subtract(h.grandTotal).abs().compareTo(one) <= 0                              // tax-inclusive rows
                    || lineSum.add(tax).add(zero(h.roundOff)).subtract(h.grandTotal).abs().compareTo(one) <= 0;
            if (!ok) {
                out.add(IssueDto.warn("TOTAL_MISMATCH", null, "grandTotal", "Sub-total " + money(taxable) + (haveTax ? " + tax " + money(tax) : "")
                        + (h.roundOff != null ? " + round-off " + money(h.roundOff) : "") + " = " + money(expected) + " but the invoice total is " + money(h.grandTotal) + "."));
            }
        }

        if (taxable != null) {
            gstPart("CGST", h.cgst, h.cgstRate, taxable, out);
            gstPart("SGST", h.sgst, h.sgstRate, taxable, out);
            gstPart("IGST", h.igst, h.igstRate, taxable, out);
        }
        if (h.cgst != null && h.sgst != null && h.cgst.subtract(h.sgst).abs().compareTo(new BigDecimal("0.02")) > 0) {
            out.add(IssueDto.warn("GST_SPLIT", null, "sgst", "CGST " + money(h.cgst) + " and SGST " + money(h.sgst) + " should be equal."));
        }
        if (h.igst != null && (h.cgst != null || h.sgst != null)) {
            out.add(IssueDto.warn("GST_MIX", null, "igst", "The bill shows IGST together with CGST/SGST; a bill normally has one or the other."));
        }
    }

    private static void gstPart(String name, BigDecimal amount, BigDecimal rate, BigDecimal taxable, List<IssueDto> out) {
        if (amount == null || rate == null) return;
        if (!GST_RATES.contains(rate.setScale(3, RoundingMode.HALF_UP).doubleValue())) {
            out.add(IssueDto.warn("GST_RATE", null, name.toLowerCase(), name + " rate " + rate.stripTrailingZeros().toPlainString() + "% is not a standard GST rate; check it."));
        }
        BigDecimal expected = taxable.multiply(rate).divide(BigDecimal.valueOf(100), 2, RoundingMode.HALF_UP);
        BigDecimal tol = expected.abs().multiply(new BigDecimal("0.005")).max(new BigDecimal("0.05"));
        if (expected.subtract(amount).abs().compareTo(tol) > 0) {
            out.add(IssueDto.warn("GST_CALC", null, name.toLowerCase(), name + " " + rate.stripTrailingZeros().toPlainString() + "% of " + money(taxable) + " is " + money(expected) + " but the bill shows " + money(amount) + "."));
        }
    }

    private static BigDecimal pct(BigDecimal p) { return p == null ? BigDecimal.ZERO : p.divide(BigDecimal.valueOf(100), 6, RoundingMode.HALF_UP); }
    private static BigDecimal zero(BigDecimal b) { return b == null ? BigDecimal.ZERO : b; }
    private static boolean blank(String s) { return s == null || s.isBlank(); }
    static String money(BigDecimal b) { return b.setScale(2, RoundingMode.HALF_UP).toPlainString(); }
}
