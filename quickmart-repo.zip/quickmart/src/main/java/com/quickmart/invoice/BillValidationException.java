package com.quickmart.invoice;

import com.quickmart.dto.IssueDto;

import java.util.List;

/** Confirming was refused because of ERROR issues, or because WARNINGs were not acknowledged. Nothing was written. */
public class BillValidationException extends RuntimeException {
    public final List<IssueDto> issues;
    public final boolean needsAcknowledgement;   // true when the only blockers are warnings
    public BillValidationException(String message, List<IssueDto> issues, boolean needsAcknowledgement) {
        super(message); this.issues = issues; this.needsAcknowledgement = needsAcknowledgement;
    }
}
