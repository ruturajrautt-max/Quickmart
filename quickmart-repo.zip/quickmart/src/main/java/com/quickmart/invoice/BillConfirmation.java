package com.quickmart.invoice;

import com.quickmart.dto.ConfirmResult;
import com.quickmart.dto.InvoiceEdit;
import com.quickmart.dto.IssueDto;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * The only code path that changes inventory from a bill, and it runs only for an explicit vendor confirmation.
 * Order of work:  1 duplicate checks  2 validate everything (nothing written)  3 record the import
 * 4 apply the plan.  Steps 1-2 reject the bill without touching the database; the Spring wrapper runs 3-4 in ONE
 * transaction, so a failure part-way (including a concurrent duplicate hitting the unique constraint in step 3)
 * rolls back everything.
 */
public final class BillConfirmation {
    private BillConfirmation() {}

    public interface InventoryPort extends StockPlanner.Catalog {
        long createItem(String name, String category, String brand, String unitSize);   // also makes it searchable
        void addStock(long itemId, int units);                                          // the shop's row exists
        void createStockRow(long itemId, BigDecimal sellingPrice, int units);
        void setPrice(long itemId, BigDecimal sellingPrice);
    }

    public interface ImportLedger {
        Optional<String> fileImportedOn(String fileHash);
        Optional<String> invoiceImportedOn(String invoiceKey);
        void record(String fileHash, String invoiceKey, String summary);
    }

    public static ConfirmResult confirm(InvoiceEdit edit, String fileHash, LocalDate today, InventoryPort inv, ImportLedger ledger) {
        if (edit == null || edit.lines == null || edit.lines.isEmpty()) throw new IllegalArgumentException("Send the reviewed rows to confirm.");

        Optional<String> sameFile = ledger.fileImportedOn(fileHash);
        if (sameFile.isPresent()) throw new DuplicateBillException("FILE", sameFile.get(), "This exact bill was already added to your stock on " + sameFile.get() + ".");
        String key = edit.header == null ? null : Hashing.invoiceKey(edit.header.gstin, edit.header.supplierName, edit.header.invoiceNumber);
        if (key != null) {
            Optional<String> sameInvoice = ledger.invoiceImportedOn(key);
            if (sameInvoice.isPresent()) throw new DuplicateBillException("INVOICE", sameInvoice.get(),
                    "Invoice " + edit.header.invoiceNumber + " from this supplier was already added on " + sameInvoice.get() + " (probably a different photo of the same bill).");
        }

        List<IssueDto> issues = new ArrayList<>(InvoiceValidator.validate(edit.header, edit.lines, today));
        StockPlanner.Plan plan = StockPlanner.plan(edit.lines, inv);
        issues.addAll(plan.errors);
        long errors = issues.stream().filter(IssueDto::isError).count(), warnings = issues.stream().filter(IssueDto::isWarning).count();
        if (errors > 0) throw new BillValidationException(errors + " problem(s) must be fixed before this bill can be added.", issues, false);
        if (warnings > 0 && !edit.acknowledgeWarnings) throw new BillValidationException(warnings + " warning(s) need your confirmation.", issues, true);

        int units = plan.changes.stream().mapToInt(p -> p.units).sum();
        ledger.record(fileHash, key, plan.changes.size() + " products, " + units + " units");     // before any stock write

        ConfirmResult res = new ConfirmResult();
        for (StockPlanner.Planned p : plan.changes) {
            ConfirmResult.Change c = new ConfirmResult.Change();
            c.name = p.displayName; c.unitsAdded = p.units;
            long itemId;
            if (p.itemId == null) {
                itemId = inv.createItem(p.newName, p.newCategory, p.newBrand, p.newUnitSize);
                inv.createStockRow(itemId, p.sellingPrice, p.units);
                c.created = true; c.oldStock = 0; c.newStock = p.units; res.productsCreated++;
            } else {
                itemId = p.itemId;
                if (p.oldStock == null) { inv.createStockRow(itemId, p.sellingPrice, p.units); c.oldStock = 0; c.newStock = p.units; }
                else {
                    inv.addStock(itemId, p.units);
                    if (p.sellingPrice != null) inv.setPrice(itemId, p.sellingPrice);
                    c.oldStock = p.oldStock; c.newStock = p.oldStock + p.units;
                }
                res.productsUpdated++;
            }
            c.itemId = itemId;
            res.changes.add(c);
            res.unitsAdded += p.units;
        }
        res.status = "CONFIRMED";
        res.message = "Stock updated: " + res.unitsAdded + " units across " + res.changes.size() + " product" + (res.changes.size() == 1 ? "" : "s")
                + (res.productsCreated > 0 ? " (" + res.productsCreated + " new)" : "") + ".";
        return res;
    }
}
