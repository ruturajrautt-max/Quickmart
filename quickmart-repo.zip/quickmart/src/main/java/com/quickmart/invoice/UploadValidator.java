package com.quickmart.invoice;

import javax.imageio.ImageIO;
import javax.imageio.ImageReader;
import javax.imageio.stream.ImageInputStream;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.Iterator;

/**
 * First line of defence for uploads: decide from the file's own bytes (not its name or declared type) whether it is
 * a JPEG, PNG or PDF, and reject empty, oversized, decompression-bomb and thumbnail-sized pictures before any OCR runs.
 */
public final class UploadValidator {
    private UploadValidator() {}

    public enum Kind { JPEG, PNG, PDF }

    public static final long MAX_BYTES = 10L * 1024 * 1024;
    public static final long MAX_PIXELS = 60_000_000L;
    public static final int MIN_WIDTH = 300, MIN_HEIGHT = 150;

    public static Kind check(byte[] d, long maxBytes) {
        if (d == null || d.length == 0) throw new InvalidBillUploadException(400, "The uploaded file is empty.");
        if (d.length > maxBytes) throw new InvalidBillUploadException(413, "The file is larger than " + (maxBytes / 1024 / 1024) + " MB. Upload a smaller photo or PDF.");
        Kind kind;
        if (d.length > 4 && d[0] == '%' && d[1] == 'P' && d[2] == 'D' && d[3] == 'F') kind = Kind.PDF;
        else if (d.length > 3 && (d[0] & 0xFF) == 0xFF && (d[1] & 0xFF) == 0xD8 && (d[2] & 0xFF) == 0xFF) kind = Kind.JPEG;
        else if (d.length > 8 && (d[0] & 0xFF) == 0x89 && d[1] == 'P' && d[2] == 'N' && d[3] == 'G') kind = Kind.PNG;
        else throw new InvalidBillUploadException(415, "Unsupported file type. Upload a JPG, JPEG, PNG or PDF bill.");
        if (kind != Kind.PDF) checkDimensions(d);
        return kind;
    }

    /** Reads only the image header, so a huge image is rejected without being decoded. */
    private static void checkDimensions(byte[] d) {
        try (ImageInputStream in = ImageIO.createImageInputStream(new ByteArrayInputStream(d))) {
            Iterator<ImageReader> it = ImageIO.getImageReaders(in);
            if (!it.hasNext()) throw new InvalidBillUploadException(422, "That image is damaged or in a format that cannot be read.");
            ImageReader r = it.next();
            try {
                r.setInput(in);
                int w = r.getWidth(0), h = r.getHeight(0);
                if ((long) w * h > MAX_PIXELS) throw new InvalidBillUploadException(422, "The image is too large (" + w + " x " + h + " pixels). Resize it and upload again.");
                if (w < MIN_WIDTH || h < MIN_HEIGHT) throw new InvalidBillUploadException(422, "The image is too small (" + w + " x " + h + " pixels) to read text from. Upload a larger photo.");
            } finally { r.dispose(); }
        } catch (IOException | RuntimeException e) {
            if (e instanceof InvalidBillUploadException ex) throw ex;
            throw new InvalidBillUploadException(422, "That image is damaged and cannot be read.");
        }
    }
}
