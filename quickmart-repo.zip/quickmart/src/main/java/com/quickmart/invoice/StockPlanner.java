package com.quickmart.invoice;

import com.quickmart.dto.InvoiceLineDto;
import com.quickmart.dto.IssueDto;
import com.quickmart.ocr.PackSize;
import com.quickmart.ocr.UnitNormalizer;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.*;

/**
 * Turns the vendor's confirmed lines into a list of exact inventory changes, or into errors. It writes nothing, so
 * every problem is found BEFORE the first database write; a bill is applied completely or not at all.
 *
 * Quantity normalisation: the stock unit is one pack of the product. A bill row in kg/g/l/ml is converted into packs
 * using the product's pack size ("25 kg" of a "1 kg" product = 25 packs); a count unit is taken as packs; "dozen" = 12.
 * The bill's rate is the vendor's COST price, so an existing selling price is changed only when the vendor types one.
 */
public final class StockPlanner {
    private StockPlanner() {}

    public record ItemInfo(long id, String name, String category, String brand, String unitSize) {}

    /** What the planner needs to know about the catalog and this shop's inventory. */
    public interface Catalog {
        Optional<ItemInfo> item(long id);
        Optional<ItemInfo> byNormalizedName(String normalizedName);
        /** This shop's stock of the product, or null when the shop has no inventory row for it. */
        Integer stockOf(long itemId);
    }

    public static final class Planned {
        public Long itemId;                                   // null = brand-new product
        public String newName, newCategory, newBrand, newUnitSize;
        public int units;
        public BigDecimal sellingPrice;                       // required for a new inventory row; optional change otherwise
        public Integer oldStock;                              // null = shop had no row
        public final List<Integer> lineIds = new ArrayList<>();
        public String displayName;
    }

    public static final class Plan {
        public final List<Planned> changes = new ArrayList<>();
        public final List<IssueDto> errors = new ArrayList<>();
        /** Packs to add, per line id (for display in the vendor table). */
        public final Map<Integer, Integer> unitsByLine = new HashMap<>();
    }

    public static String normalize(String s) { return s == null ? "" : s.trim().toLowerCase(Locale.ROOT).replaceAll("\\s+", " "); }

    public static Plan plan(List<InvoiceLineDto> lines, Catalog catalog) {
        Plan plan = new Plan();
        Map<String, Planned> merged = new LinkedHashMap<>();
        for (InvoiceLineDto l : lines) {
            String action = l.action == null || l.action.isBlank() ? (l.itemId != null ? "ADD" : "") : l.action.trim().toUpperCase(Locale.ROOT);
            if (action.equals("SKIP")) continue;
            Integer id = l.lineId;
            String label = l.name == null || l.name.isBlank() ? "row " + id : "'" + l.name.trim() + "'";

            ItemInfo item = null;
            boolean create = false;
            if (action.equals("ADD")) {
                if (l.itemId == null) { plan.errors.add(IssueDto.error("UNMAPPED", id, "itemId", "Choose the catalog product for " + label + ", create a new one, or skip the row.")); continue; }
                item = catalog.item(l.itemId).orElse(null);
                if (item == null) { plan.errors.add(IssueDto.error("ITEM_NOT_FOUND", id, "itemId", "The product chosen for " + label + " no longer exists in the catalog.")); continue; }
            } else if (action.equals("CREATE")) {
                String name = l.name == null ? "" : l.name.trim();
                String bare = PackSize.strip(name);                                  // the catalog keeps the size in unit_size, not in the name
                if (bare.chars().filter(Character::isLetter).count() >= 3) name = bare;
                if (name.chars().filter(Character::isLetter).count() < 2) { plan.errors.add(IssueDto.error("NAME_MISSING", id, "name", "Enter a product name for row " + id + ".")); continue; }
                item = catalog.byNormalizedName(normalize(name)).orElse(null);     // same name already in the catalog: add to it
                create = item == null;
            } else {
                plan.errors.add(IssueDto.error("UNMAPPED", id, "action", "Choose the catalog product for " + label + ", create a new one, or skip the row."));
                continue;
            }

            // pack size of the product this row will be stocked under, and of the row itself
            PackSize rowPack = PackSize.find(l.packSize);
            if (rowPack == null) rowPack = PackSize.find(l.name);
            PackSize targetPack = null;
            if (item != null) { targetPack = PackSize.find(item.unitSize()); if (targetPack == null) targetPack = PackSize.find(item.name()); }
            else { targetPack = PackSize.find(l.newUnitSize); if (targetPack == null) targetPack = rowPack; }

            if (item != null && rowPack != null && targetPack != null && !rowPack.sameAs(targetPack) && !l.packOverride) {
                plan.errors.add(IssueDto.error("PACK_MISMATCH", id, "packSize", label + " is " + rowPack.label() + " on the bill but the catalog product '" + item.name()
                        + "' is " + targetPack.label() + ". Pick the right pack size, create a new product, or confirm the difference is intended."));
                continue;
            }

            // quantity -> whole packs
            if (l.qty == null || l.qty.signum() <= 0) { plan.errors.add(IssueDto.error("QTY_INVALID", id, "qty", "Quantity for " + label + " must be greater than 0.")); continue; }
            String unit = UnitNormalizer.canonical(l.unit);
            double packs = l.qty.doubleValue();
            PackSize unitPack = UnitNormalizer.asPack(unit);
            if (unitPack != null && targetPack != null && unitPack.kind == targetPack.kind) {
                packs = l.qty.doubleValue() * unitPack.base / targetPack.base;
            } else if (unitPack != null && targetPack != null) {
                plan.errors.add(IssueDto.error("UNIT_MISMATCH", id, "unit", label + " is counted in " + unit + " but the product is sold as " + targetPack.label() + "."));
                continue;
            } else if ("dozen".equals(unit)) {
                packs = l.qty.doubleValue() * 12;
            }
            long whole = Math.round(packs);
            if (Math.abs(packs - whole) > 1e-6 || whole < 1) {
                plan.errors.add(IssueDto.error("QTY_NOT_WHOLE", id, "qty", label + ": " + l.qty.stripTrailingZeros().toPlainString() + (unit == null ? "" : " " + unit)
                        + " is " + trim(packs) + " packs of " + (targetPack == null ? "the product" : targetPack.label()) + ". Stock must be a whole number of packs; correct the quantity."));
                continue;
            }
            if (whole > 1_000_000) { plan.errors.add(IssueDto.error("QTY_INVALID", id, "qty", "Quantity for " + label + " is not plausible.")); continue; }

            String key;
            if (item != null) key = "i" + item.id(); else key = "n" + normalize(newNameOf(l));
            Planned p = merged.get(key);
            if (p == null) {
                p = new Planned();
                if (item != null) {
                    p.itemId = item.id(); p.displayName = item.name();
                    p.oldStock = catalog.stockOf(item.id());
                } else {
                    p.newName = newNameOf(l); p.displayName = p.newName;
                    p.newCategory = l.newCategory == null ? "" : l.newCategory.trim();
                    p.newBrand = l.newBrand == null ? "" : l.newBrand.trim();
                    p.newUnitSize = l.newUnitSize != null && !l.newUnitSize.isBlank() ? l.newUnitSize.trim()
                            : (rowPack != null ? rowPack.label() : (unitPack != null ? "1 " + unit : ""));
                    if (p.newCategory.isEmpty()) plan.errors.add(IssueDto.error("CATEGORY_REQUIRED", id, "newCategory", "Enter a category for the new product " + label + "."));
                }
                merged.put(key, p);
            }
            p.units += (int) whole;
            p.lineIds.add(id);
            if (l.sellingPrice != null && l.sellingPrice.signum() > 0) p.sellingPrice = l.sellingPrice.setScale(2, RoundingMode.HALF_UP);
            if (id != null) plan.unitsByLine.put(id, (int) whole);
        }

        for (Planned p : merged.values()) {
            boolean needsRow = p.itemId == null || p.oldStock == null;
            if (needsRow && (p.sellingPrice == null || p.sellingPrice.signum() <= 0)) {
                plan.errors.add(IssueDto.error("PRICE_REQUIRED", p.lineIds.isEmpty() ? null : p.lineIds.get(0), "sellingPrice",
                        "Enter your selling price for " + p.displayName + " (your shop has not stocked it before). The bill's rate is your cost price, not your selling price."));
            }
            plan.changes.add(p);
        }
        if (plan.changes.isEmpty() && plan.errors.isEmpty()) {
            plan.errors.add(IssueDto.error("NOTHING_TO_ADD", null, null, "Every row is skipped, so there is nothing to add to stock."));
        }
        return plan;
    }

    private static String newNameOf(InvoiceLineDto l) {
        String name = l.name.trim(), bare = PackSize.strip(name);
        return bare.chars().filter(Character::isLetter).count() >= 3 ? bare : name;
    }

    private static String trim(double d) {
        return Math.abs(d - Math.rint(d)) < 1e-9 ? String.valueOf((long) Math.rint(d)) : String.format(Locale.ROOT, "%.2f", d);
    }
}
