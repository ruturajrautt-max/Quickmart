package com.quickmart.ocr;

import java.awt.image.BufferedImage;
import java.util.HashMap;
import java.util.Map;

/**
 * image -> cleaned image -> OCR text -> invoice header + item rows.
 *
 * No single preprocessing is best for every photo, and phone photos are often sideways (the JPEG's EXIF rotation flag
 * is ignored by Java). So several attempts are made, cheapest and most likely first, and the first one that reads
 * well is used; if none does, the best-scoring attempt is returned and its rows are flagged for review:
 *   1. upright, GRAY          2. upright, BINARIZED (shadows, noise)       3. 90 / 270 / 180 degrees, GRAY
 *   4. the best orientation so far, BINARIZED
 * "Reads well" = at least one row and most rows pass the qty x rate = amount check, with decent OCR confidence.
 * The engine is injected, so this class has no Tess4J / Spring dependency and is tested with real Tesseract and with fakes.
 */
public final class BillScanner {

    public static final class Scan {
        public final OcrPage page;
        public final BillTextParser.Result parsed;
        public final InvoiceHeader header;
        public final int rotation;
        public final ImagePreprocessor.Variant variant;
        private final Map<String, Double> confByLine = new HashMap<>();

        Scan(OcrPage page, int rotation, ImagePreprocessor.Variant variant) {
            this.page = page; this.rotation = rotation; this.variant = variant;
            this.parsed = BillTextParser.parse(page.text());
            this.header = InvoiceHeaderParser.parse(page.text());
            for (OcrPage.Line l : page.lines) confByLine.put(l.text.strip(), l.confidence);
        }

        public String text() { return page.text(); }
        public double confidence() { return page.meanConfidence(); }
        /** OCR confidence (0-100) of the text line a row came from, or the page mean when unknown. */
        public double confidenceOf(String sourceLine) {
            Double c = sourceLine == null ? null : confByLine.get(sourceLine.strip());
            return c != null ? c : confidence();
        }
        int verified() { return (int) parsed.items.stream().filter(l -> l.verified).count(); }
        double score() {
            int headerHits = (header.invoiceNumber != null ? 1 : 0) + (header.grandTotal != null ? 1 : 0) + (header.gstin != null ? 1 : 0);
            long withAmount = parsed.items.stream().filter(l -> l.amount != null).count();   // rows with no amount are usually OCR garbage
            return verified() * 3 + withAmount + headerHits + confidence() / 10.0;
        }
        boolean good() {
            int n = parsed.items.size();
            return n >= 1 && verified() >= Math.ceil(n * 0.6) && confidence() >= 60;
        }
    }

    private BillScanner() {}

    public static Scan scan(BufferedImage original, OcrEngine engine) throws OcrException {
        BufferedImage base = ImagePreprocessor.normalize(original);
        Scan best = attempt(base, engine, ImagePreprocessor.Variant.GRAY, 0);
        if (best.good()) return best;

        best = better(best, attempt(base, engine, ImagePreprocessor.Variant.BINARIZED, 0));   // shadows / noise / uneven light
        if (best.good()) return best;
        if (best.parsed.items.size() >= 3 && best.confidence() >= 60) return best;           // upright and readable, just not reconcilable: do not rotate
        for (int deg : new int[]{90, 270, 180}) {           // sideways / upside-down photo
            best = better(best, attempt(base, engine, ImagePreprocessor.Variant.GRAY, deg));
            if (best.good()) return best;
        }
        if (best.variant != ImagePreprocessor.Variant.BINARIZED) {
            best = better(best, attempt(base, engine, ImagePreprocessor.Variant.BINARIZED, best.rotation));
        }
        return best;
    }

    private static Scan attempt(BufferedImage base, OcrEngine engine, ImagePreprocessor.Variant v, int rotation) throws OcrException {
        return new Scan(engine.read(ImagePreprocessor.enhance(base, v, rotation)), rotation, v);
    }

    private static Scan better(Scan a, Scan b) { return b.score() > a.score() ? b : a; }
}
