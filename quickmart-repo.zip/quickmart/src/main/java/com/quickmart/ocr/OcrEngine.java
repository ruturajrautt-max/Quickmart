package com.quickmart.ocr;

import java.awt.image.BufferedImage;

/** Something that reads text from an already-cleaned image. Implementations must be thread-safe. */
public interface OcrEngine {
    OcrPage read(BufferedImage image) throws OcrException;

    /** Short name for logs / health ("Tess4J", "tesseract command line"). */
    String name();
}
