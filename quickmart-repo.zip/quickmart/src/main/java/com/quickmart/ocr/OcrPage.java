package com.quickmart.ocr;

import java.util.ArrayList;
import java.util.List;

/** What an OCR engine read from one image: the text, line by line, with Tesseract's confidence (0-100). */
public final class OcrPage {
    public static final class Line {
        public final String text;
        public final double confidence;     // mean word confidence of the line, 0-100
        public Line(String text, double confidence) { this.text = text; this.confidence = confidence; }
    }

    public final List<Line> lines;
    public final String engine;             // "Tess4J" / "tesseract command line" / ...

    public OcrPage(List<Line> lines, String engine) { this.lines = List.copyOf(lines); this.engine = engine; }

    public String text() {
        StringBuilder sb = new StringBuilder();
        for (Line l : lines) sb.append(l.text).append('\n');
        return sb.toString();
    }

    /** Mean confidence over all lines, weighted by text length (long lines say more than a stray "|"). */
    public double meanConfidence() {
        double sum = 0; int n = 0;
        for (Line l : lines) { int w = Math.max(1, l.text.replaceAll("\\s", "").length()); sum += l.confidence * w; n += w; }
        return n == 0 ? 0 : sum / n;
    }

    public static OcrPage ofText(String text, double confidence, String engine) {
        List<Line> ls = new ArrayList<>();
        for (String s : text.split("\\r?\\n")) if (!s.isBlank()) ls.add(new Line(s.strip(), confidence));
        return new OcrPage(ls, engine);
    }
}
