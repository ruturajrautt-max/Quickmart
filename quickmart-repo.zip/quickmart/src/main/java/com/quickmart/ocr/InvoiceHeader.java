package com.quickmart.ocr;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/** Invoice-level fields read from the OCR text. Any field can be null: bills differ, and OCR misses things. */
public final class InvoiceHeader {
    public String supplierName, invoiceNumber, invoiceDateText;
    public LocalDate invoiceDate;
    public String gstin;                       // the supplier's, not the buyer's
    public boolean gstinChecksumValid, gstinRepaired;
    public List<String> otherGstins = new ArrayList<>();   // buyer / consignee GSTINs
    public BigDecimal subtotal, discountTotal, cgst, sgst, igst, cess, taxTotal, roundOff, grandTotal;
    public BigDecimal cgstRate, sgstRate, igstRate;
    public List<String> notes = new ArrayList<>();         // reading remarks, e.g. "date read as day/month"

    /** Merges a later page into this one: only fills what is still missing (totals prefer the later page). */
    public void fillFrom(InvoiceHeader o) {
        if (supplierName == null) supplierName = o.supplierName;
        if (invoiceNumber == null) invoiceNumber = o.invoiceNumber;
        if (invoiceDate == null) { invoiceDate = o.invoiceDate; invoiceDateText = o.invoiceDateText; }
        if (gstin == null) { gstin = o.gstin; gstinChecksumValid = o.gstinChecksumValid; gstinRepaired = o.gstinRepaired; }
        if (o.grandTotal != null) { grandTotal = o.grandTotal; }
        if (o.subtotal != null) subtotal = o.subtotal;
        if (o.cgst != null) { cgst = o.cgst; cgstRate = o.cgstRate; }
        if (o.sgst != null) { sgst = o.sgst; sgstRate = o.sgstRate; }
        if (o.igst != null) { igst = o.igst; igstRate = o.igstRate; }
        if (o.cess != null) cess = o.cess;
        if (o.roundOff != null) roundOff = o.roundOff;
        if (o.discountTotal != null) discountTotal = o.discountTotal;
        if (o.taxTotal != null) taxTotal = o.taxTotal;
        otherGstins.addAll(o.otherGstins);
        notes.addAll(o.notes);
    }
}
