package com.quickmart.ocr;

import java.awt.image.BufferedImage;

/**
 * Tries the primary engine (Tess4J) and uses the fallback (tesseract command line) when the primary cannot run.
 * A native-library failure (UnsatisfiedLinkError, JNA "Invalid memory access"...) marks the primary broken so it is
 * not retried on every image; an ordinary per-image failure only falls back for that image.
 */
public final class FallbackOcrEngine implements OcrEngine {
    private final OcrEngine primary, fallback;
    private volatile boolean primaryBroken;
    private volatile String primaryProblem = "";
    private volatile String lastUsed = "none yet";

    public FallbackOcrEngine(OcrEngine primary, OcrEngine fallback) { this.primary = primary; this.fallback = fallback; }

    @Override public String name() { return lastUsed; }

    @Override
    public OcrPage read(BufferedImage image) throws OcrException {
        OcrException primaryFailure = null;
        if (!primaryBroken) {
            try {
                OcrPage p = primary.read(image);
                lastUsed = primary.name();
                return p;
            } catch (OcrException e) {
                primaryProblem = e.getMessage();
                primaryFailure = e;
                if (e.reason == OcrException.Reason.ENGINE_UNAVAILABLE) primaryBroken = true;
            } catch (Error e) {                       // UnsatisfiedLinkError, NoClassDefFoundError, JNA errors
                primaryBroken = true;
                primaryProblem = e.getClass().getSimpleName() + ": " + e.getMessage();
            }
        }
        try {
            OcrPage p = fallback.read(image);
            lastUsed = fallback.name();
            return p;
        } catch (OcrException e) {
            String detail = primaryProblem.isEmpty() ? "" : " [" + primary.name() + ": " + primaryProblem + "]";
            throw new OcrException(e.reason, e.getMessage() + detail, e);
        }
    }

    public boolean primaryBroken() { return primaryBroken; }
    public String primaryProblem() { return primaryProblem; }
}
