package com.quickmart.ocr;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.*;
import java.util.concurrent.TimeUnit;

/**
 * Runs the plain `tesseract` executable and asks for TSV output, which carries a confidence per word.
 * Pure Java (no Tess4J / JNA), so it works even where the native Tess4J libraries do not load.
 * One process per image, so it is thread-safe.
 */
public final class TesseractCliEngine implements OcrEngine {
    private final String command;
    private final String datapath;        // folder with *.traineddata, or null for Tesseract's default
    private final String language;
    private final int psm;
    private final long timeoutSeconds;

    public TesseractCliEngine(String command, String datapath, String language, int psm, long timeoutSeconds) {
        this.command = command == null || command.isBlank() ? "tesseract" : command.trim();
        this.datapath = datapath == null || datapath.isBlank() ? null : datapath.trim();
        this.language = language == null || language.isBlank() ? "eng" : language.trim();
        this.psm = psm;
        this.timeoutSeconds = timeoutSeconds;
    }

    @Override public String name() { return "tesseract command line"; }

    @Override
    public OcrPage read(BufferedImage img) throws OcrException {
        File png = null, out = null, err = null;
        try {
            png = File.createTempFile("qm_ocr_", ".png");
            out = File.createTempFile("qm_ocr_", ".tsv");
            err = File.createTempFile("qm_ocr_", ".err");
            if (!ImageIO.write(img, "png", png)) throw new OcrException(OcrException.Reason.FAILED, "Could not encode the image for OCR");
            List<String> cmd = new ArrayList<>(List.of(command, png.getAbsolutePath(), "stdout", "-l", language, "--psm", String.valueOf(psm),
                    "-c", "preserve_interword_spaces=1", "-c", "user_defined_dpi=300"));
            if (datapath != null) { cmd.add("--tessdata-dir"); cmd.add(datapath); }
            cmd.add("tsv");
            ProcessBuilder pb = new ProcessBuilder(cmd).redirectOutput(out).redirectError(err);
            pb.environment().put("OMP_THREAD_LIMIT", "1");          // Tesseract's OpenMP threads fight each other and get slower
            Process p;
            try { p = pb.start(); }
            catch (IOException e) {
                throw new OcrException(OcrException.Reason.ENGINE_UNAVAILABLE,
                        "Cannot start '" + command + "'. Install Tesseract and put it on PATH, or set tesseract.command to the full path of tesseract.exe", e);
            }
            if (!p.waitFor(timeoutSeconds, TimeUnit.SECONDS)) {
                p.destroyForcibly();
                throw new OcrException(OcrException.Reason.TIMEOUT, "Tesseract did not finish within " + timeoutSeconds + " seconds");
            }
            String stderr = Files.readString(err.toPath(), StandardCharsets.UTF_8).trim();
            if (p.exitValue() != 0) {
                if (looksLikeMissingLanguage(stderr)) {
                    throw new OcrException(OcrException.Reason.LANGUAGE_DATA_MISSING, missingLanguageMessage(stderr));
                }
                throw new OcrException(OcrException.Reason.FAILED, "tesseract exited with code " + p.exitValue() + ": " + stderr);
            }
            return parseTsv(Files.readString(out.toPath(), StandardCharsets.UTF_8), name());
        } catch (IOException e) {
            throw new OcrException(OcrException.Reason.FAILED, "OCR I/O problem: " + e.getMessage(), e);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new OcrException(OcrException.Reason.FAILED, "OCR was interrupted", e);
        } finally {
            if (png != null) png.delete();
            if (out != null) out.delete();
            if (err != null) err.delete();
        }
    }

    private boolean looksLikeMissingLanguage(String stderr) {
        String s = stderr.toLowerCase(Locale.ROOT);
        return s.contains("error opening data file") || s.contains("failed loading language") || s.contains("could not initialize tesseract");
    }

    private String missingLanguageMessage(String stderr) {
        return "Tesseract cannot find the language data for '" + language + "' (" + language + ".traineddata)"
                + (datapath != null ? " in " + datapath : "")
                + ". Install it (Windows: re-run the UB-Mannheim installer and tick the language) or point tesseract.datapath at the tessdata folder. Detail: " + stderr;
    }

    /** TSV: level page block par line word left top width height conf text. Word rows have level 5. */
    static OcrPage parseTsv(String tsv, String engine) {
        Map<String, StringBuilder> text = new LinkedHashMap<>();
        Map<String, double[]> conf = new HashMap<>();       // sum, count
        Map<String, Integer> lastRight = new HashMap<>();
        for (String row : tsv.split("\\r?\\n")) {
            String[] c = row.split("\t", -1);
            if (c.length < 12 || !"5".equals(c[0])) continue;
            String word = c[11].strip();
            if (word.isEmpty()) continue;
            double cf;
            try { cf = Double.parseDouble(c[10]); } catch (NumberFormatException e) { continue; }
            if (cf < 0) continue;
            String key = c[2] + "." + c[3] + "." + c[4];
            int left = parse(c[6]), width = parse(c[8]);
            StringBuilder sb = text.computeIfAbsent(key, k -> new StringBuilder());
            if (sb.length() > 0) {
                int gap = left - lastRight.getOrDefault(key, left);
                sb.append(gap > 40 ? "   " : " ");                      // wide gaps (table columns) stay visible
            }
            sb.append(word);
            lastRight.put(key, left + width);
            double[] a = conf.computeIfAbsent(key, k -> new double[2]);
            a[0] += cf; a[1]++;
        }
        List<OcrPage.Line> lines = new ArrayList<>();
        for (Map.Entry<String, StringBuilder> e : text.entrySet()) {
            double[] a = conf.get(e.getKey());
            lines.add(new OcrPage.Line(e.getValue().toString(), a[1] == 0 ? 0 : a[0] / a[1]));
        }
        return new OcrPage(lines, engine);
    }

    private static int parse(String s) { try { return Integer.parseInt(s); } catch (NumberFormatException e) { return 0; } }

    // ───────────────────────── diagnostics (health endpoint) ─────────────────────────

    public static final class Diagnosis {
        public String version = "";
        public List<String> languages = new ArrayList<>();
        public String problem = "";          // empty = ok
    }

    public Diagnosis diagnose() {
        Diagnosis d = new Diagnosis();
        try {
            d.version = firstLine(run(List.of(command, "--version")));
            List<String> cmd = new ArrayList<>(List.of(command));
            if (datapath != null) { cmd.add("--tessdata-dir"); cmd.add(datapath); }
            cmd.add("--list-langs");
            for (String l : run(cmd).split("\\r?\\n")) {
                l = l.trim();
                if (!l.isEmpty() && !l.startsWith("List of")) d.languages.add(l);
            }
            for (String wanted : language.split("\\+")) {
                if (!d.languages.contains(wanted)) {
                    d.problem = "Language '" + wanted + "' is not installed (found: " + d.languages + ")";
                    break;
                }
            }
        } catch (Exception e) {
            d.problem = "Cannot run '" + command + "': " + e.getMessage();
        }
        return d;
    }

    private String run(List<String> cmd) throws IOException, InterruptedException {
        Process p = new ProcessBuilder(cmd).redirectErrorStream(true).start();
        byte[] all = p.getInputStream().readAllBytes();
        if (!p.waitFor(20, TimeUnit.SECONDS)) { p.destroyForcibly(); throw new IOException("timed out"); }
        return new String(all, StandardCharsets.UTF_8);
    }

    private static String firstLine(String s) { int i = s.indexOf('\n'); return (i < 0 ? s : s.substring(0, i)).trim(); }
}
