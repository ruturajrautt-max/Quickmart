package com.quickmart.ocr;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * A pack size such as "500 g", "1 KG", "1.5L", normalised to grams (MASS) or millilitres (VOLUME) so that
 * "1 kg" == "1000 g" == "1000GM" and "500 g" != "1 kg". Pure string logic, no Spring.
 */
public final class PackSize {
    public enum Kind { MASS, VOLUME }

    public final Kind kind;
    public final double base;          // grams or millilitres
    public final String text;          // as found, e.g. "500 g"
    public final int start, end;       // position inside the searched text

    private PackSize(Kind kind, double base, String text, int start, int end) {
        this.kind = kind; this.base = base; this.text = text; this.start = start; this.end = end;
    }

    // number, optional space, unit; the unit must not run into more letters ("2 LIFEBUOY" is not 2 litres)
    private static final Pattern P = Pattern.compile(
            "(?<![\\w.,])(\\d+(?:[.,]\\d+)?)\\s*(kilograms?|kilos?|kgs?|grams?|gms?|g|mg|millilit(?:er|re)s?|ml|lit(?:er|re)s?|ltrs?|l)(?![a-z0-9])",
            Pattern.CASE_INSENSITIVE);

    public static PackSize of(Kind kind, double base) {
        return new PackSize(kind, base, label(kind, base), -1, -1);
    }

    /** First pack size in the text, or null. */
    public static PackSize find(String text) {
        List<PackSize> all = findAll(text);
        return all.isEmpty() ? null : all.get(0);
    }

    public static List<PackSize> findAll(String text) {
        List<PackSize> out = new ArrayList<>();
        if (text == null) return out;
        Matcher m = P.matcher(repair(text));
        while (m.find()) {
            double v;
            try { v = Double.parseDouble(m.group(1).replace(',', '.')); } catch (NumberFormatException e) { continue; }
            if (v <= 0) continue;
            String u = m.group(2).toLowerCase(Locale.ROOT);
            Kind k; double base;
            if (u.startsWith("kilo") || u.startsWith("kg")) { k = Kind.MASS; base = v * 1000; }
            else if (u.equals("mg")) { k = Kind.MASS; base = v / 1000; }
            else if (u.startsWith("g")) { k = Kind.MASS; base = v; }
            else if (u.equals("ml") || u.startsWith("milli")) { k = Kind.VOLUME; base = v; }
            else { k = Kind.VOLUME; base = v * 1000; }                       // l, ltr, litre, liter
            out.add(new PackSize(k, base, m.group().trim(), m.start(), m.end()));
        }
        return out;
    }

    /** OCR reads the digit 1 as l / I / | right before a unit ("lkg"). Same-length replacement, so positions stay valid. */
    static String repair(String t) {
        return t.replaceAll("(?i)(?<![A-Za-z0-9])[lI|](?=\\s?(?:kgs?|gms?|ml|ltrs?)(?![a-z]))", "1");
    }

    /** The text with the first pack size cut out ("Tata Salt 1 kg" -> "Tata Salt"). */
    public static String strip(String text) {
        if (text == null) return "";
        return P.matcher(repair(text)).replaceAll(" ").replaceAll("\\s+", " ").trim();
    }

    /** Same kind and the same amount (0.5% tolerance for rounding such as 0.33 L vs 330 ml). */
    public boolean sameAs(PackSize o) {
        if (o == null || kind != o.kind) return false;
        double hi = Math.max(base, o.base);
        return Math.abs(base - o.base) <= hi * 0.005;
    }

    public String label() { return label(kind, base); }

    private static String label(Kind kind, double base) {
        boolean big = base >= 1000 && Math.abs(base / 1000 - Math.rint(base / 1000)) < 1e-9 || base >= 1500;
        if (kind == Kind.MASS) return big ? num(base / 1000) + " kg" : num(base) + " g";
        return big ? num(base / 1000) + " L" : num(base) + " ml";
    }

    private static String num(double d) {
        if (Math.abs(d - Math.rint(d)) < 1e-9) return String.valueOf((long) Math.rint(d));
        String s = String.format(Locale.ROOT, "%.3f", d);
        return s.replaceAll("0+$", "").replaceAll("\\.$", "");
    }

    @Override public String toString() { return label(); }
}
