package com.quickmart.ocr;

import net.sourceforge.tess4j.ITessAPI;
import net.sourceforge.tess4j.Tesseract;
import net.sourceforge.tess4j.TesseractException;
import net.sourceforge.tess4j.Word;

import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.List;

/**
 * Primary engine: Tess4J (JNA binding to libtesseract). Reads line by line so every line carries a confidence.
 * A new Tesseract instance per call because the Tess4J object is not thread-safe.
 * If the native library cannot load, an Error escapes and {@link FallbackOcrEngine} switches to the command line.
 */
public final class Tess4JEngine implements OcrEngine {
    private final String datapath;       // null = Tesseract default
    private final String language;
    private final int psm;

    public Tess4JEngine(String datapath, String language, int psm) {
        this.datapath = datapath == null || datapath.isBlank() ? null : datapath.trim();
        this.language = language == null || language.isBlank() ? "eng" : language.trim();
        this.psm = psm;
    }

    @Override public String name() { return "Tess4J"; }

    @Override
    public OcrPage read(BufferedImage img) throws OcrException {
        Tesseract t = new Tesseract();
        if (datapath != null) t.setDatapath(datapath);
        t.setLanguage(language);
        t.setPageSegMode(psm);
        t.setVariable("preserve_interword_spaces", "1");
        t.setVariable("user_defined_dpi", "300");
        try {
            List<Word> words = t.getWords(img, ITessAPI.TessPageIteratorLevel.RIL_TEXTLINE);
            List<OcrPage.Line> lines = new ArrayList<>();
            for (Word w : words) {
                String s = w.getText() == null ? "" : w.getText().strip();
                if (!s.isEmpty()) lines.add(new OcrPage.Line(s, Math.max(0, w.getConfidence())));
            }
            return new OcrPage(lines, name());
        } catch (TesseractException e) {
            String m = String.valueOf(e.getMessage());
            if (m.toLowerCase().contains("traineddata") || m.toLowerCase().contains("language")) {
                throw new OcrException(OcrException.Reason.LANGUAGE_DATA_MISSING,
                        "Tess4J cannot find language data for '" + language + "'. Set tesseract.datapath to the tessdata folder. Detail: " + m, e);
            }
            throw new OcrException(OcrException.Reason.FAILED, "Tess4J failed: " + m, e);
        }
    }
}
