package com.quickmart.ocr;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Indian GSTIN: 2-digit state code, 10-character PAN, entity number, 'Z', and a check character
 * (mod-36 weighted checksum, the same algorithm the GST portal uses). OCR often confuses O/0, I/1, S/5, B/8,
 * so {@link #findAll} repairs characters by position and only trusts a repaired value when its checksum is valid.
 */
public final class GstinValidator {
    private GstinValidator() {}

    private static final String CS = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    private static final Pattern STRICT = Pattern.compile("\\d{2}[A-Z]{5}\\d{4}[A-Z][1-9A-Z]Z[0-9A-Z]");
    private static final Pattern LOOSE = Pattern.compile("(?<![A-Za-z0-9])[0-9A-Za-z]{15}(?![A-Za-z0-9])");

    public static final class Found {
        public final String gstin;
        public final boolean checksumValid;
        public final boolean repaired;       // characters were corrected by position
        public final int index;              // match start in the searched text
        Found(String g, boolean ok, boolean repaired, int index) { this.gstin = g; this.checksumValid = ok; this.repaired = repaired; this.index = index; }
    }

    public static boolean hasValidFormat(String g) {
        if (g == null || !STRICT.matcher(g).matches()) return false;
        int state = Integer.parseInt(g.substring(0, 2));
        return state >= 1 && state <= 38 || state == 97 || state == 99;
    }

    public static boolean hasValidChecksum(String g) {
        if (!hasValidFormat(g)) return false;
        return checkChar(g.substring(0, 14)) == g.charAt(14);
    }

    public static char checkChar(String first14) {
        int sum = 0;
        for (int i = 0; i < 14; i++) {
            int p = CS.indexOf(first14.charAt(i)) * (i % 2 == 0 ? 1 : 2);
            sum += p / 36 + p % 36;
        }
        return CS.charAt((36 - sum % 36) % 36);
    }

    /** All GSTIN-looking tokens in the text, in order of appearance. */
    public static List<Found> findAll(String text) {
        List<Found> out = new ArrayList<>();
        if (text == null) return out;
        Matcher m = LOOSE.matcher(text);
        while (m.find()) {
            String raw = m.group().toUpperCase(Locale.ROOT);
            String fixed = repair(raw);
            if (hasValidFormat(fixed)) {
                if (!hasValidChecksum(fixed)) {                       // last character misread (O for 0, I for 1...)?
                    char want = checkChar(fixed.substring(0, 14));
                    if (confusable(fixed.charAt(14), want)) fixed = fixed.substring(0, 14) + want;
                }
                out.add(new Found(fixed, hasValidChecksum(fixed), !fixed.equals(raw), m.start()));
            }
        }
        return out;
    }

    // positions: 0-1 digit, 2-6 letter, 7-10 digit, 11 letter, 12 alnum (1-9/A-Z), 13 'Z', 14 check (alnum)
    private static String repair(String s) {
        StringBuilder b = new StringBuilder(s);
        for (int i = 0; i < 15; i++) {
            char c = b.charAt(i);
            boolean wantDigit = i < 2 || (i >= 7 && i <= 10);
            boolean wantLetter = (i >= 2 && i <= 6) || i == 11;
            if (wantDigit) b.setCharAt(i, toDigit(c));
            else if (wantLetter) b.setCharAt(i, toLetter(c));
            else if (i == 13) b.setCharAt(i, c == '2' ? 'Z' : c);
        }
        return b.toString();
    }

    private static boolean confusable(char seen, char want) {
        return seen != want && (toDigit(seen) == toDigit(want) || toLetter(seen) == toLetter(want));
    }

    private static char toDigit(char c) {
        return switch (c) { case 'O', 'Q', 'D' -> '0'; case 'I', 'L' -> '1'; case 'S' -> '5'; case 'B' -> '8'; case 'Z' -> '2'; case 'G' -> '6'; default -> c; };
    }

    private static char toLetter(char c) {
        return switch (c) { case '0' -> 'O'; case '1' -> 'I'; case '5' -> 'S'; case '8' -> 'B'; case '2' -> 'Z'; case '6' -> 'G'; default -> c; };
    }
}
