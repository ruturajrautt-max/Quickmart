package com.quickmart.ocr;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.geom.AffineTransform;
import java.awt.image.BufferedImage;
import java.awt.image.DataBufferByte;

/**
 * Cleans a bill photo before Tesseract sees it. Tesseract is trained on ~300 dpi scans; a raw phone photo is usually
 * too small, grey, uneven, slightly rotated or noisy, which is the main reason "OCR runs but reads garbage".
 *
 * Two variants are produced, because neither is best for every photo and the scanner keeps whichever reads better:
 *   GRAY       grayscale (transparent PNGs go on white) -> rescale to ~2400 px wide -> deskew -> contrast stretch -> border
 *   BINARIZED  grayscale -> rescale -> 3x3 median (noise removal) -> deskew -> contrast stretch
 *              -> adaptive (Bradley-Roth, local mean) threshold -> border
 * A global black/white threshold is deliberately never used: on photos with shadows it destroys digits.
 * Pure Java (java.awt), no OpenCV, so it runs the same on every machine and in unit tests.
 */
public final class ImagePreprocessor {
    public enum Variant { GRAY, BINARIZED }

    private static final int TARGET_WIDTH = 2400;   // upscale small images towards this
    private static final int MAX_WIDTH = 3600;      // shrink huge phone photos above this
    private static final int PAD = 30;
    private static final double MAX_SKEW_DEG = 12.0;

    private ImagePreprocessor() {}

    /** Default clean-up (GRAY variant). */
    public static BufferedImage prepare(BufferedImage src) { return prepare(src, Variant.GRAY); }

    public static BufferedImage prepare(BufferedImage src, Variant variant) {
        return enhance(normalize(src), variant, 0);
    }

    /** Step 1, shared by every attempt: grayscale and a sensible size. */
    public static BufferedImage normalize(BufferedImage src) { return rescale(toGray(src)); }

    /**
     * Step 2: turn by a multiple of 90 degrees if asked, then (per variant) denoise, straighten, stretch contrast,
     * remove table ruling lines, and optionally binarize with an adaptive threshold.
     * Rotation comes BEFORE deskew, because the skew search only makes sense on upright text.
     */
    public static BufferedImage enhance(BufferedImage normalized, Variant variant, int rotationDegrees) {
        BufferedImage img = rotationDegrees % 360 == 0 ? copyGray(normalized) : rotate(normalized, rotationDegrees);
        if (variant == Variant.BINARIZED) medianFilter3(img);
        double skew = estimateSkew(img);
        if (Math.abs(skew) >= 0.25) img = rotateByAngle(img, -skew);
        stretchContrast(img);
        byte[] px = px(img);
        int w = img.getWidth(), h = img.getHeight();
        byte[] bin = binarize(px, w, h);
        byte[] lines = rulingLines(bin, w, h);
        if (variant == Variant.BINARIZED) System.arraycopy(bin, 0, px, 0, px.length);
        for (int i = 0; i < px.length; i++) if (lines[i] != 0) px[i] = (byte) 255;      // erase table borders (they make Tesseract see a picture, not text)
        return pad(img);
    }

    /** True when the picture has (almost) no contrast at all: an empty page, a lens-cap photo, a white square. */
    public static boolean isBlank(BufferedImage src) {
        BufferedImage g = toGray(src.getWidth() > 800 ? resize(toGray(src), 800, Math.max(1, src.getHeight() * 800 / src.getWidth())) : src);
        int[] hist = histogram(px(g));
        long total = (long) g.getWidth() * g.getHeight(), cut = Math.max(1, total / 200), acc = 0;
        int lo = 0, hi = 255;
        for (int i = 0; i < 256; i++) { acc += hist[i]; if (acc >= cut) { lo = i; break; } }
        acc = 0;
        for (int i = 255; i >= 0; i--) { acc += hist[i]; if (acc >= cut) { hi = i; break; } }
        return hi - lo < 25;
    }

    // ───────────────────────── rotation ─────────────────────────

    /** Rotates by 90, 180 or 270 degrees clockwise (used when the photo is sideways / upside down). */
    public static BufferedImage rotate(BufferedImage img, int degrees) {
        int d = ((degrees % 360) + 360) % 360;
        if (d == 0) return img;
        if (d % 90 != 0) return rotateByAngle(img, d);
        boolean swap = d == 90 || d == 270;
        int w = img.getWidth(), h = img.getHeight();
        BufferedImage out = new BufferedImage(swap ? h : w, swap ? w : h, BufferedImage.TYPE_BYTE_GRAY);
        Graphics2D g = out.createGraphics();
        g.setColor(Color.WHITE);
        g.fillRect(0, 0, out.getWidth(), out.getHeight());
        AffineTransform t = new AffineTransform();
        t.translate(out.getWidth() / 2.0, out.getHeight() / 2.0);
        t.rotate(Math.toRadians(d));
        t.translate(-w / 2.0, -h / 2.0);
        g.drawImage(img, t, null);
        g.dispose();
        return out;
    }

    /** Rotates by any angle (degrees, clockwise positive), growing the canvas so nothing is cut off; new corners are white. */
    public static BufferedImage rotateByAngle(BufferedImage img, double degrees) {
        double rad = Math.toRadians(degrees), sin = Math.abs(Math.sin(rad)), cos = Math.abs(Math.cos(rad));
        int w = img.getWidth(), h = img.getHeight();
        int nw = (int) Math.ceil(w * cos + h * sin), nh = (int) Math.ceil(w * sin + h * cos);
        BufferedImage out = new BufferedImage(nw, nh, BufferedImage.TYPE_BYTE_GRAY);
        Graphics2D g = out.createGraphics();
        g.setColor(Color.WHITE);
        g.fillRect(0, 0, nw, nh);
        g.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BICUBIC);
        AffineTransform t = new AffineTransform();
        t.translate(nw / 2.0, nh / 2.0);
        t.rotate(rad);
        t.translate(-w / 2.0, -h / 2.0);
        g.drawImage(img, t, null);
        g.dispose();
        return out;
    }

    /**
     * Skew of the text lines in degrees (positive = lines run downhill to the right, so rotate by -skew to fix).
     * Projection profile: for each trial angle, project every dark pixel onto the "up" axis and measure how sharp the
     * row histogram is; text lines laid exactly horizontal give the sharpest peaks. Returns 0 when there is no clear winner.
     */
    public static double estimateSkew(BufferedImage gray) {
        int w = gray.getWidth(), h = gray.getHeight();
        int sw = Math.min(w, 900), sh = Math.max(1, (int) Math.round(h * (sw / (double) w)));
        BufferedImage small = sw == w ? gray : resize(gray, sw, sh);
        byte[] px = px(small);
        byte[] mean = boxMean(px, sw, sh, Math.max(7, sw / 30));
        int n = 0;
        int[] xs = new int[Math.min(sw * sh, 400_000)], ys = new int[xs.length];
        for (int y = 0; y < sh && n < xs.length; y++) {
            for (int x = 0; x < sw && n < xs.length; x++) {
                int i = y * sw + x;
                if ((px[i] & 0xFF) < (mean[i] & 0xFF) * 0.85) { xs[n] = x; ys[n] = y; n++; }   // ink = clearly darker than its surroundings
            }
        }
        if (n < 200) return 0;
        double base = sharpness(xs, ys, n, 0, sw, sh);
        double best = 0, bestScore = base;
        for (double a = -MAX_SKEW_DEG; a <= MAX_SKEW_DEG + 1e-9; a += 0.5) {
            double s = sharpness(xs, ys, n, a, sw, sh);
            if (s > bestScore) { bestScore = s; best = a; }
        }
        double fineBest = best;
        for (double a = best - 0.5; a <= best + 0.5 + 1e-9; a += 0.1) {
            double s = sharpness(xs, ys, n, a, sw, sh);
            if (s > bestScore) { bestScore = s; fineBest = a; }
        }
        if (Math.abs(fineBest) >= MAX_SKEW_DEG - 0.2) return 0;       // winner on the search boundary: ambiguous
        return bestScore > base * 1.03 ? fineBest : 0;                 // must be clearly better than "no skew"
    }

    private static double sharpness(int[] xs, int[] ys, int n, double deg, int w, int h) {
        double rad = Math.toRadians(deg), cos = Math.cos(rad), sin = Math.sin(rad);
        int off = (int) Math.ceil(w * Math.abs(sin)) + 2;
        int[] hist = new int[h + 2 * off + 2];
        for (int i = 0; i < n; i++) {
            int yy = (int) Math.round(ys[i] * cos - xs[i] * sin) + off;
            if (yy >= 0 && yy < hist.length) hist[yy]++;
        }
        double s = 0;
        for (int i = 1; i < hist.length; i++) { double d = hist[i] - hist[i - 1]; s += d * d; }
        return s;
    }

    // ───────────────────────── basic steps ─────────────────────────

    private static BufferedImage copyGray(BufferedImage g) {
        BufferedImage out = new BufferedImage(g.getWidth(), g.getHeight(), BufferedImage.TYPE_BYTE_GRAY);
        System.arraycopy(px(g), 0, px(out), 0, px(g).length);
        return out;
    }

    static BufferedImage toGray(BufferedImage src) {
        BufferedImage out = new BufferedImage(src.getWidth(), src.getHeight(), BufferedImage.TYPE_BYTE_GRAY);
        Graphics2D g = out.createGraphics();
        g.setColor(Color.WHITE);
        g.fillRect(0, 0, out.getWidth(), out.getHeight());   // transparent areas become white, not black
        g.drawImage(src, 0, 0, null);
        g.dispose();
        return out;
    }

    static BufferedImage rescale(BufferedImage img) {
        int w = img.getWidth();
        if (w >= TARGET_WIDTH * 0.8 && w <= MAX_WIDTH) return img;
        double target = w < TARGET_WIDTH ? Math.min(TARGET_WIDTH, w * 4.0) : 3000.0;
        BufferedImage cur = img;
        while (cur.getWidth() > target * 2) cur = resize(cur, cur.getWidth() / 2, cur.getHeight() / 2);  // halve = less aliasing
        double f = target / cur.getWidth();
        return resize(cur, Math.max(1, (int) Math.round(cur.getWidth() * f)), Math.max(1, (int) Math.round(cur.getHeight() * f)));
    }

    static BufferedImage resize(BufferedImage src, int w, int h) {
        BufferedImage out = new BufferedImage(w, h, BufferedImage.TYPE_BYTE_GRAY);
        Graphics2D g = out.createGraphics();
        g.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BICUBIC);
        g.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
        g.drawImage(src, 0, 0, w, h, null);
        g.dispose();
        return out;
    }

    /** Linear stretch so the darkest 1% maps to black and the brightest 1% to white. */
    static void stretchContrast(BufferedImage gray) {
        byte[] px = px(gray);
        int[] hist = histogram(px);
        long cut = Math.max(1, px.length / 100);
        int lo = 0, hi = 255;
        long acc = 0;
        for (int i = 0; i < 256; i++) { acc += hist[i]; if (acc >= cut) { lo = i; break; } }
        acc = 0;
        for (int i = 255; i >= 0; i--) { acc += hist[i]; if (acc >= cut) { hi = i; break; } }
        if (hi - lo < 20) return;                      // blank / already flat image: leave alone
        byte[] lut = new byte[256];
        for (int i = 0; i < 256; i++) lut[i] = (byte) Math.max(0, Math.min(255, (i - lo) * 255 / (hi - lo)));
        for (int i = 0; i < px.length; i++) px[i] = lut[px[i] & 0xFF];
    }

    /** 3x3 median filter: removes salt-and-pepper / sensor noise while keeping stroke edges sharp. Edge pixels are left as they are. */
    static void medianFilter3(BufferedImage gray) {
        int w = gray.getWidth(), h = gray.getHeight();
        byte[] src = px(gray), dst = src.clone();
        int[] v = new int[9];
        for (int y = 1; y < h - 1; y++) {
            for (int x = 1; x < w - 1; x++) {
                int k = 0, i = y * w + x;
                for (int dy = -1; dy <= 1; dy++) for (int dx = -1; dx <= 1; dx++) v[k++] = src[i + dy * w + dx] & 0xFF;
                for (int a = 1; a < 9; a++) { int t = v[a], b = a - 1; while (b >= 0 && v[b] > t) { v[b + 1] = v[b]; b--; } v[b + 1] = t; }
                dst[i] = (byte) v[4];
            }
        }
        System.arraycopy(dst, 0, src, 0, src.length);
    }

    /**
     * Bradley-Roth adaptive threshold: a pixel becomes black when it is clearly darker than the mean of its own
     * neighbourhood, so a shadow across one corner of the bill does not turn that corner black.
     */
    static void adaptiveThreshold(BufferedImage gray) {
        byte[] px = px(gray);
        System.arraycopy(binarize(px, gray.getWidth(), gray.getHeight()), 0, px, 0, px.length);
    }

    static byte[] binarize(byte[] px, int w, int h) {
        byte[] mean = boxMean(px, w, h, Math.max(15, w / 64));       // window ~ 3 text lines; tuned on the sample set (see tests)
        byte[] out = new byte[px.length];
        for (int i = 0; i < px.length; i++) out[i] = (byte) ((px[i] & 0xFF) < (mean[i] & 0xFF) * 0.80 ? 0 : 255);
        return out;
    }

    /**
     * Marks (1) the pixels of long straight black runs in a binary image: the ruling lines of a table or form.
     * A run counts as a line when it is much longer than any letter stroke (about 8% of the width horizontally,
     * about 5% of the width vertically). Gaps of up to 2 pixels are bridged (noise, JPEG), and a slightly tilted
     * line still has long runs in every row it touches.
     */
    static byte[] rulingLines(byte[] bin, int w, int h) {
        byte[] mark = new byte[bin.length];
        int minH = Math.max(80, w / 12), minV = Math.max(60, w / 20), maxGap = 2;
        for (int y = 0; y < h; y++) {                                  // horizontal
            int runStart = -1, lastBlack = -1;
            for (int x = 0; x <= w; x++) {
                boolean black = x < w && bin[y * w + x] == 0;
                if (black) { if (runStart < 0) runStart = x; lastBlack = x; }
                else if (runStart >= 0 && (x == w || x - lastBlack > maxGap)) {
                    if (lastBlack - runStart + 1 >= minH) for (int k = runStart; k <= lastBlack; k++) mark[y * w + k] = 1;
                    runStart = -1;
                }
            }
        }
        int[] start = new int[w], last = new int[w];                   // vertical, scanning row by row
        java.util.Arrays.fill(start, -1);
        for (int y = 0; y <= h; y++) {
            for (int x = 0; x < w; x++) {
                boolean black = y < h && bin[y * w + x] == 0;
                if (black) { if (start[x] < 0) start[x] = y; last[x] = y; }
                else if (start[x] >= 0 && (y == h || y - last[x] > maxGap)) {
                    if (last[x] - start[x] + 1 >= minV) for (int k = start[x]; k <= last[x]; k++) mark[k * w + x] = 1;
                    start[x] = -1;
                }
            }
        }
        return mark;
    }

    /** Mean of the (2r+1)x(2r+1) window around every pixel, using running sums (O(w*h) time, O(w) extra memory). */
    static byte[] boxMean(byte[] px, int w, int h, int r) {
        byte[] out = new byte[px.length];
        int[] col = new int[w];
        int top = 0, bottom = -1;                      // rows currently inside the window: [top, bottom]
        for (int y = 0; y < h; y++) {
            int newBottom = Math.min(h - 1, y + r), newTop = Math.max(0, y - r);
            while (bottom < newBottom) { bottom++; int o = bottom * w; for (int x = 0; x < w; x++) col[x] += px[o + x] & 0xFF; }
            while (top < newTop) { int o = top * w; for (int x = 0; x < w; x++) col[x] -= px[o + x] & 0xFF; top++; }
            int rows = bottom - top + 1;
            long sum = 0; int lo = 0, hi = -1;         // columns currently inside the window: [lo, hi]
            for (int x = 0; x < w; x++) {
                int nh = Math.min(w - 1, x + r), nl = Math.max(0, x - r);
                while (hi < nh) { hi++; sum += col[hi]; }
                while (lo < nl) { sum -= col[lo]; lo++; }
                out[y * w + x] = (byte) (sum / ((long) rows * (hi - lo + 1)));
            }
        }
        return out;
    }

    private static BufferedImage pad(BufferedImage img) {
        BufferedImage out = new BufferedImage(img.getWidth() + 2 * PAD, img.getHeight() + 2 * PAD, BufferedImage.TYPE_BYTE_GRAY);
        Graphics2D g = out.createGraphics();
        g.setColor(Color.WHITE);
        g.fillRect(0, 0, out.getWidth(), out.getHeight());
        g.drawImage(img, PAD, PAD, null);
        g.dispose();
        return out;
    }

    private static byte[] px(BufferedImage gray) { return ((DataBufferByte) gray.getRaster().getDataBuffer()).getData(); }

    private static int[] histogram(byte[] px) {
        int[] hist = new int[256];
        for (byte b : px) hist[b & 0xFF]++;
        return hist;
    }
}
