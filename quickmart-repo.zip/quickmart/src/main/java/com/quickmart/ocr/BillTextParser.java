package com.quickmart.ocr;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Turns raw OCR text of a bill / invoice into (name, qty, rate, amount) rows. Pure string logic, no Spring.
 *
 * Why not one big regex (the old approach): real bills have extra columns (serial no, HSN code, unit, GST %),
 * and OCR glues, drops or misreads numbers. Instead of guessing which column is which, we use arithmetic:
 *
 *     a row is "verified" when some  qty x rate = amount  holds among the numbers on the line.
 *
 * That also tells us which number is the quantity, ignoring HSN codes, sizes ("500 g") and serial numbers.
 * Rows where the arithmetic does not hold (OCR damaged a digit) are still returned but flagged
 * verified=false so the UI can ask the user to double-check them.
 */
public final class BillTextParser {

    public static final class Line {
        public final String name;
        public final double qty;
        public final BigDecimal rate;      // unit price on the bill, may be null
        public final BigDecimal amount;    // line total on the bill, may be null
        public final boolean verified;     // qty x rate (x discount / GST) = amount confirmed
        public final String source;        // original OCR line (for debugging / display)
        public final String unit;          // canonical unit column ("pcs", "kg", "box"...) or null
        public final PackSize packSize;    // pack size found in the product name ("500 g"), or null
        public final BigDecimal discountPct, gstPct;   // only set when the arithmetic confirmed which percentage is which
        public final String hsn;           // HSN/SAC code if the row had one
        public final String check;         // how the row was verified: EXACT, DISCOUNT, GST, DISCOUNT+GST, APPROX or NONE

        Line(String name, double qty, BigDecimal rate, BigDecimal amount, boolean verified, String source) {
            this(name, qty, rate, amount, verified, source, null, null, null, null, null, verified ? "EXACT" : "NONE");
        }

        Line(String name, double qty, BigDecimal rate, BigDecimal amount, boolean verified, String source,
             String unit, PackSize packSize, BigDecimal discountPct, BigDecimal gstPct, String hsn, String check) {
            this.name = name; this.qty = qty; this.rate = rate; this.amount = amount; this.verified = verified; this.source = source;
            this.unit = unit; this.packSize = packSize; this.discountPct = discountPct; this.gstPct = gstPct; this.hsn = hsn; this.check = check;
        }
    }

    public static final class Result {
        public final List<Line> items = new ArrayList<>();
        public final List<String> unreadable = new ArrayList<>();   // text lines that looked like products but had no usable numbers
    }

    // Lines that are never products. Word boundaries matter: the old pattern ".*cash.*" threw away "Cashew Nuts".
    private static final Pattern NOISE = Pattern.compile(
            "\\b(sub\\s*-?\\s*total|grand\\s*total|total|gstin|gst|cgst|sgst|igst|cess|vat|tax|invoice|bill\\s*(?:no|number)"
          + "|round\\s*off|discount|thanks?|visit\\s+again|upi|paytm|gpay|phonepe|paid|balance|change|cash|amount\\s+in\\s+words"
          + "|signature|authori[sz]ed|e\\s*&\\s*o\\s*e|ifsc|fssai|tel|phone|mobile|mob|email|www|page\\s+\\d+)\\b"
          + "|\\bdated?\\s*[:.]|\\d{1,2}[-/.]\\d{1,2}[-/.]\\d{2,4}", Pattern.CASE_INSENSITIVE);
    private static final Pattern TOTAL = Pattern.compile("\\b(sub\\s*-?\\s*total|grand\\s*total|total)\\b", Pattern.CASE_INSENSITIVE);
    private static final Pattern HEAD_A = Pattern.compile("\\b(qty|quantity|qnty|description|particulars|items?)\\b", Pattern.CASE_INSENSITIVE);
    private static final Pattern HEAD_B = Pattern.compile("\\b(rate|price|mrp|amount|amt|total)\\b", Pattern.CASE_INSENSITIVE);
    private static final Pattern HEAD_QTY = Pattern.compile("\\b(qty|quantity|qnty)\\b", Pattern.CASE_INSENSITIVE);
    private static final Pattern HEAD_RATE = Pattern.compile("\\b(rate|price|mrp)\\b", Pattern.CASE_INSENSITIVE);
    private static final Pattern NUM = Pattern.compile("\\d+(?:\\.\\d+)?");
    private static final Pattern NUM_CORE = Pattern.compile("^[^A-Za-z0-9]*(\\d+(?:\\.\\d+)?)[^A-Za-z0-9]*$");
    private static final Set<String> SIZE_UNITS = Set.of("g", "gm", "gms", "gram", "grams", "kg", "kgs", "ml", "l", "ltr", "ltrs",
            "litre", "litres", "liter", "liters", "mg", "oz", "lb");
    private static final Set<String> COUNT_UNITS = Set.of("pcs", "pc", "nos", "no", "box", "boxes", "pkt", "pkts", "pack", "packs",
            "dz", "doz", "case", "ctn", "bag", "btl", "unit", "units", "each", "ea");

    private BillTextParser() {}

    private static final class Cand {
        List<String> tokens;          // name tokens (still including a possible leading serial / qty number)
        boolean leadSmallInt;         // first token looks like a serial number or a quantity
        boolean leadQtyForm;          // line looked like "<qty> <name> <price>"
        int leadVal = -1;             // value of that leading number
        double qty; BigDecimal rate, amount; boolean verified; String source;
        String unit, hsn, check = "NONE"; BigDecimal discountPct, gstPct;
    }

    public static Result parse(String ocrText) {
        Result res = new Result();
        if (ocrText == null) return res;
        List<Cand> cands = new ArrayList<>();
        boolean headerSeen = false, qtyFirst = true, strict = false;
        List<String> pctOrder = List.of();            // which percentage column comes first in the header: DISC / GST

        for (String raw : ocrText.split("\\r?\\n")) {
            String line = raw.trim();
            if (line.length() < 3) continue;

            if (isHeader(line)) {
                if (!headerSeen) cands.clear();            // everything above the column titles is address / shop name
                headerSeen = true;
                Matcher q = HEAD_QTY.matcher(line), r = HEAD_RATE.matcher(line);
                if (q.find() && r.find()) qtyFirst = q.start() < r.start();
                pctOrder = percentColumns(line);
                continue;
            }
            if (NOISE.matcher(line).find()) {
                if (TOTAL.matcher(line).find() && !cands.isEmpty()) strict = true;   // after the total only fully verified rows count
                continue;
            }

            Cand c = parseLine(normalize(line), qtyFirst, line, percents(line), pctOrder);
            if (c == null || (strict && !c.verified)) {
                if (c == null && letters(line) >= 4 && res.unreadable.size() < 20) res.unreadable.add(line);
                continue;
            }
            cands.add(c);
        }

        // Is there a serial-number column? Most rows must start with a small integer AND those integers must count 1, 2, 3...
        // (otherwise "2 Butter 556.00 / 3 Bread 120.00" would be mistaken for serial numbers instead of quantities).
        int lead = 0, pairs = 0, seq = 0, prev = -1, firstLead = -1;
        for (Cand c : cands) {
            if (!c.leadSmallInt) continue;
            lead++;
            if (firstLead < 0) firstLead = c.leadVal;
            if (prev >= 0) { pairs++; if (c.leadVal == prev + 1) seq++; }
            prev = c.leadVal;
        }
        boolean serialLayout = cands.size() >= 2 ? (lead >= 0.6 * cands.size() && firstLead <= 1 && pairs > 0 && seq * 2 >= pairs)
                : cands.size() == 1 && cands.get(0).leadSmallInt && isOne(cands.get(0).tokens.get(0));

        for (Cand c : cands) {
            List<String> t = new ArrayList<>(c.tokens);
            double qty = c.qty;
            BigDecimal rate = c.rate;
            if (c.leadSmallInt && (serialLayout || c.leadQtyForm) && t.size() > 1) {
                String first = t.remove(0);
                if (!serialLayout && c.leadQtyForm) {                    // "2 TATA TOOR DAL 224.00": the leading number is the quantity
                    qty = Double.parseDouble(first.replaceAll("[^0-9.]", ""));
                    if (c.amount != null && qty > 0) rate = c.amount.divide(BigDecimal.valueOf(qty), 2, RoundingMode.HALF_UP);
                }
            }
            String name = cleanName(t);
            if (letters(name) < 3) continue;
            res.items.add(new Line(name, qty <= 0 ? 1 : qty, rate, c.amount, c.verified, c.source,
                    c.unit, PackSize.find(name), c.discountPct, c.gstPct, c.hsn, c.check));
        }
        return res;
    }

    // ───────────────────────── one line ─────────────────────────

    private static Cand parseLine(String norm, boolean qtyFirst, String source, List<BigDecimal> pcts, List<String> pctOrder) {
        String[] tok = norm.trim().split("\\s+");
        int n = tok.length;
        if (n < 2) return null;

        // numeric candidates: standalone numbers that are not part of a size ("500 g") and not a leading serial number
        boolean leadSmallInt = isSmallInt(tok[0]) && n > 2;
        List<Integer> num = numberIndexes(tok, leadSmallInt, false);

        Cand c = new Cand();
        c.source = source;
        c.leadSmallInt = leadSmallInt;
        if (leadSmallInt) c.leadVal = (int) val(tok[0].replaceAll("[^0-9]", ""));

        // 1) verified: qty x rate (x discount / GST) = amount
        if (verify(c, tok, num, qtyFirst, pcts, pctOrder)) return c;
        // 1b) "Sugar 25 KG 44.00 1100.00": the number before KG may be the quantity of a unit column, not a pack size
        List<Integer> all = numberIndexes(tok, leadSmallInt, true);
        if (all.size() > num.size() && verify(c, tok, all, qtyFirst, pcts, pctOrder)) return c;

        // 1c) OCR dropped a decimal point ("16450" for "164.50"): accept only if inserting it makes the arithmetic hold
        for (int idx : num) {
            if (idx == 0 && leadSmallInt || !tok[idx].matches("\\d{3,8}")) continue;
            String[] fixed = tok.clone();
            fixed[idx] = String.format(java.util.Locale.ROOT, "%.2f", Double.parseDouble(tok[idx]) / 100.0);
            Cand r = new Cand(); r.source = source; r.leadSmallInt = leadSmallInt; r.leadVal = c.leadVal;
            if (verify(r, fixed, num, qtyFirst, pcts, pctOrder) && r.rate != null) {
                r.verified = false; r.check = "REPAIRED";                // right numbers, but flag it: a digit was invented
                return r;
            }
        }

        // 2) fallbacks: OCR damaged a digit somewhere, so we cannot verify; flagged for the user to check
        int m = num.size();
        int nameEnd = m == 0 ? 0 : m >= 3 ? num.get(m - 3) : m == 2 ? num.get(0) : num.get(0);
        if (m >= 3) {                                            // "... qty rate amount"
            c.qty = qtyOr1(val(tok[num.get(m - 3)]));
            c.rate = bd(val(tok[num.get(m - 2)]));
            c.amount = bd(val(tok[num.get(m - 1)]));
            c.tokens = nameTokens(tok, num.get(m - 3));
            c.unit = unitAfter(tok, num.get(m - 3));
            c.hsn = hsnBefore(tok, num.get(m - 3));
        } else if (m == 2) {                                     // "... qty price"
            c.qty = qtyOr1(val(tok[num.get(0)]));
            c.rate = bd(val(tok[num.get(1)]));
            c.amount = c.rate.multiply(BigDecimal.valueOf(c.qty)).setScale(2, RoundingMode.HALF_UP);
            c.tokens = nameTokens(tok, num.get(0));
            c.unit = unitAfter(tok, num.get(0));
        } else if (m == 1) {
            double v = val(tok[num.get(0)]);
            c.tokens = nameTokens(tok, num.get(0));
            if (tok[num.get(0)].contains(".") || v > 99) {       // a price
                c.qty = 1; c.amount = bd(v); c.rate = bd(v);
                c.leadQtyForm = leadSmallInt;                    // maybe "2 TATA TOOR DAL 224.00"
            } else {                                             // "toor dal 2"
                c.qty = v;
                c.unit = unitAfter(tok, num.get(0));
            }
        } else {
            return null;                                         // no numbers: shop name, address...
        }
        if (c.unit == null) c.unit = trailingUnit(tok, nameEnd);
        c.verified = false;
        c.check = "NONE";
        return c;
    }

    private static List<Integer> numberIndexes(String[] tok, boolean leadSmallInt, boolean includeSizeNumbers) {
        List<Integer> num = new ArrayList<>();
        int n = tok.length;
        for (int i = 0; i < n; i++) {
            if (!NUM.matcher(tok[i]).matches()) continue;
            if (!includeSizeNumbers && i + 1 < n && isSizeUnit(tok[i + 1], tok[i])) continue;
            if (i == 0 && leadSmallInt) continue;
            num.add(i);
        }
        return num;
    }

    /** Looks for a row where some  qty x rate (x discount / GST) = amount  holds; fills the Cand and returns true if found. */
    private static boolean verify(Cand c, String[] tok, List<Integer> num, boolean qtyFirst, List<BigDecimal> pcts, List<String> pctOrder) {
        for (int phase = 0; phase < 3; phase++) {          // 0 exact, 1 with the row's percentages, 2 within 3% (OCR-damaged decimals)
            if (phase == 1 && pcts.isEmpty()) continue;
            double tol = phase == 2 ? 0.03 : 0.011;
            for (int k = num.size() - 1; k >= 2; k--)
                for (int j = k - 1; j >= 1; j--)
                    for (int i = j - 1; i >= 0; i--) {
                        double a = val(tok[num.get(i)]), b = val(tok[num.get(j)]), amt = val(tok[num.get(k)]);
                        if (a <= 0 || b <= 0 || amt <= 0) continue;
                        String how = phase == 2 ? "APPROX" : "EXACT";
                        BigDecimal disc = null, gst = null;
                        if (phase == 1) {
                            Factor f = factorMatch(a * b, amt, pcts);
                            if (f == null) continue;
                            how = f.kind; disc = f.disc; gst = f.gst;
                        } else if (!close(a * b, amt, tol)) continue;
                        if (letters(String.join(" ", Arrays.copyOfRange(tok, 0, num.get(i)))) < 3) continue;   // a name must come first
                        boolean aInt = isWhole(a), bInt = isWhole(b);
                        boolean aIsQty = (aInt && !bInt) ? true : (!aInt && bInt) ? false : qtyFirst;
                        int qtyIdx = aIsQty ? num.get(i) : num.get(j);
                        c.qty = aIsQty ? a : b;
                        c.rate = bd(aIsQty ? b : a);
                        c.amount = bd(amt);
                        c.verified = phase < 2;
                        c.check = how;
                        c.tokens = nameTokens(tok, num.get(i));
                        c.unit = unitAfter(tok, qtyIdx);
                        if (c.unit == null) c.unit = trailingUnit(tok, num.get(i));
                        c.hsn = hsnBefore(tok, qtyIdx);
                        if (phase == 1) { c.discountPct = disc; c.gstPct = gst; }
                        else if (!pcts.isEmpty() && pctOrder.size() == pcts.size()) {   // exact row: header says which column is which
                            for (int p = 0; p < pcts.size(); p++) {
                                if (pctOrder.get(p).equals("DISC")) c.discountPct = pcts.get(p); else c.gstPct = pcts.get(p);
                            }
                        }
                        return true;
                    }
        }
        return false;
    }

    private static final class Factor { String kind; BigDecimal disc, gst; }

    private static Factor factorMatch(double prod, double amt, List<BigDecimal> pcts) {
        for (BigDecimal p : pcts) {
            double d = p.doubleValue();
            if (close(prod * (1 - d / 100), amt, 0.011)) { Factor f = new Factor(); f.kind = "DISCOUNT"; f.disc = p; return f; }
            if (close(prod * (1 + d / 100), amt, 0.011)) { Factor f = new Factor(); f.kind = "GST"; f.gst = p; return f; }
        }
        for (int x = 0; x < pcts.size(); x++)
            for (int y = 0; y < pcts.size(); y++) {
                if (x == y) continue;
                double d = pcts.get(x).doubleValue(), g = pcts.get(y).doubleValue();
                if (close(prod * (1 - d / 100) * (1 + g / 100), amt, 0.011)) {
                    Factor f = new Factor(); f.kind = "DISCOUNT+GST"; f.disc = pcts.get(x); f.gst = pcts.get(y); return f;
                }
            }
        return null;
    }

    /** All "12.5%" values in the raw OCR line, in reading order (normalize() throws them away, so read them first). */
    static List<BigDecimal> percents(String rawLine) {
        List<BigDecimal> out = new ArrayList<>();
        Matcher m = Pattern.compile("(\\d+(?:[.,]\\d+)?)\\s*%").matcher(rawLine.replaceAll("(?<![A-Za-z0-9])[Ss](?=\\s*%)", "5"));
        while (m.find()) {
            try { out.add(new BigDecimal(m.group(1).replace(',', '.'))); } catch (NumberFormatException ignored) { }
        }
        return out;
    }

    /** Order of the discount / GST columns in the header line, e.g. "Rate Disc% GST% Amount" -> [DISC, GST]. */
    static List<String> percentColumns(String header) {
        Matcher d = Pattern.compile("\\bdisc(?:ount)?\\b|\\bdis\\b", Pattern.CASE_INSENSITIVE).matcher(header);
        Matcher g = Pattern.compile("\\b(?:i?gst|tax|vat)\\b", Pattern.CASE_INSENSITIVE).matcher(header);
        boolean hd = d.find(), hg = g.find();
        if (hd && hg) return d.start() < g.start() ? List.of("DISC", "GST") : List.of("GST", "DISC");
        if (hd) return List.of("DISC");
        if (hg) return List.of("GST");
        return List.of();
    }

    private static String unitAfter(String[] tok, int qtyIdx) {
        return qtyIdx + 1 < tok.length ? UnitNormalizer.canonical(tok[qtyIdx + 1]) : null;
    }

    /** A unit word printed just before the number columns ("... 0405 Pcs 24 268.00"): scans back over HSN codes and unit words. */
    private static String trailingUnit(String[] tok, int endExclusive) {
        for (int i = Math.min(endExclusive, tok.length) - 1; i >= 0; i--) {
            String u = UnitNormalizer.canonical(tok[i]);
            if (u != null && !isSizeWord(u)) return u;
            if (!tok[i].matches("\\d{4,8}") && u == null) break;
        }
        return null;
    }

    private static boolean isSizeWord(String canonical) { return UnitNormalizer.isMeasure(canonical); }

    /** HSN / SAC: a 4-8 digit whole number somewhere before the quantity column. */
    private static String hsnBefore(String[] tok, int qtyIdx) {
        String found = null;
        for (int i = 0; i < qtyIdx && i < tok.length; i++) if (tok[i].matches("\\d{4,8}")) found = tok[i];
        return found;
    }

    private static List<String> nameTokens(String[] tok, int endExclusive) {
        List<String> t = new ArrayList<>(Arrays.asList(tok).subList(0, endExclusive));
        while (!t.isEmpty()) {                                   // strip trailing HSN codes and unit words
            String last = t.get(t.size() - 1);
            if (last.matches("\\d{4,8}") || COUNT_UNITS.contains(last.toLowerCase(Locale.ROOT))) t.remove(t.size() - 1);
            else break;
        }
        return t;
    }

    // ───────────────────────── helpers ─────────────────────────

    private static boolean isHeader(String line) {
        return HEAD_A.matcher(line).find() && HEAD_B.matcher(line).find() && !line.matches(".*\\d+[.,]\\d{2}.*");
    }

    /** Cleans OCR noise without changing the meaning of the words. */
    static String normalize(String s) {
        s = s.replaceAll("[|_~`‘’“”«»{}\\[\\]]", " ");
        s = s.replaceAll("(?i)(₹|\\brs\\.?|\\binr\\b)", " ");
        s = s.replaceAll("\\d+(?:\\.\\d+)?\\s*%", " ");                          // GST / discount percentages
        s = s.replaceAll("(?<=\\d),(?=\\d{3}(?!\\d))", "");                      // 1,200.00 -> 1200.00
        s = s.replaceAll("(?<=\\d),(?=\\d{2}(?!\\d))", ".");                     // 470,00 -> 470.00 (decimal comma)
        s = s.replaceAll("(?<=\\d)\\s*[x×*@]\\s*(?=\\d)", " ");                  // 2 x 120.00 -> 2 120.00
        Matcher m = Pattern.compile("(?<![\\w.])(?=[0-9OoSIl]*\\d)[0-9OoSIl]+\\.[0-9OoSIl]{2}(?![\\w])").matcher(s);
        StringBuilder sb = new StringBuilder();
        while (m.find()) {                                                       // 1O0.00 / l20.00 -> 100.00 / 120.00
            m.appendReplacement(sb, m.group().replace('O', '0').replace('o', '0').replace('S', '5').replace('I', '1').replace('l', '1'));
        }
        m.appendTail(sb);
        StringBuilder out = new StringBuilder();
        for (String t : sb.toString().trim().split("\\s+")) {
            Matcher core = NUM_CORE.matcher(t);                                  // ?224.00 / (24) / 1. -> 224.00 / 24 / 1
            t = core.matches() ? core.group(1) : t.replaceAll("^[(:;,]+|[):;,]+$", "");
            if (!t.isEmpty()) out.append(t).append(' ');
        }
        return out.toString().trim();
    }

    private static String cleanName(List<String> t) {
        String s = PackSize.repair(String.join(" ", t)).replaceAll("[^\\p{L}\\p{N}\\s.&()'/+-]", " ").replaceAll("\\s+", " ").trim();
        s = s.replaceAll("^[^\\p{L}\\p{N}(]+|[^\\p{L}\\p{N})]+$", "");
        return s.replaceAll("^(?:\\p{L}\\s+)+(?=\\p{L}{2,})", "");          // lone letters left over from table borders ("a Tata Salt")
    }

    private static boolean isSizeUnit(String next, String num) {
        String u = next.toLowerCase(Locale.ROOT);
        return SIZE_UNITS.contains(u) || (u.equals("9") && num.length() >= 2);   // OCR often reads "g" as "9"
    }
    private static boolean isSmallInt(String t) { return t.matches("\\(?\\d{1,2}[.):]?"); }
    private static boolean isOne(String t) { return t.matches("\\(?0*1[.):]?"); }
    private static boolean isWhole(double d) { return Math.abs(d - Math.rint(d)) < 1e-9; }
    private static boolean close(double x, double y, double tol) {
        double diff = Math.abs(x - y);
        return tol < 0.02 ? diff <= tol : diff <= Math.max(0.5, tol * y);
    }
    private static double val(String t) { try { return Double.parseDouble(t); } catch (NumberFormatException e) { return -1; } }
    private static double qtyOr1(double v) { return (v > 0 && v <= 9999 && isWhole(v)) ? v : 1; }
    private static BigDecimal bd(double v) { return BigDecimal.valueOf(v).setScale(2, RoundingMode.HALF_UP); }
    private static int letters(String s) { int c = 0; for (char ch : s.toCharArray()) if (Character.isLetter(ch)) c++; return c; }
}
