package com.quickmart.ocr;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Reads supplier, invoice number, date, GSTIN and the totals block from raw OCR text. Pure string logic. */
public final class InvoiceHeaderParser {
    private InvoiceHeaderParser() {}

    private static final Pattern INV_NO = Pattern.compile(
            "(?:invoice|inv|bill|receipt|memo)\\s*(?:no\\.?|number|num|#)\\s*[:#.\\-]*\\s*([A-Z0-9][A-Z0-9/\\-_.]{2,24})", Pattern.CASE_INSENSITIVE);
    private static final Pattern DATE_NUM = Pattern.compile("(?<![\\d/.-])(\\d{1,2})\\s*[-/.]\\s*(\\d{1,2})\\s*[-/.]\\s*(\\d{4}|\\d{2})(?![\\d/])");
    private static final Pattern DATE_ISO = Pattern.compile("(?<!\\d)(\\d{4})-(\\d{2})-(\\d{2})(?!\\d)");
    private static final Pattern DATE_TXT = Pattern.compile(
            "(?<!\\d)(\\d{1,2})[\\s\\-/.]*(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*[\\s\\-/.,]*(\\d{4}|\\d{2})(?!\\d)", Pattern.CASE_INSENSITIVE);
    private static final List<String> MONTHS = List.of("jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec");
    private static final Pattern NOT_SUPPLIER = Pattern.compile(
            "\\b(tax\\s+invoice|invoice|bill\\s+of\\s+supply|cash\\s*memo|estimate|original|duplicate|gstin|gst|date|phone|mobile|mob|tel|email|www|address|bill\\s+to|ship\\s+to|customer|description|qty|item|sl\\.?\\s*no|thank)\\b",
            Pattern.CASE_INSENSITIVE);
    private static final Pattern BUYER = Pattern.compile("\\b(buyer|bill\\s*to|billed\\s*to|ship\\s*to|consignee|customer|party|recipient|receiver|sold\\s*to)\\b", Pattern.CASE_INSENSITIVE);
    private static final Pattern PCT = Pattern.compile("(\\d+(?:[.,]\\d+)?)\\s*%");
    private static final Pattern NUMBER = Pattern.compile("\\d[\\d,]*(?:\\.\\d{1,2})?");

    public static InvoiceHeader parse(String text) {
        InvoiceHeader h = new InvoiceHeader();
        if (text == null || text.isBlank()) return h;
        String[] lines = text.split("\\r?\\n");
        findGstin(lines, h);
        h.invoiceNumber = findInvoiceNumber(lines);
        findDate(lines, h);
        h.supplierName = findSupplier(lines);
        findTotals(lines, h);
        return h;
    }

    private static void findGstin(String[] lines, InvoiceHeader h) {
        GstinValidator.Found chosen = null;
        for (String line : lines) {
            for (GstinValidator.Found f : GstinValidator.findAll(line)) {
                boolean buyer = BUYER.matcher(line.substring(0, f.index)).find();
                if (buyer) { h.otherGstins.add(f.gstin); continue; }
                if (chosen == null) chosen = f; else h.otherGstins.add(f.gstin);
            }
        }
        if (chosen != null) {
            h.gstin = chosen.gstin; h.gstinChecksumValid = chosen.checksumValid; h.gstinRepaired = chosen.repaired;
            if (chosen.repaired) h.notes.add("GSTIN had misread characters that were corrected; please verify it");
        }
    }

    private static String findInvoiceNumber(String[] lines) {
        for (String line : lines) {
            Matcher m = INV_NO.matcher(line);
            while (m.find()) {
                String t = m.group(1).replaceAll("[.\\-_/]+$", "");
                if (t.matches(".*\\d.*") && t.length() >= 3) return t.toUpperCase(Locale.ROOT);
            }
        }
        return null;
    }

    private static void findDate(String[] lines, InvoiceHeader h) {
        for (int pass = 0; pass < 2; pass++) {                       // pass 0: lines that say "date"; pass 1: any line
            for (String line : lines) {
                String low = line.toLowerCase(Locale.ROOT);
                String hay = line;
                if (pass == 0) {
                    Matcher d = Pattern.compile("\\b(?:dated?|dt)\\b").matcher(low);
                    if (!d.find()) continue;
                    hay = line.substring(d.end());
                }
                if (parseDateIn(hay, h)) return;
            }
        }
    }

    private static boolean parseDateIn(String s, InvoiceHeader h) {
        Matcher m = DATE_ISO.matcher(s);
        if (m.find()) { LocalDate d = ymd(m.group(1), m.group(2), m.group(3)); if (d != null) { h.invoiceDate = d; h.invoiceDateText = m.group(); return true; } }
        m = DATE_TXT.matcher(s);
        if (m.find()) {
            int mon = MONTHS.indexOf(m.group(2).toLowerCase(Locale.ROOT)) + 1;
            LocalDate d = ymd(year(m.group(3)), String.valueOf(mon), m.group(1));
            if (d != null) { h.invoiceDate = d; h.invoiceDateText = m.group().trim(); return true; }
        }
        m = DATE_NUM.matcher(s);
        while (m.find()) {
            int a = Integer.parseInt(m.group(1)), b = Integer.parseInt(m.group(2));
            LocalDate d = ymd(year(m.group(3)), String.valueOf(b), String.valueOf(a));     // Indian bills: day first
            if (d != null) {
                h.invoiceDate = d; h.invoiceDateText = m.group().trim();
                if (a <= 12 && b <= 12 && a != b) h.notes.add("Date " + h.invoiceDateText + " was read as day-month-year");
                return true;
            }
        }
        return false;
    }

    private static String year(String y) { return y.length() == 2 ? "20" + y : y; }

    private static LocalDate ymd(String y, String mo, String d) {
        try { return LocalDate.of(Integer.parseInt(y), Integer.parseInt(mo), Integer.parseInt(d)); }
        catch (RuntimeException e) { return null; }
    }

    private static String findSupplier(String[] lines) {
        for (String line : lines) {                                   // explicit label wins
            Matcher m = Pattern.compile("(?i)\\b(?:sold\\s*by|supplier|from|vendor)\\s*[:\\-]\\s*(.{3,60})").matcher(line);
            if (m.find()) return clean(m.group(1));
        }
        int seen = 0;
        for (String raw : lines) {
            if (seen++ >= 8) break;
            String line = clean(raw);
            if (line.length() < 4 || line.length() > 60) continue;
            if (NOT_SUPPLIER.matcher(line).find() || line.matches(".*\\d{5,}.*")) continue;
            long letters = line.chars().filter(Character::isLetter).count();
            if (letters < 4 || letters < 0.7 * line.replaceAll("\\s", "").length()) continue;
            if (line.matches("(?i).*\\b(plot|road|rd|street|st|lane|nagar|floor|shop|pune|mumbai)\\b.*,.*")) continue;   // an address line
            return line;
        }
        return null;
    }

    private static String clean(String s) {
        return s.replaceAll("[|_~=]+", " ").replaceAll("^[^\\p{L}\\p{N}(]+|[^\\p{L}\\p{N})&.]+$", "").replaceAll("\\s+", " ").trim();
    }

    // ───────────────────────── totals ─────────────────────────

    private static void findTotals(String[] lines, InvoiceHeader h) {
        BigDecimal lastPlainTotal = null;
        for (String line : lines) {
            String low = line.toLowerCase(Locale.ROOT);
            BigDecimal amt = lastAmount(line);
            if (amt == null) continue;
            Matcher pm = PCT.matcher(line);
            BigDecimal rate = pm.find() ? new BigDecimal(pm.group(1).replace(',', '.')) : null;
            if (low.matches(".*\\b(sub\\s*-?\\s*total|taxable\\s*(value|amount|amt)|total\\s+taxable)\\b.*")) { if (h.subtotal == null) h.subtotal = amt; }
            else if (low.matches(".*\\bcgst\\b.*")) { if (h.cgst == null) { h.cgst = amt; h.cgstRate = rate; } }
            else if (low.matches(".*\\bsgst\\b.*|.*\\butgst\\b.*")) { if (h.sgst == null) { h.sgst = amt; h.sgstRate = rate; } }
            else if (low.matches(".*\\bigst\\b.*")) { if (h.igst == null) { h.igst = amt; h.igstRate = rate; } }
            else if (low.matches(".*\\bcess\\b.*")) { if (h.cess == null) h.cess = amt; }
            else if (low.matches(".*round(?:ing)?\\s*-?\\s*off.*")) { if (h.roundOff == null) h.roundOff = signed(line, amt); }
            else if (low.matches(".*\\b(total\\s+(?:tax|gst)|tax\\s+total)\\b.*")) { if (h.taxTotal == null) h.taxTotal = amt; }
            else if (low.matches(".*\\b(total\\s+discount|discount\\s+total|less\\s*:?\\s*discount)\\b.*")) { if (h.discountTotal == null) h.discountTotal = amt; }
            else if (low.matches(".*\\b(grand\\s*total|net\\s*payable|net\\s*amount|amount\\s*payable|invoice\\s*total|total\\s*amount|bill\\s*total)\\b.*")) { h.grandTotal = amt; }
            else if (low.matches("^\\W*total\\b.*")) { lastPlainTotal = amt; }
        }
        if (h.grandTotal == null) h.grandTotal = lastPlainTotal;
    }

    /** The last money amount on the line, ignoring percentages ("CGST 2.5%   547.11" -> 547.11). */
    static BigDecimal lastAmount(String line) {
        String s = PCT.matcher(line).replaceAll(" ").replaceAll("(?i)(₹|\\brs\\.?|\\binr\\b)", " ");
        s = s.replaceAll("(?<=\\d)[Oo](?=\\d)", "0").replaceAll("[?#*]+(?=\\d)", "");
        Matcher m = NUMBER.matcher(s);
        String last = null;
        while (m.find()) last = m.group();
        if (last == null) return null;
        try { return new BigDecimal(last.replace(",", "")); } catch (NumberFormatException e) { return null; }
    }

    private static BigDecimal signed(String line, BigDecimal amt) {
        return line.matches(".*[-(]\\s*\\d.*") ? amt.negate() : amt;
    }
}
