package com.quickmart.ocr;

/** An OCR engine problem, with a reason that lets callers show an actionable message. */
public class OcrException extends Exception {
    public enum Reason {
        /** Tesseract / Tess4J / its native libraries are not installed or cannot start. */
        ENGINE_UNAVAILABLE,
        /** Tesseract runs but the requested language file (e.g. eng.traineddata) cannot be found. */
        LANGUAGE_DATA_MISSING,
        /** The engine did not answer in time. */
        TIMEOUT,
        /** The engine started but failed on this image. */
        FAILED
    }

    public final Reason reason;

    public OcrException(Reason reason, String message) { super(message); this.reason = reason; }
    public OcrException(Reason reason, String message, Throwable cause) { super(message, cause); this.reason = reason; }
}
