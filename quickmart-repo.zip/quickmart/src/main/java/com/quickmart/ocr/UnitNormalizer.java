package com.quickmart.ocr;

import java.util.Locale;
import java.util.Map;

/** Maps the many spellings of an invoice unit column ("Pcs", "NOS", "Kgs", "LTR") to one canonical unit. */
public final class UnitNormalizer {
    private UnitNormalizer() {}

    private static final Map<String, String> CANON = Map.ofEntries(
            Map.entry("kg", "kg"), Map.entry("kgs", "kg"), Map.entry("kilo", "kg"), Map.entry("kilos", "kg"),
            Map.entry("g", "g"), Map.entry("gm", "g"), Map.entry("gms", "g"), Map.entry("gram", "g"), Map.entry("grams", "g"),
            Map.entry("l", "l"), Map.entry("ltr", "l"), Map.entry("ltrs", "l"), Map.entry("lt", "l"), Map.entry("litre", "l"),
            Map.entry("litres", "l"), Map.entry("liter", "l"), Map.entry("liters", "l"),
            Map.entry("ml", "ml"),
            Map.entry("pcs", "pcs"), Map.entry("pc", "pcs"), Map.entry("nos", "pcs"), Map.entry("no", "pcs"), Map.entry("each", "pcs"),
            Map.entry("ea", "pcs"), Map.entry("pes", "pcs"), Map.entry("pos", "pcs"), Map.entry("unit", "pcs"), Map.entry("units", "pcs"),
            Map.entry("box", "box"), Map.entry("boxes", "box"), Map.entry("pkt", "pkt"), Map.entry("pkts", "pkt"),
            Map.entry("pack", "pkt"), Map.entry("packs", "pkt"), Map.entry("packet", "pkt"), Map.entry("packets", "pkt"),
            Map.entry("dz", "dozen"), Map.entry("doz", "dozen"), Map.entry("dozen", "dozen"),
            Map.entry("case", "case"), Map.entry("ctn", "case"), Map.entry("carton", "case"),
            Map.entry("bag", "bag"), Map.entry("bags", "bag"), Map.entry("btl", "btl"), Map.entry("bottle", "btl"),
            Map.entry("jar", "jar"), Map.entry("tin", "tin"), Map.entry("can", "can"), Map.entry("tub", "tub"), Map.entry("sachet", "sachet"));

    /** Canonical unit for a token, or null when it is not a unit word. */
    public static String canonical(String token) {
        if (token == null) return null;
        return CANON.get(token.trim().toLowerCase(Locale.ROOT).replaceAll("[^a-z]", ""));
    }

    public static boolean isMeasure(String canonicalUnit) {
        return "kg".equals(canonicalUnit) || "g".equals(canonicalUnit) || "l".equals(canonicalUnit) || "ml".equals(canonicalUnit);
    }

    /** One unit of a measure expressed as a PackSize ("kg" -> 1 kg), or null for count units. */
    public static PackSize asPack(String canonicalUnit) {
        if (canonicalUnit == null) return null;
        return switch (canonicalUnit) {
            case "kg" -> PackSize.of(PackSize.Kind.MASS, 1000);
            case "g" -> PackSize.of(PackSize.Kind.MASS, 1);
            case "l" -> PackSize.of(PackSize.Kind.VOLUME, 1000);
            case "ml" -> PackSize.of(PackSize.Kind.VOLUME, 1);
            default -> null;
        };
    }

    /** Pieces in a count unit that is a fixed multiple ("dozen" = 12); 1 for pcs; 0 when the multiple is unknown (box, case...). */
    public static int piecesPer(String canonicalUnit) {
        if (canonicalUnit == null) return 1;
        return switch (canonicalUnit) {
            case "pcs", "pkt", "bag", "btl", "jar", "tin", "can", "tub", "sachet" -> 1;
            case "dozen" -> 12;
            default -> 0;
        };
    }
}
