package com.quickmart.controller;

import com.quickmart.model.ApplicationStatus;
import com.quickmart.model.DeliveryPartner;
import com.quickmart.model.Vendor;
import com.quickmart.repository.DeliveryPartnerRepository;
import com.quickmart.repository.VendorRepository;
import com.quickmart.service.AuthService;
import com.quickmart.service.Validation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/auth")
@CrossOrigin
public class AuthController {
    @Autowired private AuthService auth;
    @Autowired private VendorRepository vendors;
    @Autowired private DeliveryPartnerRepository partners;

    public record LoginReq(String role, String phone, String pin) {}
    public record AdminReq(String key) {}

    /** role = VENDOR or PARTNER. Pending / rejected applicants get their status but no token. */
    @PostMapping("/login")
    public Map<String, Object> login(@RequestBody LoginReq r) {
        String phone = Validation.phone(r.phone());
        String hash = AuthService.hashPin(phone, r.pin() == null ? "" : r.pin());
        String role = r.role() == null ? "" : r.role().toUpperCase();
        Long id; String name; ApplicationStatus status;
        if (role.equals("VENDOR")) {
            Vendor v = vendors.findByPhone(phone).filter(x -> hash.equals(x.pinHash)).orElseThrow(this::bad);
            id = v.vendorId; name = v.shopName; status = v.status;
        } else if (role.equals("PARTNER")) {
            DeliveryPartner p = partners.findByPhone(phone).filter(x -> hash.equals(x.pinHash)).orElseThrow(this::bad);
            id = p.partnerId; name = p.name; status = p.status;
        } else {
            throw new IllegalArgumentException("Unknown role");
        }
        Map<String, Object> out = new HashMap<>();
        out.put("status", status.name());
        out.put("name", name);
        if (status == ApplicationStatus.APPROVED) out.put("token", auth.startSession(role, id));
        return out;
    }

    @PostMapping("/admin")
    public Map<String, Object> admin(@RequestBody AdminReq r) {
        return Map.of("token", auth.adminLogin(r.key()));
    }

    private ResponseStatusException bad() { return new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Wrong phone or PIN"); }
}
