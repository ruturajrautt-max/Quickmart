package com.quickmart.controller;

import com.quickmart.service.StoreService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/stores")
@CrossOrigin
public class StoreController {
    @Autowired private StoreService storeService;

    // GET /api/stores?q=milk&lat=18.52&lng=73.85   (q optional; matches store name/address or an item the store stocks)
    @GetMapping
    public List<StoreService.StoreView> search(@RequestParam(required = false) String q,
                                               @RequestParam(required = false) Double lat,
                                               @RequestParam(required = false) Double lng) {
        return storeService.search(q, lat, lng);
    }

    // GET /api/stores/3/stock?q=amul   (stock left in one store)
    @GetMapping("/{storeId}/stock")
    public List<StoreService.StockRow> stock(@PathVariable Long storeId, @RequestParam(required = false) String q) {
        return storeService.stock(storeId, q);
    }
}
