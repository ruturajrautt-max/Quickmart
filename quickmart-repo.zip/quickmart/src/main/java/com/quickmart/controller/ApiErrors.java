package com.quickmart.controller;

import com.quickmart.dto.IssueDto;
import com.quickmart.invoice.BillValidationException;
import com.quickmart.invoice.DuplicateBillException;
import com.quickmart.invoice.InvalidBillUploadException;
import com.quickmart.service.BillOcrService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.multipart.MaxUploadSizeExceededException;
import org.springframework.web.server.ResponseStatusException;

import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Turns validation / auth failures of the vendor-delivery-order APIs into {"error": "..."} JSON. */
@RestControllerAdvice(assignableTypes = {AuthController.class, SearchController.class, VendorController.class,
        PartnerController.class, OrderController.class, AdminController.class, BillController.class})
public class ApiErrors {
    @ExceptionHandler(IllegalArgumentException.class)
    public ResponseEntity<Map<String, String>> badRequest(IllegalArgumentException e) {
        return ResponseEntity.badRequest().body(Map.of("error", String.valueOf(e.getMessage())));
    }

    @ExceptionHandler(ResponseStatusException.class)
    public ResponseEntity<Map<String, String>> status(ResponseStatusException e) {
        return ResponseEntity.status(e.getStatusCode()).body(Map.of("error", String.valueOf(e.getReason())));
    }

    /** OCR engine missing / not working: tell the user what to install instead of a blank HTTP 500. */
    @ExceptionHandler(BillOcrService.OcrUnavailableException.class)
    public ResponseEntity<Map<String, String>> ocrDown(BillOcrService.OcrUnavailableException e) {
        return ResponseEntity.status(HttpStatus.SERVICE_UNAVAILABLE).body(Map.of("error", String.valueOf(e.getMessage())));
    }

    /** Wrong type / empty / too large / unreadable upload: the status code says which (400, 413, 415, 422). */
    @ExceptionHandler(InvalidBillUploadException.class)
    public ResponseEntity<Map<String, String>> badUpload(InvalidBillUploadException e) {
        return ResponseEntity.status(e.status).body(Map.of("error", String.valueOf(e.getMessage())));
    }

    @ExceptionHandler(MaxUploadSizeExceededException.class)
    public ResponseEntity<Map<String, String>> tooBig(MaxUploadSizeExceededException e) {
        return ResponseEntity.status(HttpStatus.PAYLOAD_TOO_LARGE).body(Map.of("error", "The file is too large. The limit is 10 MB."));
    }

    /** The bill (same file, or same supplier + invoice number) is already in the stock: 409, nothing was changed. */
    @ExceptionHandler(DuplicateBillException.class)
    public ResponseEntity<Map<String, Object>> duplicate(DuplicateBillException e) {
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("error", e.getMessage());
        body.put("duplicate", e.kind);
        body.put("importedOn", e.importedOn);
        return ResponseEntity.status(HttpStatus.CONFLICT).body(body);
    }

    /** Confirming refused: 422 with every problem found, and whether the vendor only needs to acknowledge warnings. */
    @ExceptionHandler(BillValidationException.class)
    public ResponseEntity<Map<String, Object>> invalidBill(BillValidationException e) {
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("error", e.getMessage());
        body.put("needsAcknowledgement", e.needsAcknowledgement);
        List<IssueDto> issues = e.issues;
        body.put("issues", issues);
        return ResponseEntity.status(HttpStatus.UNPROCESSABLE_ENTITY).body(body);
    }

    @ExceptionHandler(IOException.class)
    public ResponseEntity<Map<String, String>> unreadableUpload(IOException e) {
        return ResponseEntity.badRequest().body(Map.of("error", "Could not read the uploaded file"));
    }
}
