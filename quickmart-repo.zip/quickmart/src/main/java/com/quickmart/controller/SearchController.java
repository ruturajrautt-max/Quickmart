package com.quickmart.controller;

import com.quickmart.model.Item;
import com.quickmart.service.SearchService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/search")
@CrossOrigin
public class SearchController {
    @Autowired private SearchService searchService;

    // GET /api/search/suggest?q=mi&limit=8   (Trie-backed autocomplete)
    @GetMapping("/suggest")
    public List<Item> suggest(@RequestParam String q, @RequestParam(defaultValue = "8") int limit) {
        return searchService.suggest(q, Math.max(1, Math.min(limit, 20)));
    }
}
