package com.quickmart.controller;

import com.quickmart.model.DeliveryPartner;
import com.quickmart.service.AuthService;
import com.quickmart.service.OrderService;
import com.quickmart.service.PartnerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/partners")
@CrossOrigin
public class PartnerController {
    private static final String TOKEN = "X-Auth-Token";
    @Autowired private AuthService auth;
    @Autowired private PartnerService partnerService;
    @Autowired private OrderService orderService;

    public record StatusReq(Boolean online, Double lat, Double lng) {}

    @PostMapping("/apply")
    public DeliveryPartner apply(@RequestBody PartnerService.ApplyReq req) { return partnerService.apply(req); }

    @GetMapping("/me")
    public DeliveryPartner me(@RequestHeader(value = TOKEN, required = false) String token) {
        return partnerService.get(auth.require(token, "PARTNER"));
    }

    // online/offline toggle and/or location update
    @PostMapping("/status")
    public DeliveryPartner status(@RequestHeader(value = TOKEN, required = false) String token, @RequestBody StatusReq req) {
        return partnerService.update(auth.require(token, "PARTNER"), req.online(), req.lat(), req.lng());
    }

    @GetMapping("/deliveries")
    public List<OrderService.OrderView> deliveries(@RequestHeader(value = TOKEN, required = false) String token) {
        return orderService.forPartner(auth.require(token, "PARTNER"));
    }

    // POST /api/partners/deliveries/12/action?type=accept | decline | pickup | deliver
    @PostMapping("/deliveries/{orderId}/action")
    public OrderService.OrderView action(@RequestHeader(value = TOKEN, required = false) String token,
                                         @PathVariable Long orderId, @RequestParam String type) {
        return orderService.partnerAction(auth.require(token, "PARTNER"), orderId, type);
    }
}
