package com.quickmart.controller;

import com.quickmart.model.Item;
import com.quickmart.repository.ItemRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/items")
@CrossOrigin
public class ItemController {

    @Autowired
    private ItemRepository itemRepository;

    @GetMapping
    public List<Item> getAll() {
        return itemRepository.findAll();
    }

    @GetMapping("/search")
    public List<Item> search(@RequestParam String name) {
        String searchName = Item.normalize(name);
        return itemRepository.findByNormalizedNameContaining(searchName);
    }
}