package com.quickmart.controller;

import com.quickmart.service.BillOcrService;
import com.quickmart.service.BillParsingService;
import com.quickmart.service.BillReorderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/bills")
@CrossOrigin
public class BillController {

    @Autowired private BillParsingService billParsingService;
    @Autowired private BillReorderService reorderService;
    @Autowired private BillOcrService ocrService;

    // POST /api/bills/upload  (multipart form, field name "file"; JPG / PNG / PDF)
    // Plain read + match, kept as it was: returns the parsed lines.
    @PostMapping("/upload")
    public List<BillParsingService.ParsedLine> uploadBill(@RequestParam("file") MultipartFile file) throws IOException {
        return billParsingService.scan(file.getBytes(), file.getOriginalFilename()).lines;
    }

    // POST /api/bills/reorder?lat=18.52&lng=73.85  (multipart, field "file")
    // Customer reorder: every bill line matched to a catalog item with the cheapest store that has it in stock.
    @PostMapping("/reorder")
    public BillReorderService.Reorder reorder(@RequestParam("file") MultipartFile file,
                                              @RequestParam(defaultValue = "18.5204") double lat,
                                              @RequestParam(defaultValue = "73.8567") double lng) throws IOException {
        return reorderService.fromBill(file.getBytes(), file.getOriginalFilename(), lat, lng);
    }

    // GET /api/bills/health : reads a generated test image through the real OCR pipeline and says what is wrong if it fails
    @GetMapping("/health")
    public Map<String, Object> health() {
        return ocrService.health();
    }
}
