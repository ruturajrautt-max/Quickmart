package com.quickmart.controller;

import com.quickmart.model.ApplicationStatus;
import com.quickmart.model.DeliveryPartner;
import com.quickmart.model.Vendor;
import com.quickmart.repository.DeliveryPartnerRepository;
import com.quickmart.repository.VendorRepository;
import com.quickmart.service.AuthService;
import com.quickmart.service.OrderService;
import com.quickmart.service.PartnerService;
import com.quickmart.service.VendorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/admin")
@CrossOrigin
public class AdminController {
    private static final String TOKEN = "X-Auth-Token";
    @Autowired private AuthService auth;
    @Autowired private VendorService vendorService;
    @Autowired private PartnerService partnerService;
    @Autowired private VendorRepository vendors;
    @Autowired private DeliveryPartnerRepository partners;
    @Autowired private OrderService orderService;

    @GetMapping("/vendors")
    public List<Vendor> vendors(@RequestHeader(value = TOKEN, required = false) String token,
                                @RequestParam(required = false) ApplicationStatus status) {
        auth.require(token, "ADMIN");
        return status == null ? vendors.findAll() : vendors.findByStatus(status);
    }

    @PostMapping("/vendors/{id}/decision")
    public Vendor decideVendor(@RequestHeader(value = TOKEN, required = false) String token,
                               @PathVariable Long id, @RequestParam boolean approve) {
        auth.require(token, "ADMIN");
        return vendorService.decide(id, approve);
    }

    @GetMapping("/partners")
    public List<DeliveryPartner> partners(@RequestHeader(value = TOKEN, required = false) String token,
                                          @RequestParam(required = false) ApplicationStatus status) {
        auth.require(token, "ADMIN");
        return status == null ? partners.findAll() : partners.findByStatus(status);
    }

    @PostMapping("/partners/{id}/decision")
    public DeliveryPartner decidePartner(@RequestHeader(value = TOKEN, required = false) String token,
                                         @PathVariable Long id, @RequestParam boolean approve) {
        auth.require(token, "ADMIN");
        return partnerService.decide(id, approve);
    }

    // orders currently waiting in the processing queue (front of the queue first)
    @GetMapping("/queue")
    public List<OrderService.OrderView> queue(@RequestHeader(value = TOKEN, required = false) String token) {
        auth.require(token, "ADMIN");
        return orderService.queued();
    }
}
