package com.quickmart.controller;

import com.quickmart.model.Vendor;
import com.quickmart.dto.*;
import com.quickmart.service.AuthService;
import com.quickmart.service.BillInvoiceService;
import com.quickmart.service.OrderService;
import com.quickmart.service.VendorBillService;
import com.quickmart.service.VendorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.net.URI;
import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/vendors")
@CrossOrigin
public class VendorController {
    private static final String TOKEN = "X-Auth-Token";
    @Autowired private AuthService auth;
    @Autowired private VendorService vendorService;
    @Autowired private OrderService orderService;
    @Autowired private VendorBillService vendorBills;
    @Autowired private BillInvoiceService invoices;

    public record PriceStockReq(BigDecimal price, Integer stockQty) {}

    @PostMapping("/apply")
    public Vendor apply(@RequestBody VendorService.ApplyReq req) { return vendorService.apply(req); }

    @GetMapping("/me")
    public Vendor me(@RequestHeader(value = TOKEN, required = false) String token) {
        return vendorService.get(auth.require(token, "VENDOR"));
    }

    @GetMapping("/products")
    public List<VendorService.ProductView> products(@RequestHeader(value = TOKEN, required = false) String token) {
        return vendorService.products(auth.require(token, "VENDOR"));
    }

    @PostMapping("/products")
    public VendorService.ProductView addProduct(@RequestHeader(value = TOKEN, required = false) String token,
                                                @RequestBody VendorService.ProductReq req) {
        return vendorService.saveProduct(auth.require(token, "VENDOR"), req);
    }

    @PutMapping("/products/{itemId}")
    public VendorService.ProductView update(@RequestHeader(value = TOKEN, required = false) String token,
                                            @PathVariable Long itemId, @RequestBody PriceStockReq req) {
        return vendorService.saveProduct(auth.require(token, "VENDOR"),
                new VendorService.ProductReq(itemId, null, null, null, null, req.price(), req.stockQty(), null));
    }

    @DeleteMapping("/products/{itemId}")
    public Map<String, Boolean> remove(@RequestHeader(value = TOKEN, required = false) String token, @PathVariable Long itemId) {
        vendorService.removeProduct(auth.require(token, "VENDOR"), itemId);
        return Map.of("deleted", true);
    }

    // ───────────── reviewed bill workflow (OCR draft -> vendor edits -> confirm) ─────────────
    // Every call needs a vendor token; a bill is only ever visible to the store that uploaded it.

    // POST /api/vendors/bills  (multipart "file": JPG/PNG/PDF) -> 201 + the extracted, matched and validated bill. Saves a DRAFT only.
    //   200 instead of 201 when the same file was uploaded before and its unfinished draft is reused.
    @PostMapping("/bills")
    public ResponseEntity<InvoiceView> uploadBill(@RequestHeader(value = TOKEN, required = false) String token,
                                                  @RequestParam("file") MultipartFile file) throws IOException {
        InvoiceView v = invoices.upload(auth.require(token, "VENDOR"), file.getBytes(), file.getOriginalFilename());
        return v.reusedExisting ? ResponseEntity.ok(v) : ResponseEntity.created(URI.create("/api/vendors/bills/" + v.billId)).body(v);
    }

    // GET /api/vendors/bills -> the 30 most recent scanned bills
    @GetMapping("/bills")
    public List<BillSummaryDto> billList(@RequestHeader(value = TOKEN, required = false) String token) {
        return invoices.list(auth.require(token, "VENDOR"));
    }

    // GET /api/vendors/bills/{id} -> the OCR result (with the vendor's edits, if any)
    @GetMapping("/bills/{billId}")
    public InvoiceView getBill(@RequestHeader(value = TOKEN, required = false) String token, @PathVariable Long billId) {
        return invoices.get(auth.require(token, "VENDOR"), billId);
    }

    // PUT /api/vendors/bills/{id}  {header, lines} -> saves the vendor's corrections; rows are re-matched and re-validated. Does NOT change stock.
    @PutMapping("/bills/{billId}")
    public InvoiceView editBill(@RequestHeader(value = TOKEN, required = false) String token, @PathVariable Long billId,
                                @RequestBody InvoiceEdit edit) {
        return invoices.edit(auth.require(token, "VENDOR"), billId, edit);
    }

    // POST /api/vendors/bills/{id}/match  {lineId | text, packSize?} -> catalog suggestions with confidence and pack-size verdict
    @PostMapping("/bills/{billId}/match")
    public Map<String, List<SuggestionDto>> matchBill(@RequestHeader(value = TOKEN, required = false) String token, @PathVariable Long billId,
                                                      @RequestBody MatchRequest req) {
        return Map.of("suggestions", invoices.suggest(auth.require(token, "VENDOR"), billId, req));
    }

    // POST /api/vendors/bills/{id}/confirm  {header, lines, acknowledgeWarnings} -> ADDS the quantities to stock, all or nothing.
    //   422 {error, issues[], needsAcknowledgement} when something must be fixed / acknowledged;  409 when the bill was already added.
    @PostMapping("/bills/{billId}/confirm")
    public ConfirmResult confirmBill(@RequestHeader(value = TOKEN, required = false) String token, @PathVariable Long billId,
                                     @RequestBody InvoiceEdit edit) {
        return invoices.confirm(auth.require(token, "VENDOR"), billId, edit);
    }

    // DELETE /api/vendors/bills/{id} -> throws away an unconfirmed draft (a confirmed bill cannot be deleted)
    @DeleteMapping("/bills/{billId}")
    public Map<String, Boolean> discardBill(@RequestHeader(value = TOKEN, required = false) String token, @PathVariable Long billId) {
        invoices.discard(auth.require(token, "VENDOR"), billId);
        return Map.of("ok", true);
    }

    // POST /api/vendors/bill/scan   (multipart, field "file": JPG/PNG/PDF of the distributor's bill) - reads only, saves nothing
    @PostMapping("/bill/scan")
    public VendorBillService.ScanView scanBill(@RequestHeader(value = TOKEN, required = false) String token,
                                               @RequestParam("file") MultipartFile file) throws IOException {
        return vendorBills.scan(auth.require(token, "VENDOR"), file.getBytes(), file.getOriginalFilename());
    }

    // POST /api/vendors/bill/apply  {billHash, lines:[{itemId|name+category, qty, price}]} - ADDS the quantities to stock
    @PostMapping("/bill/apply")
    public List<VendorService.ProductView> applyBill(@RequestHeader(value = TOKEN, required = false) String token,
                                                     @RequestBody VendorBillService.ApplyReq req) {
        return vendorBills.apply(auth.require(token, "VENDOR"), req);
    }

    @GetMapping("/orders")
    public List<OrderService.OrderView> orders(@RequestHeader(value = TOKEN, required = false) String token) {
        return orderService.forStore(vendorService.storeIdOf(auth.require(token, "VENDOR")));
    }

    // POST /api/vendors/orders/12/action?type=PREPARING | READY | CANCELLED | UNDO
    @PostMapping("/orders/{orderId}/action")
    public OrderService.OrderView action(@RequestHeader(value = TOKEN, required = false) String token,
                                         @PathVariable Long orderId, @RequestParam String type) {
        return orderService.vendorAction(vendorService.storeIdOf(auth.require(token, "VENDOR")), orderId, type);
    }
}
