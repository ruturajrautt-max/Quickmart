package com.quickmart.controller;

import com.quickmart.dto.StorePriceResult;
import com.quickmart.service.PriceComparisonService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/price")
@CrossOrigin(origins = "*")
public class PriceController {

    @Autowired
    private PriceComparisonService priceComparisonService;

    // GET /api/price/compare?itemId=1&lat=18.52&lng=73.85&maxDistanceKm=5&k=5
    @GetMapping("/compare")
    public List<StorePriceResult> compare(@RequestParam Long itemId,
                                           @RequestParam double lat,
                                           @RequestParam double lng,
                                           @RequestParam(defaultValue = "-1") double maxDistanceKm,
                                           @RequestParam(defaultValue = "5") int k) {
        return priceComparisonService.getCheapestStores(itemId, lat, lng, maxDistanceKm, k);
    }
}
