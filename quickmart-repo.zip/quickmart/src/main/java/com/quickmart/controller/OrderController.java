package com.quickmart.controller;

import com.quickmart.service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/orders")
@CrossOrigin
public class OrderController {
    @Autowired private OrderService orderService;

    // customer cart -> one order per store, each pushed on the processing queue
    @PostMapping
    public List<OrderService.OrderView> place(@RequestBody OrderService.PlaceReq req) { return orderService.placeOrder(req); }

    @GetMapping("/track")
    public List<OrderService.OrderView> track(@RequestParam String phone) { return orderService.track(phone); }

    @GetMapping("/{orderId}/history")
    public List<OrderService.EventView> history(@PathVariable Long orderId) { return orderService.history(orderId); }
}
