package com.quickmart.service;

import com.quickmart.repository.PurchaseHistoryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;

/**
 * "Frequently bought" per user, optionally scoped to a specific store.
 *
 * DSA: HashMap for O(1) count aggregation per (item), then a min-heap of size N
 * to pull the top-N most frequent items in O(m log N) instead of sorting all
 * distinct items O(m log m).
 */
@Service
public class FrequentlyBoughtService {

    @Autowired
    private PurchaseHistoryRepository purchaseHistoryRepository;

    public static class ItemFrequency {
        public Long itemId;
        public int count;
        public ItemFrequency(Long itemId, int count) { this.itemId = itemId; this.count = count; }
    }

    /**
     * storeId == null -> across all stores. Looks at purchases in the last `daysWindow` days.
     */
    public List<ItemFrequency> getTopFrequentItems(Long userId, Long storeId, int daysWindow, int topN) {

        List<Object[]> rows = (storeId == null)
                ? purchaseHistoryRepository.findItemIdsByUserSince(userId, daysWindow)
                : purchaseHistoryRepository.findItemIdsByUserAndStoreSince(userId, storeId, daysWindow);

        // Step 1: aggregate counts — HashMap, O(m)
        Map<Long, Integer> countMap = new HashMap<>();
        for (Object[] row : rows) {
            Long itemId = (Long) row[0];
            Integer qty = (Integer) row[1];
            countMap.merge(itemId, qty, Integer::sum);
        }

        // Step 2: top-N via min-heap, O(m log N) — avoids sorting everything when
        // you only ever display a handful of "frequently bought" chips in the UI.
        PriorityQueue<ItemFrequency> minHeap = new PriorityQueue<>(Comparator.comparingInt(f -> f.count));
        for (Map.Entry<Long, Integer> entry : countMap.entrySet()) {
            minHeap.offer(new ItemFrequency(entry.getKey(), entry.getValue()));
            if (minHeap.size() > topN) minHeap.poll();
        }

        List<ItemFrequency> result = new ArrayList<>(minHeap);
        result.sort((a, b) -> b.count - a.count); // highest frequency first
        return result;
    }
}
