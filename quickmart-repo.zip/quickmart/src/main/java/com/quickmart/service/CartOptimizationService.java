package com.quickmart.service;

import com.quickmart.model.StoreInventory;
import com.quickmart.repository.StoreInventoryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.*;

/**
 * Cart-level cost optimization.
 *
 * Problem: given a cart of items and a set of candidate stores (each with a flat
 * delivery fee), find the cheapest way to fulfil the cart using AT MOST maxStores
 * stores (split cart across stores if that saves money net of delivery fees).
 *
 * This is a set-cover / partition style problem -> NP-hard in general.
 * For a bounded, small maxStores (1 or 2, which covers the realistic UX case),
 * we brute-force over store combinations and greedily assign each item to its
 * cheapest store within the chosen combination. This keeps it tractable and is
 * a legitimate thing to explain in viva: "we constrain maxStores to keep this
 * out of exponential blow-up, and greedy-assign within a fixed store set."
 */
@Service
public class CartOptimizationService {

    @Autowired
    private StoreInventoryRepository storeInventoryRepository;

    public static class CartPlan {
        public Map<Long, List<Long>> storeToItems = new HashMap<>(); // storeId -> itemIds
        public BigDecimal totalCost = BigDecimal.ZERO;
    }

    /**
     * candidateStoreIds: stores worth considering (e.g. within delivery radius)
     * deliveryFeePerStore: flat fee charged once per store used in the plan
     */
    public CartPlan findBestPlan(List<Long> itemIds, List<Long> candidateStoreIds,
                                  BigDecimal deliveryFeePerStore, int maxStores) {

        // price[itemId][storeId] = price, only if in stock
        Map<Long, Map<Long, BigDecimal>> priceMatrix = new HashMap<>();
        for (Long storeId : candidateStoreIds) {
            List<StoreInventory> offers = storeInventoryRepository.findByStoreId(storeId);
            for (StoreInventory offer : offers) {
                if (!itemIds.contains(offer.getItemId()) || offer.getStockQty() <= 0) continue;
                priceMatrix.computeIfAbsent(offer.getItemId(), k -> new HashMap<>())
                        .put(storeId, offer.getPrice());
            }
        }

        CartPlan best = null;

        // Try every combination of stores of size 1..maxStores (small n in practice,
        // since candidateStoreIds is already pre-filtered to "nearby" stores).
        List<List<Long>> combos = generateCombinations(candidateStoreIds, maxStores);

        for (List<Long> combo : combos) {
            CartPlan plan = new CartPlan();
            boolean feasible = true;

            for (Long itemId : itemIds) {
                Map<Long, BigDecimal> offersForItem = priceMatrix.get(itemId);
                if (offersForItem == null) { feasible = false; break; }

                // cheapest store within this combo that stocks the item
                Long bestStore = null;
                BigDecimal bestPrice = null;
                for (Long storeId : combo) {
                    BigDecimal p = offersForItem.get(storeId);
                    if (p != null && (bestPrice == null || p.compareTo(bestPrice) < 0)) {
                        bestPrice = p;
                        bestStore = storeId;
                    }
                }
                if (bestStore == null) { feasible = false; break; }

                plan.storeToItems.computeIfAbsent(bestStore, k -> new ArrayList<>()).add(itemId);
                plan.totalCost = plan.totalCost.add(bestPrice);
            }

            if (!feasible) continue;

            // add delivery fee per store actually used
            plan.totalCost = plan.totalCost.add(
                    deliveryFeePerStore.multiply(BigDecimal.valueOf(plan.storeToItems.size()))
            );

            if (best == null || plan.totalCost.compareTo(best.totalCost) < 0) {
                best = plan;
            }
        }

        return best; // null if no feasible plan (some item unavailable everywhere)
    }

    /** All subsets of `stores` with size 1..maxSize. Kept small since candidate list is pre-filtered. */
    private List<List<Long>> generateCombinations(List<Long> stores, int maxSize) {
        List<List<Long>> result = new ArrayList<>();
        int n = stores.size();
        for (int mask = 1; mask < (1 << n); mask++) {
            if (Integer.bitCount(mask) > maxSize) continue;
            List<Long> combo = new ArrayList<>();
            for (int i = 0; i < n; i++) {
                if ((mask & (1 << i)) != 0) combo.add(stores.get(i));
            }
            result.add(combo);
        }
        return result;
    }
}
