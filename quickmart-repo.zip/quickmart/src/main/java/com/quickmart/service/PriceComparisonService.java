package com.quickmart.service;

import com.quickmart.dto.StorePriceResult;
import com.quickmart.model.Store;
import com.quickmart.model.StoreInventory;
import com.quickmart.repository.StoreInventoryRepository;
import com.quickmart.repository.StoreRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;

/**
 * Price comparison across stores for a single item.
 *
 * DSA: uses a bounded min-heap (actually a max-heap capped at size k) to find the
 * k cheapest stores in O(n log k) instead of sorting the full list in O(n log n).
 * Worth it once you have hundreds of stores carrying the same item.
 */
@Service
public class PriceComparisonService {

    @Autowired
    private StoreInventoryRepository storeInventoryRepository;

    @Autowired
    private StoreRepository storeRepository;

    /**
     * Returns the k cheapest stores for a given item, optionally biased toward
     * stores within maxDistanceKm of the user (pass -1 to ignore distance).
     */
    public List<StorePriceResult> getCheapestStores(Long itemId, double userLat, double userLng,
                                                      double maxDistanceKm, int k) {

        List<StoreInventory> allOffers = storeInventoryRepository.findByItemIdAndStockQtyGreaterThan(itemId, 0);

        // Max-heap of size k on price: if a cheaper item comes in and heap is full,
        // evict the current most expensive. End result = k cheapest, O(n log k).
        PriorityQueue<StorePriceResult> maxHeap = new PriorityQueue<>(
                (a, b) -> b.getPrice().compareTo(a.getPrice())
        );

        for (StoreInventory offer : allOffers) {
            Store store = storeRepository.findById(offer.getStoreId()).orElse(null);
            if (store == null || !Boolean.TRUE.equals(store.getIsActive())) continue;

            double dist = store.distanceTo(userLat, userLng);
            if (maxDistanceKm > 0 && dist > maxDistanceKm) continue;

            StorePriceResult candidate = new StorePriceResult(
                    store.getStoreId(), store.getName(), offer.getPrice(), dist
            );

            if (maxHeap.size() < k) {
                maxHeap.offer(candidate);
            } else if (maxHeap.peek() != null && candidate.getPrice().compareTo(maxHeap.peek().getPrice()) < 0) {
                maxHeap.poll();
                maxHeap.offer(candidate);
            }
        }

        List<StorePriceResult> result = new ArrayList<>(maxHeap);
        result.sort(Comparator.comparing(StorePriceResult::getPrice)); // cheapest first for display
        return result;
    }
}
