package com.quickmart.service;

/** Small input checks shared by the vendor / partner / order services. */
public final class Validation {
    private Validation() {}

    public static boolean blank(String s) { return s == null || s.isBlank(); }

    public static String need(String value, String label) {
        if (blank(value)) throw new IllegalArgumentException(label + " is required");
        return value.trim();
    }

    /** Keeps the last 10 digits; rejects anything that is not a 10-digit mobile number. */
    public static String phone(String raw) {
        String d = raw == null ? "" : raw.replaceAll("\\D", "");
        if (d.length() > 10) d = d.substring(d.length() - 10);
        if (d.length() != 10) throw new IllegalArgumentException("Enter a valid 10-digit phone number");
        return d;
    }

    public static String pin(String pin) {
        if (pin == null || !pin.matches("\\d{4,6}")) throw new IllegalArgumentException("PIN must be 4-6 digits");
        return pin;
    }

    public static void location(Double lat, Double lng) {
        if (lat == null || lng == null) throw new IllegalArgumentException("Please choose a location");
    }
}
