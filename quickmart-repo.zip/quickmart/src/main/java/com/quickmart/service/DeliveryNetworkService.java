package com.quickmart.service;

import com.quickmart.dsa.NearestPartnerHeap;
import com.quickmart.dsa.RoadGraph;
import com.quickmart.model.*;
import com.quickmart.repository.DeliveryPartnerRepository;
import com.quickmart.repository.StoreRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;

/**
 * Builds the store / customer / partner road graph from the database and runs
 *  - Dijkstra : shortest delivery route (store -> customer)
 *  - Min-heap : nearest available partner to the store
 */
@Service
public class DeliveryNetworkService {
    @Autowired private StoreRepository storeRepository;
    @Autowired private DeliveryPartnerRepository partnerRepository;

    public record Assignment(DeliveryPartner partner, double pickupKm, double routeKm, String routePath) {}

    private RoadGraph buildGraph(Store pickup, double custLat, double custLng, Collection<DeliveryPartner> partners) {
        RoadGraph g = new RoadGraph();
        for (Store s : storeRepository.findAll()) {
            if (Boolean.TRUE.equals(s.getIsActive())) g.addNode("S" + s.getStoreId(), s.getLatitude(), s.getLongitude());
        }
        if (!g.hasNode("S" + pickup.getStoreId())) g.addNode("S" + pickup.getStoreId(), pickup.getLatitude(), pickup.getLongitude());
        g.addNode("C", custLat, custLng);
        g.connectRoads(3);
        for (DeliveryPartner p : partners) g.attachLeaf("P" + p.partnerId, p.latitude, p.longitude, 2);
        return g;
    }

    /** Dijkstra route from the store to the customer, as a readable path. */
    public RoadGraph.Path route(Store store, double custLat, double custLng) {
        return buildGraph(store, custLat, custLng, List.of()).shortestPath("S" + store.getStoreId(), "C");
    }

    private String label(RoadGraph.Path path) {
        StringBuilder sb = new StringBuilder();
        for (String n : path.nodes()) {
            if (sb.length() > 0) sb.append(" > ");
            sb.append(n.equals("C") ? "Customer" : storeRepository.findById(Long.valueOf(n.substring(1))).map(Store::getName).orElse(n));
        }
        return sb.toString();
    }

    /** Nearest available partner (not in `declined`) or empty when nobody is online & free. */
    public Optional<Assignment> assignNearest(CustomerOrder order, Set<Long> declined) {
        List<DeliveryPartner> free = new ArrayList<>();
        for (DeliveryPartner p : partnerRepository.findByStatusAndOnlineTrueAndBusyFalse(ApplicationStatus.APPROVED)) {
            if (p.latitude != null && p.longitude != null && !declined.contains(p.partnerId)) free.add(p);
        }
        if (free.isEmpty()) return Optional.empty();

        Store store = storeRepository.findById(order.storeId).orElseThrow();
        RoadGraph g = buildGraph(store, order.latitude, order.longitude, free);
        String src = "S" + store.getStoreId();

        Map<String, Double> dist = g.dijkstra(src, null);               // distance store -> every node
        NearestPartnerHeap heap = new NearestPartnerHeap();             // min-heap on pickup distance
        for (DeliveryPartner p : free) {
            Double d = dist.get("P" + p.partnerId);
            if (d != null) heap.add(p.partnerId, d);
        }
        NearestPartnerHeap.Candidate best = heap.pollNearest();
        RoadGraph.Path path = g.shortestPath(src, "C");
        if (best == null || path == null) return Optional.empty();

        DeliveryPartner chosen = free.stream().filter(p -> p.partnerId.equals(best.partnerId())).findFirst().orElseThrow();
        return Optional.of(new Assignment(chosen, best.km(), path.km(), label(path)));
    }
}
