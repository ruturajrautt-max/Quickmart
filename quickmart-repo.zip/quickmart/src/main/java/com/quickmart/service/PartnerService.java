package com.quickmart.service;

import com.quickmart.model.ApplicationStatus;
import com.quickmart.model.DeliveryPartner;
import com.quickmart.repository.DeliveryPartnerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class PartnerService {
    @Autowired private DeliveryPartnerRepository partners;

    public record ApplyReq(String name, String phone, String vehicle, String pin, Double lat, Double lng) {}

    public DeliveryPartner apply(ApplyReq r) {
        String phone = Validation.phone(r.phone());
        if (partners.findByPhone(phone).isPresent()) throw new IllegalArgumentException("This phone number already has a delivery application");
        Validation.location(r.lat(), r.lng());
        DeliveryPartner p = new DeliveryPartner();
        p.name = Validation.need(r.name(), "Name");
        p.vehicle = Validation.need(r.vehicle(), "Vehicle");
        p.phone = phone;
        p.pinHash = AuthService.hashPin(phone, Validation.pin(r.pin()));
        p.latitude = r.lat();
        p.longitude = r.lng();
        return partners.save(p);
    }

    public DeliveryPartner decide(Long id, boolean approve) {
        DeliveryPartner p = get(id);
        if (p.status != ApplicationStatus.PENDING) throw new IllegalArgumentException("Application already " + p.status);
        p.status = approve ? ApplicationStatus.APPROVED : ApplicationStatus.REJECTED;
        return partners.save(p);
    }

    public DeliveryPartner get(Long id) {
        return partners.findById(id).orElseThrow(() -> new IllegalArgumentException("Delivery partner not found"));
    }

    /** Go online/offline and/or update location (null = keep current value). */
    public DeliveryPartner update(Long id, Boolean online, Double lat, Double lng) {
        DeliveryPartner p = get(id);
        if (p.status != ApplicationStatus.APPROVED) throw new IllegalArgumentException("Your application is " + p.status);
        if (lat != null && lng != null) { p.latitude = lat; p.longitude = lng; }
        if (online != null) {
            if (!online && Boolean.TRUE.equals(p.busy)) throw new IllegalArgumentException("Finish or decline your active delivery before going offline");
            if (online && (p.latitude == null || p.longitude == null)) throw new IllegalArgumentException("Set your location first");
            p.online = online;
        }
        return partners.save(p);
    }
}
