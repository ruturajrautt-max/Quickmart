package com.quickmart.service;

import com.quickmart.model.*;
import com.quickmart.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Service
public class VendorService {
    @Autowired private VendorRepository vendors;
    @Autowired private StoreRepository stores;
    @Autowired private ItemRepository items;
    @Autowired private StoreInventoryRepository inventory;
    @Autowired private SearchService search;

    public record ApplyReq(String shopName, String ownerName, String phone, String email, String address,
                           Double lat, Double lng, String pin) {}
    public record ProductReq(Long itemId, String name, String category, String brand, String unitSize,
                             BigDecimal price, Integer stockQty, LocalDate expiryDate) {}
    public record ProductView(Long itemId, String name, String category, String brand, String unitSize,
                              BigDecimal price, Integer stockQty, LocalDate expiryDate) {}

    // ---- application + admin decision ----
    public Vendor apply(ApplyReq r) {
        String phone = Validation.phone(r.phone());
        if (vendors.findByPhone(phone).isPresent()) throw new IllegalArgumentException("This phone number already has a vendor application");
        Validation.location(r.lat(), r.lng());
        Vendor v = new Vendor();
        v.shopName = Validation.need(r.shopName(), "Shop name");
        v.ownerName = Validation.need(r.ownerName(), "Owner name");
        v.address = Validation.need(r.address(), "Address");
        v.email = r.email();
        v.phone = phone;
        v.latitude = r.lat();
        v.longitude = r.lng();
        v.pinHash = AuthService.hashPin(phone, Validation.pin(r.pin()));
        return vendors.save(v);
    }

    /** Approving creates the vendor's row in `stores`, so it joins price comparison and the delivery graph. */
    public Vendor decide(Long vendorId, boolean approve) {
        Vendor v = vendors.findById(vendorId).orElseThrow(() -> new IllegalArgumentException("Vendor not found"));
        if (v.status != ApplicationStatus.PENDING) throw new IllegalArgumentException("Application already " + v.status);
        if (approve) {
            Store s = stores.save(new Store(v.shopName, v.latitude, v.longitude, v.address));
            v.storeId = s.getStoreId();
            v.status = ApplicationStatus.APPROVED;
        } else {
            v.status = ApplicationStatus.REJECTED;
        }
        return vendors.save(v);
    }

    public Vendor get(Long vendorId) {
        return vendors.findById(vendorId).orElseThrow(() -> new IllegalArgumentException("Vendor not found"));
    }

    /** Store id of an approved vendor (403 otherwise). */
    public Long storeIdOf(Long vendorId) {
        Vendor v = get(vendorId);
        if (v.status != ApplicationStatus.APPROVED || v.storeId == null) throw new ResponseStatusException(HttpStatus.FORBIDDEN, "Vendor is not approved");
        return v.storeId;
    }

    // ---- products / prices / stock (rows of store_inventory for this vendor's store) ----
    public List<ProductView> products(Long vendorId) {
        List<ProductView> out = new ArrayList<>();
        for (StoreInventory inv : inventory.findByStoreId(storeIdOf(vendorId))) {
            items.findById(inv.getItemId()).ifPresent(it -> out.add(view(it, inv)));
        }
        out.sort((a, b) -> a.name().compareToIgnoreCase(b.name()));
        return out;
    }

    public ProductView saveProduct(Long vendorId, ProductReq r) {
        Long storeId = storeIdOf(vendorId);
        if (r.price() == null || r.price().signum() <= 0) throw new IllegalArgumentException("Price must be greater than 0");
        if (r.stockQty() == null || r.stockQty() < 0) throw new IllegalArgumentException("Stock cannot be negative");

        Item item;
        if (r.itemId() != null) {
            item = items.findById(r.itemId()).orElseThrow(() -> new IllegalArgumentException("Product not found"));
        } else {
            String name = Validation.need(r.name(), "Product name");
            item = items.findFirstByNormalizedName(Item.normalize(name)).orElse(null);
            if (item == null) {                                   // brand-new product -> catalog + Trie
                item = items.save(new Item(name, Validation.need(r.category(), "Category"),
                        r.brand() == null ? "" : r.brand().trim(), r.unitSize() == null ? "" : r.unitSize().trim()));
                search.index(item);
            }
        }
        StoreInventory inv = inventory.findById(new StoreInventory.StoreInventoryId(storeId, item.getItemId()))
                .orElseGet(() -> new StoreInventory(storeId, null, null, null, null));
        inv.setStoreId(storeId);
        inv.setItemId(item.getItemId());
        inv.setPrice(r.price());
        inv.setStockQty(r.stockQty());
        inv.setExpiryDate(r.expiryDate());
        return view(item, inventory.save(inv));
    }

    public void removeProduct(Long vendorId, Long itemId) {
        inventory.deleteById(new StoreInventory.StoreInventoryId(storeIdOf(vendorId), itemId));
    }

    private ProductView view(Item it, StoreInventory inv) {
        return new ProductView(it.getItemId(), it.getName(), it.getCategory(), it.getBrand(), it.getUnitSize(),
                inv.getPrice(), inv.getStockQty(), inv.getExpiryDate());
    }
}
