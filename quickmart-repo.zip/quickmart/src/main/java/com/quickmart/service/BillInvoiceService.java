package com.quickmart.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.quickmart.dto.*;
import com.quickmart.invoice.*;
import com.quickmart.model.BillImport;
import com.quickmart.model.Item;
import com.quickmart.model.OcrBill;
import com.quickmart.model.StoreInventory;
import com.quickmart.ocr.BillScanner;
import com.quickmart.repository.BillImportRepository;
import com.quickmart.repository.ItemRepository;
import com.quickmart.repository.OcrBillRepository;
import com.quickmart.repository.StoreInventoryRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.support.TransactionSynchronization;
import org.springframework.transaction.support.TransactionSynchronizationManager;
import org.springframework.web.server.ResponseStatusException;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

/**
 * Vendor bill workflow:  upload -> OCR + match (saved as a draft, inventory untouched) -> vendor edits (re-matched and
 * re-validated on the server) -> confirm (the ONLY step that changes stock, in one database transaction).
 *
 * All decisions live in the plain-Java classes of com.quickmart.invoice (tested without a database); this class adds
 * authorization (every bill is looked up by store id), persistence and the transaction.
 */
@Service
public class BillInvoiceService {
    private static final Logger log = LoggerFactory.getLogger(BillInvoiceService.class);
    private static final DateTimeFormatter WHEN = DateTimeFormatter.ofPattern("dd MMM yyyy, HH:mm");

    @Autowired private BillOcrService ocr;
    @Autowired private VendorService vendors;
    @Autowired private ItemRepository items;
    @Autowired private StoreInventoryRepository inventory;
    @Autowired private BillImportRepository imports;
    @Autowired private OcrBillRepository bills;
    @Autowired private SearchService search;
    @Autowired private ObjectMapper json;

    // ───────────────────────── upload (OCR runs outside any DB transaction) ─────────────────────────

    public InvoiceView upload(Long vendorId, byte[] data, String filename) {
        Long storeId = vendors.storeIdOf(vendorId);
        UploadValidator.Kind kind = UploadValidator.check(data, UploadValidator.MAX_BYTES);
        String hash = Hashing.sha256(data);

        imports.findByStoreIdAndBillHash(storeId, hash).ifPresent(b -> {
            throw new DuplicateBillException("FILE", WHEN.format(b.importedAt), "This exact bill was already added to your stock on " + WHEN.format(b.importedAt) + ".");
        });
        Optional<OcrBill> same = bills.findFirstByStoreIdAndFileHashOrderByBillIdDesc(storeId, hash);
        Snapshot snap = snapshot(storeId);
        LocalDate today = LocalDate.now();
        if (same.isPresent() && OcrBill.EXTRACTED.equals(same.get().status)) {          // same file again: continue the existing draft
            InvoiceView v = view(same.get());
            InvoiceAssembler.revalidate(v, snap, today);
            v.reusedExisting = true;
            return v;
        }

        List<BillScanner.Scan> scans = ocr.scanPages(data, filename);
        InvoiceView v = InvoiceAssembler.fromScans(scans, snap.matcher(), snap, today);
        OcrBill b = new OcrBill();
        b.storeId = storeId; b.vendorId = vendorId; b.fileHash = hash; b.fileType = kind.name();
        b.fileName = filename == null ? null : (filename.length() > 250 ? filename.substring(0, 250) : filename);
        b.status = OcrBill.EXTRACTED; b.ocrEngine = ocr.engineName(); b.ocrConfidence = v.ocrConfidence;
        StringBuilder raw = new StringBuilder();
        for (BillScanner.Scan s : scans) raw.append(s.text()).append('\n');
        b.rawText = raw.toString();
        bills.save(b);
        decorate(v, b);
        b.viewJson = write(v);
        bills.save(b);
        log.info("Bill {} scanned for store {}: {} rows, OCR confidence {}", b.billId, storeId, v.lines.size(), v.ocrConfidence);
        return v;
    }

    // ───────────────────────── read / list / discard ─────────────────────────

    public InvoiceView get(Long vendorId, Long billId) {
        return view(load(vendors.storeIdOf(vendorId), billId));
    }

    public List<BillSummaryDto> list(Long vendorId) {
        List<BillSummaryDto> out = new ArrayList<>();
        for (OcrBill b : bills.findTop30ByStoreIdOrderByBillIdDesc(vendors.storeIdOf(vendorId))) {
            InvoiceView v = read(b);
            BillSummaryDto s = new BillSummaryDto();
            s.billId = b.billId; s.status = b.status; s.fileName = b.fileName; s.ocrConfidence = b.ocrConfidence;
            s.createdAt = b.createdAt == null ? null : WHEN.format(b.createdAt);
            s.confirmedAt = b.confirmedAt == null ? null : WHEN.format(b.confirmedAt);
            s.supplierName = v.header.supplierName; s.invoiceNumber = v.header.invoiceNumber; s.invoiceDate = v.header.invoiceDate;
            s.grandTotal = v.header.grandTotal; s.lineCount = v.lines.size();
            out.add(s);
        }
        return out;
    }

    @Transactional
    public void discard(Long vendorId, Long billId) {
        OcrBill b = load(vendors.storeIdOf(vendorId), billId);
        if (OcrBill.CONFIRMED.equals(b.status)) throw new ResponseStatusException(HttpStatus.CONFLICT, "This bill was already added to your stock and cannot be discarded.");
        bills.delete(b);
    }

    // ───────────────────────── edit (draft only; never touches inventory) ─────────────────────────

    @Transactional
    public InvoiceView edit(Long vendorId, Long billId, InvoiceEdit edit) {
        Long storeId = vendors.storeIdOf(vendorId);
        OcrBill b = load(storeId, billId);
        requireDraft(b);
        if (edit == null || edit.lines == null) throw new IllegalArgumentException("Send the rows to save.");
        Snapshot snap = snapshot(storeId);
        InvoiceView v = InvoiceAssembler.applyEdit(read(b), edit, snap.matcher(), snap, LocalDate.now());
        decorate(v, b);
        b.viewJson = write(v);
        b.updatedAt = LocalDateTime.now();
        bills.save(b);
        return v;
    }

    public List<SuggestionDto> suggest(Long vendorId, Long billId, MatchRequest req) {
        Long storeId = vendors.storeIdOf(vendorId);
        OcrBill b = load(storeId, billId);
        String text = req == null ? null : req.text;
        String pack = req == null ? null : req.packSize;
        if ((text == null || text.isBlank()) && req != null && req.lineId != null) {
            for (InvoiceLineDto l : read(b).lines) if (req.lineId.equals(l.lineId)) { text = l.name; if (pack == null) pack = l.packSize; }
        }
        if (text == null || text.isBlank()) throw new IllegalArgumentException("Type part of the product name to search for.");
        Snapshot snap = snapshot(storeId);
        return InvoiceAssembler.suggest(text, pack, snap.matcher(), snap);
    }

    // ───────────────────────── confirm: the only code that changes stock ─────────────────────────

    /**
     * One transaction: if anything fails after the first write (database error, concurrent duplicate hitting the unique
     * constraint, ...) every change is rolled back, so a bill is never half-applied.
     */
    @Transactional
    public ConfirmResult confirm(Long vendorId, Long billId, InvoiceEdit edit) {
        Long storeId = vendors.storeIdOf(vendorId);
        OcrBill b = load(storeId, billId);
        if (OcrBill.CONFIRMED.equals(b.status)) {
            String when = b.confirmedAt == null ? "earlier" : WHEN.format(b.confirmedAt);
            throw new DuplicateBillException("FILE", when, "This bill was already added to your stock on " + when + ".");
        }
        if (edit == null || edit.lines == null || edit.lines.isEmpty()) throw new IllegalArgumentException("Send the reviewed rows to confirm.");

        Snapshot snap = snapshot(storeId);
        LocalDate today = LocalDate.now();
        InvoiceView finalView = InvoiceAssembler.applyEdit(read(b), edit, snap.matcher(), snap, today);   // what the vendor approved, for the record

        JpaPorts ports = new JpaPorts(storeId, b.billId, snap);
        ConfirmResult res;
        try {
            res = BillConfirmation.confirm(edit, b.fileHash, today, ports, ports);
        } catch (DataIntegrityViolationException e) {                    // unique constraint: another request added this bill first
            throw new DuplicateBillException("FILE", "just now", "This bill was added a moment ago by another request, so nothing was changed.");
        }

        b.status = OcrBill.CONFIRMED;
        b.confirmedAt = LocalDateTime.now();
        b.updatedAt = b.confirmedAt;
        decorate(finalView, b);
        b.viewJson = write(finalView);
        bills.save(b);
        res.billId = b.billId;

        List<Item> created = ports.created;
        if (!created.isEmpty() && TransactionSynchronizationManager.isSynchronizationActive()) {
            TransactionSynchronizationManager.registerSynchronization(new TransactionSynchronization() {
                @Override public void afterCommit() { for (Item it : created) search.index(it); }    // searchable only if the data really committed
            });
        }
        log.info("Bill {} confirmed for store {}: {}", b.billId, storeId, res.message);
        return res;
    }

    // ───────────────────────── helpers ─────────────────────────

    private OcrBill load(Long storeId, Long billId) {
        return bills.findByBillIdAndStoreId(billId, storeId).orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Bill not found"));
    }

    private static void requireDraft(OcrBill b) {
        if (!OcrBill.EXTRACTED.equals(b.status)) throw new ResponseStatusException(HttpStatus.CONFLICT, "This bill was already added to your stock and can no longer be edited.");
    }

    private InvoiceView view(OcrBill b) {
        InvoiceView v = read(b);
        decorate(v, b);
        return v;
    }

    private InvoiceView read(OcrBill b) {
        try {
            return json.readValue(b.viewJson, InvoiceView.class);
        } catch (JsonProcessingException | RuntimeException e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "The saved bill data could not be read. Upload the bill again.");
        }
    }

    private String write(InvoiceView v) {
        try { return json.writeValueAsString(v); }
        catch (JsonProcessingException e) { throw new IllegalStateException("Could not save the bill data", e); }
    }

    private static void decorate(InvoiceView v, OcrBill b) {
        v.billId = b.billId; v.status = b.status; v.fileName = b.fileName; v.fileHash = b.fileHash; v.ocrEngine = b.ocrEngine;
        if (b.ocrConfidence != null) v.ocrConfidence = b.ocrConfidence;
        v.createdAt = b.createdAt == null ? null : WHEN.format(b.createdAt);
        v.confirmedAt = b.confirmedAt == null ? null : WHEN.format(b.confirmedAt);
        if (OcrBill.CONFIRMED.equals(b.status)) v.canConfirm = false;
    }

    private Snapshot snapshot(Long storeId) {
        Snapshot s = new Snapshot();
        for (Item it : items.findAll()) { s.byId.put(it.getItemId(), it); s.byName.putIfAbsent(Item.normalize(it.getName()), it); }
        for (StoreInventory inv : inventory.findByStoreId(storeId)) s.inv.put(inv.getItemId(), inv);
        return s;
    }

    /** Catalog + this shop's stock, read once per request. */
    private static final class Snapshot implements StockPlanner.Catalog {
        final Map<Long, Item> byId = new HashMap<>();
        final Map<String, Item> byName = new HashMap<>();
        final Map<Long, StoreInventory> inv = new HashMap<>();

        private static StockPlanner.ItemInfo info(Item i) { return new StockPlanner.ItemInfo(i.getItemId(), i.getName(), i.getCategory(), i.getBrand(), i.getUnitSize()); }
        @Override public Optional<StockPlanner.ItemInfo> item(long id) { return Optional.ofNullable(byId.get(id)).map(Snapshot::info); }
        @Override public Optional<StockPlanner.ItemInfo> byNormalizedName(String n) { return Optional.ofNullable(byName.get(n)).map(Snapshot::info); }
        @Override public Integer stockOf(long id) { StoreInventory s = inv.get(id); return s == null ? null : (s.getStockQty() == null ? 0 : s.getStockQty()); }

        ProductMatcher matcher() {
            List<ProductMatcher.Candidate> c = new ArrayList<>();
            for (Item i : byId.values()) c.add(new ProductMatcher.Candidate(i.getItemId(), i.getName(), i.getBrand(), i.getUnitSize(), i.getCategory(), inv.containsKey(i.getItemId()), stockOf(i.getItemId())));
            return new ProductMatcher(c);
        }
    }

    /** JPA implementation of the ports used by BillConfirmation. Runs inside confirm()'s transaction. */
    private final class JpaPorts implements BillConfirmation.InventoryPort, BillConfirmation.ImportLedger {
        private final Long storeId, billId;
        private final Snapshot snap;
        final List<Item> created = new ArrayList<>();

        JpaPorts(Long storeId, Long billId, Snapshot snap) { this.storeId = storeId; this.billId = billId; this.snap = snap; }

        @Override public Optional<StockPlanner.ItemInfo> item(long id) { return snap.item(id); }
        @Override public Optional<StockPlanner.ItemInfo> byNormalizedName(String n) { return snap.byNormalizedName(n); }
        @Override public Integer stockOf(long id) { return snap.stockOf(id); }

        @Override public long createItem(String name, String category, String brand, String unitSize) {
            Item it = items.save(new Item(name, category, brand, unitSize));
            created.add(it);
            return it.getItemId();
        }
        @Override public void addStock(long itemId, int units) {
            if (inventory.addStock(storeId, itemId, units) != 1) throw new IllegalStateException("Stock row for item " + itemId + " disappeared; nothing was changed.");
        }
        @Override public void createStockRow(long itemId, BigDecimal price, int units) { inventory.save(new StoreInventory(storeId, itemId, price, units, null)); }
        @Override public void setPrice(long itemId, BigDecimal price) { inventory.setPrice(storeId, itemId, price); }

        @Override public Optional<String> fileImportedOn(String fileHash) {
            return imports.findByStoreIdAndBillHash(storeId, fileHash).map(b -> WHEN.format(b.importedAt));
        }
        @Override public Optional<String> invoiceImportedOn(String invoiceKey) {
            return imports.findByStoreIdAndInvoiceKey(storeId, invoiceKey).map(b -> WHEN.format(b.importedAt));
        }
        @Override public void record(String fileHash, String invoiceKey, String summary) {
            BillImport r = new BillImport();
            r.storeId = storeId; r.billHash = fileHash; r.invoiceKey = invoiceKey; r.summary = summary; r.ocrBillId = billId;
            imports.saveAndFlush(r);              // flush now: the unique constraints reject a concurrent duplicate before any stock changes
        }
    }
}
