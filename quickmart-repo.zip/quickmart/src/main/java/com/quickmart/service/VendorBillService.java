package com.quickmart.service;

import com.quickmart.model.BillImport;
import com.quickmart.model.Item;
import com.quickmart.model.StoreInventory;
import com.quickmart.repository.BillImportRepository;
import com.quickmart.repository.ItemRepository;
import com.quickmart.repository.StoreInventoryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.format.DateTimeFormatter;
import java.util.*;

/**
 * Vendor flow: "add the stock from my distributor's bill".
 *   scan  -> read the bill, match lines to catalog items, show current stock next to what the bill says (nothing is saved)
 *   apply -> the vendor confirms (and can fix) the lines; quantities are ADDED to current stock
 *
 * The rate on a distributor bill is the vendor's COST price, not the selling price, so existing selling prices are
 * never overwritten from the bill; the vendor types a selling price only for products new to their shop.
 */
@Service
public class VendorBillService {
    @Autowired private BillParsingService parsing;
    @Autowired private VendorService vendors;
    @Autowired private StoreInventoryRepository inventory;
    @Autowired private ItemRepository items;
    @Autowired private BillImportRepository imports;
    @Autowired private SearchService search;

    public static class StockLine {
        public String billText;
        public int billQty;
        public BigDecimal billRate;          // distributor's rate (cost price)
        public boolean needsReview;
        public boolean sizeMismatch;
        public double matchConfidence;
        public Long itemId;                  // null = not in the catalog yet (would become a new product)
        public String itemName, category, brand, unitSize;
        public Integer currentStock;         // null if this shop has never stocked it
        public BigDecimal currentPrice;      // this shop's selling price, null if never stocked
    }

    public static class ScanView {
        public String billHash;
        public boolean alreadyImported;
        public String importedOn;
        public List<StockLine> lines = new ArrayList<>();
        public List<String> unreadable = new ArrayList<>();
    }

    public record ApplyLine(Long itemId, String name, String category, String brand, String unitSize, Integer qty, BigDecimal price) {}
    public record ApplyReq(String billHash, List<ApplyLine> lines) {}

    // ───────────────────────── scan (read only) ─────────────────────────

    public ScanView scan(Long vendorId, byte[] data, String filename) {
        Long storeId = vendors.storeIdOf(vendorId);
        BillParsingService.ScanResult scan = parsing.scan(data, filename);
        ScanView view = new ScanView();
        view.billHash = scan.billHash;
        view.unreadable = scan.unreadable;
        imports.findByStoreIdAndBillHash(storeId, scan.billHash).ifPresent(b -> {
            view.alreadyImported = true;
            view.importedOn = b.importedAt.format(DateTimeFormatter.ofPattern("dd MMM yyyy, HH:mm"));
        });

        for (BillParsingService.ParsedLine l : scan.lines) {
            StockLine s = new StockLine();
            s.billText = l.rawName;
            s.billQty = l.quantity;
            s.billRate = l.price;
            s.needsReview = l.needsReview;
            s.sizeMismatch = l.sizeMismatch;
            s.matchConfidence = l.matchConfidence;
            if (l.matchedItem != null) {
                Item it = l.matchedItem;
                s.itemId = it.getItemId();
                s.itemName = it.getName();
                s.category = it.getCategory();
                s.brand = it.getBrand();
                s.unitSize = it.getUnitSize();
                inventory.findById(new StoreInventory.StoreInventoryId(storeId, it.getItemId())).ifPresent(inv -> {
                    s.currentStock = inv.getStockQty();
                    s.currentPrice = inv.getPrice();
                });
            } else {
                s.itemName = l.rawName;      // the vendor can rename it and pick a category before adding it as a new product
            }
            view.lines.add(s);
        }
        return view;
    }

    // ───────────────────────── apply (writes) ─────────────────────────

    private static final class Plan {
        Item item; String newName, newCategory, newBrand, newUnit;
        int qty; BigDecimal price;
    }

    @Transactional
    public List<VendorService.ProductView> apply(Long vendorId, ApplyReq req) {
        Long storeId = vendors.storeIdOf(vendorId);
        if (req == null || req.lines() == null || req.lines().isEmpty()) throw new IllegalArgumentException("Select at least one line to add");
        String hash = Validation.need(req.billHash(), "Bill reference");
        if (imports.findByStoreIdAndBillHash(storeId, hash).isPresent()) {
            throw new IllegalArgumentException("This bill was already added to your stock. Use the Products tab to correct quantities by hand.");
        }

        // pass 1: validate everything (and merge duplicate lines) before touching the database
        Map<String, Plan> plans = new LinkedHashMap<>();
        for (ApplyLine l : req.lines()) {
            if (l.qty() == null || l.qty() < 1) throw new IllegalArgumentException("Quantity must be at least 1" + label(l));
            Plan p = new Plan();
            p.qty = l.qty();
            p.price = l.price();
            String key;
            StoreInventory existing = null;
            if (l.itemId() != null) {
                p.item = items.findById(l.itemId()).orElseThrow(() -> new IllegalArgumentException("Product not found" + label(l)));
                existing = inventory.findById(new StoreInventory.StoreInventoryId(storeId, p.item.getItemId())).orElse(null);
                key = "i" + p.item.getItemId();
            } else {
                p.newName = Validation.need(l.name(), "Product name");
                Item known = items.findFirstByNormalizedName(Item.normalize(p.newName)).orElse(null);   // already in catalog under that name
                if (known != null) {
                    p.item = known;
                    existing = inventory.findById(new StoreInventory.StoreInventoryId(storeId, known.getItemId())).orElse(null);
                    key = "i" + known.getItemId();
                } else {
                    p.newCategory = Validation.need(l.category(), "Category for " + p.newName);
                    p.newBrand = l.brand() == null ? "" : l.brand().trim();
                    p.newUnit = l.unitSize() == null ? "" : l.unitSize().trim();
                    key = "n" + Item.normalize(p.newName);
                }
            }
            boolean priceGiven = p.price != null && p.price.signum() > 0;
            if (existing == null && !priceGiven) {
                throw new IllegalArgumentException("Enter a selling price for " + (p.item != null ? p.item.getName() : p.newName));
            }
            Plan merged = plans.get(key);
            if (merged == null) plans.put(key, p);
            else { merged.qty += p.qty; if (priceGiven) merged.price = p.price; }      // same product twice on one bill
        }

        // pass 2: write
        List<Long> touched = new ArrayList<>();
        for (Plan p : plans.values()) {
            Item item = p.item;
            if (item == null) {                                                          // brand-new product -> catalog + Trie search
                item = items.save(new Item(p.newName, p.newCategory, p.newBrand, p.newUnit));
                search.index(item);
            }
            StoreInventory inv = inventory.findById(new StoreInventory.StoreInventoryId(storeId, item.getItemId())).orElse(null);
            if (inv == null) {
                inv = new StoreInventory(storeId, item.getItemId(), p.price, 0, null);
            } else if (p.price != null && p.price.signum() > 0) {
                inv.setPrice(p.price);                                                    // only when the vendor typed a new selling price
            }
            inv.setStockQty((inv.getStockQty() == null ? 0 : inv.getStockQty()) + p.qty);
            inventory.save(inv);
            touched.add(item.getItemId());
        }

        BillImport rec = new BillImport();
        rec.storeId = storeId;
        rec.billHash = hash;
        rec.summary = plans.size() + " products, " + plans.values().stream().mapToInt(x -> x.qty).sum() + " units";
        imports.save(rec);

        List<VendorService.ProductView> out = new ArrayList<>();
        for (VendorService.ProductView v : vendors.products(vendorId)) if (touched.contains(v.itemId())) out.add(v);
        return out;
    }

    private static String label(ApplyLine l) {
        String n = l.name() != null && !l.name().isBlank() ? l.name() : (l.itemId() != null ? "item #" + l.itemId() : "");
        return n.isEmpty() ? "" : " (" + n + ")";
    }
}
