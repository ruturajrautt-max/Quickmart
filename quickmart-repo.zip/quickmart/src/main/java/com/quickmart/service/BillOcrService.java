package com.quickmart.service;

import com.quickmart.invoice.InvalidBillUploadException;
import com.quickmart.ocr.*;
import jakarta.annotation.PostConstruct;
import net.sourceforge.tess4j.util.PdfUtilities;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.imageio.ImageIO;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.*;
import java.util.concurrent.Semaphore;
import java.util.concurrent.TimeUnit;

/**
 * Runs OCR on an uploaded bill (JPG / PNG / PDF).
 *
 *   image -> ImagePreprocessor (gray, denoise, deskew, contrast, adaptive threshold, ruling-line removal)
 *         -> Tess4J (primary) or the `tesseract` command (automatic fallback) -> BillScanner (several attempts, best one wins)
 *
 * The tessdata folder is auto-detected (config value, TESSDATA_PREFIX, usual install folders). Any engine problem is
 * reported as {@link OcrUnavailableException} (HTTP 503) with what to install; /api/bills/health shows the details.
 * At most {@code ocr.max-concurrent} bills are OCR'd at once so a few uploads cannot starve the whole server.
 */
@Service
public class BillOcrService {
    private static final Logger log = LoggerFactory.getLogger(BillOcrService.class);

    /** OCR engine missing or broken: reported to the client as HTTP 503 with a readable message. */
    public static class OcrUnavailableException extends RuntimeException {
        public OcrUnavailableException(String msg) { super(msg); }
    }

    /** What one uploaded file produced (a PDF can have several pages). */
    public static class Output {
        public final String text;
        public final BillTextParser.Result parsed;
        Output(String text, BillTextParser.Result parsed) { this.text = text; this.parsed = parsed; }
    }

    private static final int MAX_PDF_PAGES = 8;

    @Value("${tesseract.datapath:}") private String configuredDatapath;
    @Value("${tesseract.command:tesseract}") private String cliCommand;
    @Value("${tesseract.language:eng}") private String language;
    @Value("${tesseract.timeout-seconds:90}") private long timeoutSeconds;
    @Value("${ocr.max-concurrent:2}") private int maxConcurrent;
    @Value("${ocr.queue-wait-seconds:60}") private long queueWaitSeconds;

    private volatile String datapath;
    private volatile FallbackOcrEngine engine;
    private volatile TesseractCliEngine cli;
    private Semaphore slots;

    @PostConstruct
    void init() {
        String os = System.getProperty("os.name", "").toLowerCase(Locale.ROOT);
        if (os.contains("mac") && System.getProperty("jna.library.path") == null && new File("/opt/homebrew/lib").isDirectory()) {
            System.setProperty("jna.library.path", "/opt/homebrew/lib");      // Homebrew on Apple Silicon: where libtesseract lives
        }
        datapath = resolveDatapath();
        cli = new TesseractCliEngine(cliCommand, datapath, language, 6, timeoutSeconds);
        engine = new FallbackOcrEngine(new Tess4JEngine(datapath, language, 6), cli);
        slots = new Semaphore(Math.max(1, maxConcurrent), true);
        log.info("OCR: tessdata folder = {}, language = {}, max concurrent = {}", datapath == null ? "(not found, using Tesseract default)" : datapath, language, maxConcurrent);
    }

    // ───────────────────────── public API ─────────────────────────

    /** Reads every page and returns one {@link BillScanner.Scan} per page (header, rows, per-line confidence). */
    public List<BillScanner.Scan> scanPages(byte[] data, String filename) {
        if (data == null || data.length == 0) throw new IllegalArgumentException("The uploaded file is empty");
        List<BufferedImage> pages = isPdf(data, filename) ? pdfPages(data) : List.of(loadImage(data));
        boolean got = false;
        try { got = slots.tryAcquire(queueWaitSeconds, TimeUnit.SECONDS); } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
        if (!got) throw new OcrUnavailableException("The server is busy reading other bills. Please try again in a minute.");
        try {
            List<BillScanner.Scan> scans = new ArrayList<>();
            for (BufferedImage page : pages) {
                if (ImagePreprocessor.isBlank(page)) continue;                         // an empty page: nothing to read
                try {
                    scans.add(BillScanner.scan(page, engine));
                } catch (OcrException e) {
                    throw translate(e);
                }
            }
            if (scans.isEmpty()) throw new InvalidBillUploadException(422, "The picture looks blank, so no text could be read. Upload a photo of the bill.");
            if (log.isDebugEnabled()) for (BillScanner.Scan s : scans) log.debug("OCR TEXT >>>\n{}\n<<<", s.text());
            return scans;
        } finally {
            slots.release();
        }
    }

    /** Used by the older customer "reorder" and vendor "scan" flows: combined text and parsed rows. */
    public Output read(byte[] data, String filename) {
        List<BillScanner.Scan> scans = scanPages(data, filename);
        StringBuilder text = new StringBuilder();
        BillTextParser.Result all = new BillTextParser.Result();
        for (BillScanner.Scan s : scans) {
            text.append(s.text()).append('\n');
            all.items.addAll(s.parsed.items);
            all.unreadable.addAll(s.parsed.unreadable);
        }
        return new Output(text.toString(), all);
    }

    public String engineName() { return engine == null ? "none" : engine.name(); }

    /** Self-test for GET /api/bills/health: reports the Tesseract install and reads a generated line of text through the real pipeline. */
    public Map<String, Object> health() {
        Map<String, Object> out = new LinkedHashMap<>();
        out.put("tessdataFolder", datapath == null ? "not found (Tesseract default will be used)" : datapath);
        out.put("language", language);
        TesseractCliEngine.Diagnosis d = cli.diagnose();
        out.put("tesseractVersion", d.version.isEmpty() ? "not found" : d.version);
        out.put("installedLanguages", d.languages);
        out.put("commandLineProblem", d.problem.isEmpty() ? "none" : d.problem);
        try {
            BufferedImage img = new BufferedImage(900, 160, BufferedImage.TYPE_INT_RGB);
            Graphics2D g = img.createGraphics();
            g.setColor(Color.WHITE);
            g.fillRect(0, 0, 900, 160);
            g.setColor(Color.BLACK);
            g.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 64));
            g.drawString("QuickMart 4821", 40, 100);
            g.dispose();
            OcrPage page = engine.read(ImagePreprocessor.prepare(img));
            String text = page.text().trim();
            out.put("ok", text.replace(" ", "").contains("4821"));
            out.put("textRead", text);
            out.put("selfTestConfidence", Math.round(page.meanConfidence() * 10) / 10.0);
        } catch (OcrException | RuntimeException | LinkageError e) {
            out.put("ok", false);
            out.put("error", String.valueOf(e.getMessage()));
        }
        out.put("engineUsed", engine.name());
        out.put("tess4jProblem", engine.primaryProblem().isEmpty() ? "none" : engine.primaryProblem());
        out.put("busySlots", Math.max(1, maxConcurrent) - slots.availablePermits());
        return out;
    }

    // ───────────────────────── errors ─────────────────────────

    private RuntimeException translate(OcrException e) {
        return switch (e.reason) {
            case FAILED -> new InvalidBillUploadException(422, "This picture could not be read: " + e.getMessage());
            case TIMEOUT -> new OcrUnavailableException("Reading the bill took too long. Try a smaller or clearer image. " + e.getMessage());
            default -> new OcrUnavailableException("OCR is not working on the server. Install Tesseract "
                    + "(Windows: github.com/UB-Mannheim/tesseract/wiki, Ubuntu: sudo apt install tesseract-ocr, macOS: brew install tesseract) "
                    + "and set tesseract.datapath / tesseract.command in application.properties. Open /api/bills/health for details. " + e.getMessage());
        };
    }

    // ───────────────────────── input handling ─────────────────────────

    private static boolean isPdf(byte[] d, String name) {
        boolean magic = d.length > 4 && d[0] == '%' && d[1] == 'P' && d[2] == 'D' && d[3] == 'F';
        return magic || (name != null && name.toLowerCase(Locale.ROOT).endsWith(".pdf"));
    }

    private static BufferedImage loadImage(byte[] data) {
        try {
            BufferedImage img = ImageIO.read(new ByteArrayInputStream(data));
            if (img == null) throw new InvalidBillUploadException(415, "Unsupported file. Please upload a JPG, PNG or PDF bill.");
            return img;
        } catch (IOException e) {
            throw new InvalidBillUploadException(422, "Could not read that image. Please upload a JPG, PNG or PDF bill.");
        }
    }

    /** PDF -> one PNG per page (Tess4J ships PDFBox for this), first few pages only. */
    private static List<BufferedImage> pdfPages(byte[] data) {
        File pdf = null;
        File[] pngs = new File[0];
        try {
            pdf = File.createTempFile("qm_bill_", ".pdf");
            Files.write(pdf.toPath(), data);
            pngs = PdfUtilities.convertPdf2Png(pdf);
            List<BufferedImage> pages = new ArrayList<>();
            for (int i = 0; i < Math.min(pngs.length, MAX_PDF_PAGES); i++) pages.add(ImageIO.read(pngs[i]));
            if (pages.isEmpty()) throw new InvalidBillUploadException(422, "That PDF has no pages");
            return pages;
        } catch (IOException | RuntimeException e) {
            if (e instanceof InvalidBillUploadException ex) throw ex;
            throw new InvalidBillUploadException(422, "Could not open that PDF: " + e.getMessage());
        } finally {
            if (pdf != null) pdf.delete();
            for (File f : pngs) f.delete();
        }
    }

    // ───────────────────────── tessdata detection ─────────────────────────

    private String resolveDatapath() {
        List<String> candidates = new ArrayList<>();
        if (configuredDatapath != null && !configuredDatapath.isBlank()) candidates.add(configuredDatapath.trim());
        String env = System.getenv("TESSDATA_PREFIX");
        if (env != null && !env.isBlank()) { candidates.add(env); candidates.add(env + "/tessdata"); }
        candidates.addAll(List.of(
                "C:/Program Files/Tesseract-OCR/tessdata", "C:/Program Files (x86)/Tesseract-OCR/tessdata",
                "/usr/share/tesseract-ocr/5/tessdata", "/usr/share/tesseract-ocr/4.00/tessdata", "/usr/share/tessdata",
                "/usr/local/share/tessdata", "/opt/homebrew/share/tessdata"));
        String firstLang = language.split("\\+")[0];
        for (String c : candidates) {
            if (new File(c, firstLang + ".traineddata").isFile()) return c;
        }
        return null;
    }
}
