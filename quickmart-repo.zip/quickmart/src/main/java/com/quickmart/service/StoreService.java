package com.quickmart.service;

import com.quickmart.model.Item;
import com.quickmart.model.Store;
import com.quickmart.model.StoreInventory;
import com.quickmart.repository.ItemRepository;
import com.quickmart.repository.StoreInventoryRepository;
import com.quickmart.repository.StoreRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.*;

/** Store locator + stock lookup: search stores by name/area, or by an item they stock, and see how many units are left. */
@Service
public class StoreService {
    @Autowired private StoreRepository stores;
    @Autowired private StoreInventoryRepository inventory;
    @Autowired private ItemRepository items;

    public record StockRow(Long itemId, String name, String brand, String category, String unitSize,
                           BigDecimal price, int stockQty, String level) {}
    public record StoreView(Long storeId, String name, String address, Double lat, Double lng,
                            Double distKm, int itemCount, int unitsLeft, List<StockRow> matches) {}

    private static String level(int qty) { return qty <= 0 ? "OUT" : qty <= 5 ? "LOW" : "IN"; }

    private StockRow row(StoreInventory inv, Item it) {
        int q = inv.getStockQty() == null ? 0 : inv.getStockQty();
        return new StockRow(it.getItemId(), it.getName(), it.getBrand(), it.getCategory(), it.getUnitSize(),
                inv.getPrice(), q, level(q));
    }

    private static boolean has(String text, String q) { return text != null && text.toLowerCase().contains(q); }

    /** q blank = every active store. Otherwise stores whose name/address match OR that stock an item matching q. */
    public List<StoreView> search(String rawQ, Double lat, Double lng) {
        String q = rawQ == null ? "" : rawQ.trim().toLowerCase();
        Map<Long, Item> itemById = new HashMap<>();
        for (Item i : items.findAll()) itemById.put(i.getItemId(), i);

        List<StoreView> out = new ArrayList<>();
        for (Store s : stores.findAll()) {
            if (!Boolean.TRUE.equals(s.getIsActive())) continue;
            List<StoreInventory> inv = inventory.findByStoreId(s.getStoreId());
            int units = 0, count = 0;
            List<StockRow> matches = new ArrayList<>();
            for (StoreInventory si : inv) {
                Item it = itemById.get(si.getItemId());
                if (it == null) continue;
                int qty = si.getStockQty() == null ? 0 : si.getStockQty();
                units += qty;
                if (qty > 0) count++;
                if (!q.isEmpty() && (has(it.getName(), q) || has(it.getBrand(), q) || has(it.getCategory(), q))) matches.add(row(si, it));
            }
            boolean storeHit = q.isEmpty() || has(s.getName(), q) || has(s.getAddress(), q);
            if (!storeHit && matches.isEmpty()) continue;
            matches.sort(Comparator.comparing(StockRow::name));
            Double d = (lat != null && lng != null && s.getLatitude() != null && s.getLongitude() != null)
                    ? Math.round(s.distanceTo(lat, lng) * 10) / 10.0 : null;
            out.add(new StoreView(s.getStoreId(), s.getName(), s.getAddress(), s.getLatitude(), s.getLongitude(), d, count, units, matches));
        }
        out.sort(Comparator.comparing((StoreView v) -> v.distKm() == null ? Double.MAX_VALUE : v.distKm()).thenComparing(StoreView::name));
        return out;
    }

    /** Full stock list of one store, optionally filtered by item name / brand / category. */
    public List<StockRow> stock(Long storeId, String rawQ) {
        if (!stores.existsById(storeId)) throw new IllegalArgumentException("Store not found");
        String q = rawQ == null ? "" : rawQ.trim().toLowerCase();
        List<StockRow> out = new ArrayList<>();
        for (StoreInventory si : inventory.findByStoreId(storeId)) {
            Item it = items.findById(si.getItemId()).orElse(null);
            if (it == null) continue;
            if (q.isEmpty() || has(it.getName(), q) || has(it.getBrand(), q) || has(it.getCategory(), q)) out.add(row(si, it));
        }
        out.sort(Comparator.comparing(StockRow::name));
        return out;
    }
}
