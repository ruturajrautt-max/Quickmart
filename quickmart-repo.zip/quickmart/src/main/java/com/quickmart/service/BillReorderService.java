package com.quickmart.service;

import com.quickmart.model.Item;
import com.quickmart.model.Store;
import com.quickmart.model.StoreInventory;
import com.quickmart.repository.StoreInventoryRepository;
import com.quickmart.repository.StoreRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.*;

/**
 * Customer flow: "reorder from my old bill". The bill is read, every line is matched to a catalog item, and for each
 * item we look up which stores have it in stock RIGHT NOW (the price printed on the old bill is not reused,
 * it came from some other shop). The cheapest store that can cover the quantity is suggested, with alternatives.
 */
@Service
public class BillReorderService {
    @Autowired private BillParsingService parsing;
    @Autowired private StoreInventoryRepository inventory;
    @Autowired private StoreRepository stores;

    public static class Offer {
        public Long storeId;
        public String storeName;
        public BigDecimal price;
        public double distanceKm;
        public int stock;
    }

    public static class Row {
        public String billText;            // what the bill said
        public int billQty;
        public boolean needsReview;        // OCR could not confirm qty x rate = amount on this line
        public boolean sizeMismatch;       // matched product has a different pack size than the bill
        public double matchConfidence;
        public Long itemId;                // null when the product is not in the catalog
        public String itemName;
        public String unitSize;
        public String status;              // OK | LOW_STOCK | NO_STOCK | NOT_FOUND
        public int suggestedQty;           // billQty, or what the best store can actually supply
        public List<Offer> offers = new ArrayList<>();   // cheapest first; offers.get(0) is the suggestion
    }

    public static class Reorder {
        public List<Row> rows = new ArrayList<>();
        public List<String> unreadable = new ArrayList<>();
    }

    public Reorder fromBill(byte[] data, String filename, double lat, double lng) {
        BillParsingService.ScanResult scan = parsing.scan(data, filename);
        Reorder out = new Reorder();
        out.unreadable = scan.unreadable;

        for (BillParsingService.ParsedLine line : scan.lines) {
            Row row = new Row();
            row.billText = line.rawName;
            row.billQty = line.quantity;
            row.needsReview = line.needsReview;
            row.sizeMismatch = line.sizeMismatch;
            row.matchConfidence = line.matchConfidence;

            Item item = line.matchedItem;
            if (item == null) {
                row.status = "NOT_FOUND";
                row.suggestedQty = line.quantity;
                out.rows.add(row);
                continue;
            }
            row.itemId = item.getItemId();
            row.itemName = item.getName();
            row.unitSize = item.getUnitSize();
            row.offers = offersFor(item.getItemId(), lat, lng);

            if (row.offers.isEmpty()) {
                row.status = "NO_STOCK";
                row.suggestedQty = line.quantity;
            } else {
                // cheapest store that can cover the whole quantity goes first
                Offer firstFull = row.offers.stream().filter(o -> o.stock >= line.quantity).findFirst().orElse(null);
                if (firstFull != null) {
                    row.offers.remove(firstFull);
                    row.offers.add(0, firstFull);
                    row.status = "OK";
                    row.suggestedQty = line.quantity;
                } else {                                         // nobody has enough: suggest the store with the most stock
                    Offer most = Collections.max(row.offers, Comparator.comparingInt(o -> o.stock));
                    row.offers.remove(most);
                    row.offers.add(0, most);
                    row.status = "LOW_STOCK";
                    row.suggestedQty = most.stock;
                }
            }
            out.rows.add(row);
        }
        return out;
    }

    private List<Offer> offersFor(Long itemId, double lat, double lng) {
        List<Offer> offers = new ArrayList<>();
        for (StoreInventory inv : inventory.findByItemIdAndStockQtyGreaterThan(itemId, 0)) {
            Store s = stores.findById(inv.getStoreId()).orElse(null);
            if (s == null || !Boolean.TRUE.equals(s.getIsActive())) continue;
            Offer o = new Offer();
            o.storeId = s.getStoreId();
            o.storeName = s.getName();
            o.price = inv.getPrice();
            o.distanceKm = Math.round(s.distanceTo(lat, lng) * 10) / 10.0;
            o.stock = inv.getStockQty();
            offers.add(o);
        }
        offers.sort(Comparator.comparing((Offer o) -> o.price).thenComparingDouble(o -> o.distanceKm));
        return offers;
    }
}
