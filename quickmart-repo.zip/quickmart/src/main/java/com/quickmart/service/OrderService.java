package com.quickmart.service;

import com.quickmart.dsa.OrderQueue;
import com.quickmart.dsa.StatusStack;
import com.quickmart.model.*;
import com.quickmart.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;
import org.springframework.http.HttpStatus;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.*;

/**
 * Order life-cycle:  PLACED -> CONFIRMED -> PREPARING -> READY -> PICKED_UP -> DELIVERED  (or CANCELLED)
 *
 *  Queue : every new order joins a FIFO OrderQueue; a scheduler serves it oldest-first
 *          (check stock, find nearest partner, reserve stock, confirm).
 *  Stack : every status change is pushed on a StatusStack -> current status (peek), history
 *          (newest first) and the store's "undo last step" (pop).
 *  Graph/Dijkstra/Heap are used through DeliveryNetworkService when an order is confirmed.
 */
@Service
public class OrderService {
    @Autowired private CustomerOrderRepository orders;
    @Autowired private OrderLineRepository lines;
    @Autowired private OrderStatusEventRepository events;
    @Autowired private StoreRepository stores;
    @Autowired private StoreInventoryRepository inventory;
    @Autowired private ItemRepository items;
    @Autowired private VendorRepository vendors;
    @Autowired private DeliveryPartnerRepository partners;
    @Autowired private DeliveryNetworkService network;

    private final OrderQueue queue = new OrderQueue();

    public record LineReq(Long itemId, String itemName, String storeName, Integer qty) {}
    public record PlaceReq(String customerName, String phone, String address, Double lat, Double lng, List<LineReq> lines) {}
    public record LineView(String itemName, int qty, BigDecimal price) {}
    public record EventView(String status, String note, LocalDateTime at) {}
    public record OrderView(Long orderId, String status, String storeName, String customerName, String customerPhone,
                            String address, BigDecimal total, LocalDateTime createdAt, List<LineView> lines,
                            String partnerName, String partnerPhone, Boolean partnerAccepted,
                            Double pickupKm, Double routeKm, String routePath, Integer etaMin, List<EventView> history,
                            Double storeLat, Double storeLng, Double custLat, Double custLng,
                            Double partnerLat, Double partnerLng) {}

    private static final Set<OrderStatus> ACTIVE_BEFORE_PICKUP = EnumSet.of(OrderStatus.CONFIRMED, OrderStatus.PREPARING, OrderStatus.READY);

    // ───────────────────────── place order ─────────────────────────
    public List<OrderView> placeOrder(PlaceReq r) {
        String name = Validation.need(r.customerName(), "Name");
        String phone = Validation.phone(r.phone());
        String address = Validation.need(r.address(), "Address");
        if (address.length() < 5) throw new IllegalArgumentException("Please enter a full delivery address");
        if (address.length() > 255) throw new IllegalArgumentException("Address is too long (max 255 characters)");
        Validation.location(r.lat(), r.lng());
        if (r.lines() == null || r.lines().isEmpty()) throw new IllegalArgumentException("Cart is empty");

        Map<String, List<LineReq>> byStore = new LinkedHashMap<>();
        for (LineReq l : r.lines()) byStore.computeIfAbsent(l.storeName(), k -> new ArrayList<>()).add(l);

        // pass 1: validate every store/line first so a bad line never leaves a half-placed cart
        record Plan(Store store, Collection<OrderLine> lines) {}
        List<Plan> plans = new ArrayList<>();
        for (Map.Entry<String, List<LineReq>> e : byStore.entrySet()) {
            Store store = stores.findFirstByName(e.getKey()).filter(s -> Boolean.TRUE.equals(s.getIsActive()))
                    .orElseThrow(() -> new IllegalArgumentException("Unknown store: " + e.getKey()));
            Map<Long, OrderLine> merged = new LinkedHashMap<>();
            for (LineReq l : e.getValue()) {
                if (l.qty() == null || l.qty() < 1) throw new IllegalArgumentException("Quantity must be at least 1");
                Item item = resolveItem(l);
                StoreInventory inv = inventory.findById(new StoreInventory.StoreInventoryId(store.getStoreId(), item.getItemId()))
                        .orElseThrow(() -> new IllegalArgumentException(item.getName() + " is not sold by " + store.getName()));
                OrderLine ol = merged.computeIfAbsent(item.getItemId(), id -> {
                    OrderLine x = new OrderLine();
                    x.itemId = id; x.itemName = item.getName(); x.quantity = 0; x.price = inv.getPrice();
                    return x;
                });
                ol.quantity += l.qty();
                if (inv.getStockQty() < ol.quantity)
                    throw new IllegalArgumentException("Only " + inv.getStockQty() + " left of " + item.getName() + " at " + store.getName());
            }
            plans.add(new Plan(store, merged.values()));
        }

        // pass 2: save one order per store and put it on the queue
        List<OrderView> out = new ArrayList<>();
        for (Plan p : plans) {
            CustomerOrder o = new CustomerOrder();
            o.customerName = name; o.customerPhone = phone; o.address = address;
            o.latitude = r.lat(); o.longitude = r.lng();
            o.storeId = p.store().getStoreId(); o.storeName = p.store().getName();
            o.total = p.lines().stream().map(l -> l.price.multiply(BigDecimal.valueOf(l.quantity))).reduce(BigDecimal.ZERO, BigDecimal::add);
            orders.save(o);
            for (OrderLine l : p.lines()) { l.orderId = o.orderId; lines.save(l); }
            events.save(new OrderStatusEvent(o.orderId, OrderStatus.PLACED, "Order placed"));
            queue.enqueue(o.orderId);
            out.add(view(o));
        }
        return out;
    }

    private Item resolveItem(LineReq l) {
        if (l.itemId() != null) return items.findById(l.itemId()).orElseThrow(() -> new IllegalArgumentException("Unknown product"));
        return items.findFirstByNormalizedName(Item.normalize(l.itemName()))
                .orElseThrow(() -> new IllegalArgumentException("Unknown product: " + l.itemName()));
    }

    // ───────────────────────── queue processing ─────────────────────────
    @EventListener(ApplicationReadyEvent.class)
    public void restoreQueue() {                                    // rebuild the in-memory queue after a restart
        orders.findByStatusOrderByCreatedAtAsc(OrderStatus.PLACED).forEach(o -> queue.enqueue(o.orderId));
        orders.findByPartnerIdIsNullAndStatusIn(ACTIVE_BEFORE_PICKUP).forEach(o -> queue.enqueue(o.orderId));
    }

    @Scheduled(fixedDelay = 3000)
    public synchronized void processQueue() {
        int n = queue.size();                                       // each order gets one attempt per tick
        for (int i = 0; i < n; i++) {
            Long id = queue.dequeue();
            if (id == null) return;
            boolean finished;
            try { finished = processOne(id); }
            catch (Exception ex) { ex.printStackTrace(); finished = false; }
            if (!finished) queue.enqueue(id);                       // no partner free yet -> back of the line
        }
    }

    /** @return true when the order needs no more queue time. */
    private boolean processOne(Long id) {
        CustomerOrder o = orders.findById(id).orElse(null);
        if (o == null) return true;
        boolean fresh = o.status == OrderStatus.PLACED;
        boolean needsPartner = ACTIVE_BEFORE_PICKUP.contains(o.status) && o.partnerId == null;
        if (!fresh && !needsPartner) return true;

        List<OrderLine> ls = lines.findByOrderId(id);
        List<StoreInventory> invs = new ArrayList<>();
        if (fresh) {                                                // stock check before touching anything
            for (OrderLine l : ls) {
                StoreInventory inv = inventory.findById(new StoreInventory.StoreInventoryId(o.storeId, l.itemId)).orElse(null);
                if (inv == null || inv.getStockQty() < l.quantity) { cancel(o, "Out of stock: " + l.itemName); return true; }
                invs.add(inv);
            }
        }

        Set<Long> declined = declinedSet(o);
        Optional<DeliveryNetworkService.Assignment> a = network.assignNearest(o, declined);
        if (a.isEmpty()) {
            if (!declined.isEmpty()) { o.declinedPartners = ""; orders.save(o); }   // let everyone be considered again
            return false;
        }

        if (fresh) for (int i = 0; i < ls.size(); i++) {
            StoreInventory inv = invs.get(i);
            inv.setStockQty(inv.getStockQty() - ls.get(i).quantity);
            inventory.save(inv);
        }
        DeliveryPartner p = a.get().partner();
        p.busy = true;
        partners.save(p);
        o.partnerId = p.partnerId;
        o.partnerAccepted = false;
        o.pickupKm = round(a.get().pickupKm());
        o.routeKm = round(a.get().routeKm());
        o.routePath = a.get().routePath();
        if (fresh) {
            setStatus(o, OrderStatus.CONFIRMED, "Confirmed. " + p.name + " is your nearest delivery partner");
            if (vendors.findByStoreId(o.storeId).isEmpty()) setStatus(o, OrderStatus.READY, "Packed (store without a vendor account)");
        } else {
            orders.save(o);
        }
        return true;
    }

    private static double round(double v) { return Math.round(v * 100.0) / 100.0; }

    private Set<Long> declinedSet(CustomerOrder o) {
        Set<Long> s = new HashSet<>();
        if (o.declinedPartners != null && !o.declinedPartners.isBlank())
            for (String x : o.declinedPartners.split(",")) s.add(Long.valueOf(x));
        return s;
    }

    // ───────────────────────── status changes (stack) ─────────────────────────
    private void setStatus(CustomerOrder o, OrderStatus s, String note) {
        o.status = s;
        orders.save(o);
        events.save(new OrderStatusEvent(o.orderId, s, note));
    }

    private void freePartner(Long partnerId) {
        if (partnerId == null) return;
        partners.findById(partnerId).ifPresent(p -> { p.busy = false; partners.save(p); });
    }

    private void cancel(CustomerOrder o, String reason) {
        if (o.status != OrderStatus.PLACED)                         // stock is only reserved once CONFIRMED
            for (OrderLine l : lines.findByOrderId(o.orderId))
                inventory.findById(new StoreInventory.StoreInventoryId(o.storeId, l.itemId)).ifPresent(inv -> {
                    inv.setStockQty(inv.getStockQty() + l.quantity);
                    inventory.save(inv);
                });
        freePartner(o.partnerId);
        o.partnerId = null;
        queue.remove(o.orderId);
        setStatus(o, OrderStatus.CANCELLED, reason);
    }

    private void undoLast(CustomerOrder o) {
        StatusStack<OrderStatusEvent> stack = new StatusStack<>();
        for (OrderStatusEvent e : events.findByOrderIdOrderByEventIdAsc(o.orderId)) stack.push(e);
        events.delete(stack.pop());                                 // pop the newest status change
        o.status = stack.peek().status;                             // the one below becomes current
        orders.save(o);
    }

    private CustomerOrder load(Long orderId) {
        return orders.findById(orderId).orElseThrow(() -> new IllegalArgumentException("Order not found"));
    }

    private static void expect(boolean ok, String msg) { if (!ok) throw new IllegalArgumentException(msg); }

    /** Vendor actions: PREPARING, READY, CANCELLED, UNDO. */
    public synchronized OrderView vendorAction(Long storeId, Long orderId, String action) {
        CustomerOrder o = load(orderId);
        if (!o.storeId.equals(storeId)) throw new ResponseStatusException(HttpStatus.FORBIDDEN, "Not your order");
        switch (action == null ? "" : action.toUpperCase()) {
            case "PREPARING" -> { expect(o.status == OrderStatus.CONFIRMED, "Order must be CONFIRMED"); setStatus(o, OrderStatus.PREPARING, "Store is preparing your order"); }
            case "READY" -> { expect(o.status == OrderStatus.PREPARING, "Order must be PREPARING"); setStatus(o, OrderStatus.READY, "Order packed and ready for pickup"); }
            case "CANCELLED" -> { expect(o.status == OrderStatus.CONFIRMED || o.status == OrderStatus.PREPARING, "Too late to cancel"); cancel(o, "Cancelled by store"); }
            case "UNDO" -> { expect(o.status == OrderStatus.PREPARING || o.status == OrderStatus.READY, "Nothing to undo"); undoLast(o); }
            default -> throw new IllegalArgumentException("Unknown action: " + action);
        }
        return view(o);
    }

    /** Delivery-partner actions: accept, decline, pickup, deliver. */
    public synchronized OrderView partnerAction(Long partnerId, Long orderId, String action) {
        CustomerOrder o = load(orderId);
        if (!partnerId.equals(o.partnerId)) throw new ResponseStatusException(HttpStatus.FORBIDDEN, "Not your delivery");
        switch (action == null ? "" : action.toLowerCase()) {
            case "accept" -> {
                expect(ACTIVE_BEFORE_PICKUP.contains(o.status) && !o.partnerAccepted, "Cannot accept this delivery");
                o.partnerAccepted = true;
                orders.save(o);
            }
            case "decline" -> {
                expect(ACTIVE_BEFORE_PICKUP.contains(o.status) && !o.partnerAccepted, "Cannot decline after accepting");
                o.declinedPartners = (o.declinedPartners == null || o.declinedPartners.isBlank() ? "" : o.declinedPartners + ",") + partnerId;
                freePartner(partnerId);
                o.partnerId = null;
                orders.save(o);
                queue.enqueue(o.orderId);                           // back on the queue for the next-nearest partner
            }
            case "pickup" -> {
                expect(o.partnerAccepted && o.status == OrderStatus.READY, "Order is not ready for pickup yet");
                setStatus(o, OrderStatus.PICKED_UP, "Picked up by " + partners.findById(partnerId).map(p -> p.name).orElse("partner"));
            }
            case "deliver" -> {
                expect(o.status == OrderStatus.PICKED_UP, "Pick the order up first");
                setStatus(o, OrderStatus.DELIVERED, "Delivered");
                partners.findById(partnerId).ifPresent(p -> {
                    p.busy = false; p.latitude = o.latitude; p.longitude = o.longitude;   // rider is now at the customer's area
                    partners.save(p);
                });
            }
            default -> throw new IllegalArgumentException("Unknown action: " + action);
        }
        return view(o);
    }

    // ───────────────────────── read side ─────────────────────────
    public List<OrderView> track(String phone) {
        return orders.findByCustomerPhoneOrderByCreatedAtDesc(Validation.phone(phone)).stream().map(this::view).toList();
    }
    public List<OrderView> forStore(Long storeId) { return orders.findByStoreIdOrderByCreatedAtDesc(storeId).stream().map(this::view).toList(); }
    public List<OrderView> forPartner(Long partnerId) { return orders.findByPartnerIdOrderByCreatedAtDesc(partnerId).stream().map(this::view).toList(); }
    public List<OrderView> queued() {
        return queue.snapshot().stream().map(orders::findById).flatMap(Optional::stream).map(this::view).toList();
    }

    public List<EventView> history(Long orderId) {
        StatusStack<OrderStatusEvent> stack = new StatusStack<>();
        for (OrderStatusEvent e : events.findByOrderIdOrderByEventIdAsc(orderId)) stack.push(e);
        return stack.topFirst().stream().map(e -> new EventView(e.status.name(), e.note, e.at)).toList();   // newest first
    }

    public OrderView view(CustomerOrder o) {
        List<LineView> ls = lines.findByOrderId(o.orderId).stream().map(l -> new LineView(l.itemName, l.quantity, l.price)).toList();
        String pName = null, pPhone = null;
        Double pLat = null, pLng = null;
        if (o.partnerId != null) {
            DeliveryPartner p = partners.findById(o.partnerId).orElse(null);
            if (p != null) { pName = p.name; pPhone = p.phone; pLat = p.latitude; pLng = p.longitude; }
        }
        Store st = o.storeId == null ? null : stores.findById(o.storeId).orElse(null);
        boolean live = o.status != OrderStatus.DELIVERED && o.status != OrderStatus.CANCELLED;
        Integer eta = (live && o.pickupKm != null && o.routeKm != null) ? 5 + (int) Math.round((o.pickupKm + o.routeKm) / 0.4) : null;  // ~24 km/h
        return new OrderView(o.orderId, o.status.name(), o.storeName, o.customerName, o.customerPhone, o.address, o.total,
                o.createdAt, ls, pName, pPhone, o.partnerAccepted, o.pickupKm, o.routeKm, o.routePath, eta, history(o.orderId),
                st == null ? null : st.getLatitude(), st == null ? null : st.getLongitude(), o.latitude, o.longitude, pLat, pLng);
    }
}
