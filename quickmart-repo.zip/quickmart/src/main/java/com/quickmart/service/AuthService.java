package com.quickmart.service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.HexFormat;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/** Minimal token auth for vendor / delivery-partner / admin portals (in-memory sessions). */
@Service
public class AuthService {
    private record Session(String role, Long id) {}

    private final Map<String, Session> sessions = new ConcurrentHashMap<>();

    @Value("${quickmart.admin.key}")
    private String adminKey;

    public static String hashPin(String phone, String pin) {
        try {
            byte[] d = MessageDigest.getInstance("SHA-256").digest((phone + ":" + pin).getBytes(StandardCharsets.UTF_8));
            return HexFormat.of().formatHex(d);
        } catch (Exception e) { throw new IllegalStateException(e); }
    }

    public String startSession(String role, Long id) {
        String token = UUID.randomUUID().toString();
        sessions.put(token, new Session(role, id));
        return token;
    }

    public String adminLogin(String key) {
        if (key == null || !key.equals(adminKey)) throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Wrong admin key");
        return startSession("ADMIN", 0L);
    }

    /** Returns the logged-in id for the role, or throws 401. */
    public Long require(String token, String role) {
        Session s = token == null ? null : sessions.get(token);
        if (s == null || !s.role().equals(role)) throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Please log in again");
        return s.id();
    }
}
