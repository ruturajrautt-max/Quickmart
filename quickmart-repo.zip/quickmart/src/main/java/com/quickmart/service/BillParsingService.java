package com.quickmart.service;

import com.quickmart.model.Item;
import com.quickmart.ocr.BillTextParser;
import com.quickmart.repository.ItemRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Bill/receipt OCR pipeline (used by the customer "Scan Bill" reorder and the vendor "add stock from bill" screens).
 *
 * Step 1: image -> clean-up (grayscale, upscale, contrast) -> Tesseract text         (BillOcrService, ocr/ImagePreprocessor)
 * Step 2: text -> rows (name, qty, rate, amount); a row is "verified" when qty x rate = amount
 *         holds, which also tells us which number on the line is the quantity     (ocr/BillTextParser)
 * Step 3: fuzzy-match each row's name to the Items table: word-set overlap with per-word Levenshtein
 *         edit distance (DP, O(n*m)) to absorb OCR typos, plus a pack-size check.   (this class)
 */
@Service
public class BillParsingService {

    @Autowired private ItemRepository itemRepository;
    @Autowired private BillOcrService ocr;

    public static final double MIN_CONFIDENCE = 60.0;

    public static class ParsedLine {
        public String rawName;
        public int quantity;
        public BigDecimal price;          // unit price printed on the bill (may be null if unreadable)
        public BigDecimal amount;         // line total printed on the bill
        public boolean needsReview;       // qty x rate != amount: OCR may have damaged a digit, ask the user to check
        public boolean sizeMismatch;      // same product name but a different pack size than the catalog item
        public Item matchedItem;          // null if no good match found
        public double matchConfidence;    // 0-100

        public ParsedLine(String rawName, int quantity, BigDecimal price) {
            this.rawName = rawName;
            this.quantity = quantity;
            this.price = price;
        }
    }

    public static class ScanResult {
        public String billHash;           // SHA-256 of the uploaded file: stops the same bill being added to stock twice
        public List<ParsedLine> lines = new ArrayList<>();
        public List<String> unreadable = new ArrayList<>();   // text lines that looked like products but had no usable numbers
    }

    /** Whole pipeline for one uploaded file. */
    public ScanResult scan(byte[] data, String filename) {
        BillOcrService.Output out = ocr.read(data, filename);
        ScanResult r = new ScanResult();
        r.billHash = sha256(data);
        r.lines = toLines(out.parsed);
        r.unreadable = out.parsed.unreadable;
        matchItems(r.lines, MIN_CONFIDENCE);
        return r;
    }

    /** Parses raw OCR text into structured lines (kept for callers that already have the text). */
    public List<ParsedLine> parseLines(String ocrText) {
        return toLines(BillTextParser.parse(ocrText));
    }

    private static List<ParsedLine> toLines(BillTextParser.Result parsed) {
        List<ParsedLine> lines = new ArrayList<>();
        for (BillTextParser.Line l : parsed.items) {
            ParsedLine p = new ParsedLine(l.name, (int) Math.max(1, Math.round(l.qty)), l.rate);
            p.amount = l.amount;
            p.needsReview = !l.verified;
            lines.add(p);
        }
        return lines;
    }

    /**
     * Fuzzy-matches each parsed line's item name to the closest entry in the Items table.
     * Sets matchedItem, matchConfidence and sizeMismatch on each line in place.
     */
    public void matchItems(List<ParsedLine> parsedLines, double minConfidence) {
        List<Item> allItems = itemRepository.findAll(); // fine for a catalog of a few thousand;
        // for a much larger catalog, pre-bucket by first letter or category to cut comparisons.

        for (ParsedLine line : parsedLines) {
            String normalized = Item.normalize(line.rawName);
            String billSize = sizeOf(normalized);

            Item best = null;
            double bestScore = -1;
            boolean bestSizeMismatch = false;

            for (Item item : allItems) {
                double score = similarity(normalized, item.getNormalizedName());
                boolean mismatch = false;
                String itemSize = sizeOf(Item.normalize(item.getUnitSize()) + " " + item.getNormalizedName());
                if (billSize != null && itemSize != null) {
                    if (billSize.equals(itemSize)) score = Math.min(1.0, score + 0.05);   // same pack size: prefer this variant
                    else { score *= 0.85; mismatch = true; }                               // same words, different pack: lower rank
                }
                if (score > bestScore) {
                    bestScore = score;
                    best = item;
                    bestSizeMismatch = mismatch;
                }
            }

            line.matchConfidence = Math.max(0, bestScore) * 100;
            if (best != null && line.matchConfidence >= minConfidence) {
                line.matchedItem = best;
                line.sizeMismatch = bestSizeMismatch;
            } else {
                line.matchedItem = null;
                line.sizeMismatch = false;
            }
        }
    }

    // ───────────────────────── matching helpers ─────────────────────────

    private static final Pattern SIZE = Pattern.compile(
            "(\\d+(?:\\.\\d+)?)\\s*(kgs?|gms?|grams?|g|mg|ltrs?|litres?|liters?|l|ml)\\b");

    /** Canonical pack size ("g:1000", "ml:500") or null if the text has none. 1 kg == 1000 g, 1 L == 1000 ml. */
    static String sizeOf(String text) {
        Matcher m = SIZE.matcher(text.toLowerCase(Locale.ROOT));
        if (!m.find()) return null;
        double v = Double.parseDouble(m.group(1));
        String u = m.group(2);
        if (u.startsWith("kg"))  return "g:" + Math.round(v * 1000);
        if (u.equals("mg"))      return "g:" + Math.round(v / 1000);
        if (u.startsWith("g"))   return "g:" + Math.round(v);
        if (u.equals("ml"))      return "ml:" + Math.round(v);
        return "ml:" + Math.round(v * 1000);                       // l / ltr / litre
    }

    /** Lower-case alphabetic words only; drops sizes like 1kg / 400g / 1l and punctuation. */
    private static Set<String> tokens(String s) {
        Set<String> t = new HashSet<>();
        for (String w : s.toLowerCase().split("[^a-z0-9]+")) {
            if (w.length() >= 2 && w.matches("[a-z]+")) t.add(w);
        }
        return t;
    }

    /** Words match if equal, or (for words of 4+ letters) within 1 edit, to absorb OCR typos. */
    private boolean tokenEq(String a, String b) {
        return a.equals(b) || (a.length() >= 4 && b.length() >= 4 && levenshtein(a, b) <= 1);
    }

    /**
     * Similarity in [0,1] between a bill line and a catalog name.
     * Whole-string Levenshtein fails when lengths differ a lot ("TATA TOOR DAL 1KG" vs
     * "Tata Sampann Unpolished Toor Dal" = 28%), so compare word sets instead and use
     * per-word edit distance only for OCR typos.
     */
    private double similarity(String bill, String catalog) {
        Set<String> a = tokens(bill), b = tokens(catalog);
        if (a.isEmpty() || b.isEmpty()) return 0;
        int matched = 0;
        for (String x : a) {
            for (String y : b) {
                if (tokenEq(x, y)) { matched++; break; }
            }
        }
        double coverage = (double) matched / a.size(); // how much of the bill text is explained
        double tidy = (double) matched / b.size();     // tie-break: prefer the tighter catalog name
        return 0.8 * coverage + 0.2 * tidy;
    }

    /** Classic DP edit distance, O(n*m) time and space. */
    private int levenshtein(String a, String b) {
        int n = a.length(), m = b.length();
        int[][] dp = new int[n + 1][m + 1];

        for (int i = 0; i <= n; i++) dp[i][0] = i;
        for (int j = 0; j <= m; j++) dp[0][j] = j;

        for (int i = 1; i <= n; i++) {
            for (int j = 1; j <= m; j++) {
                if (a.charAt(i - 1) == b.charAt(j - 1)) {
                    dp[i][j] = dp[i - 1][j - 1];
                } else {
                    dp[i][j] = 1 + Math.min(dp[i - 1][j - 1], Math.min(dp[i - 1][j], dp[i][j - 1]));
                }
            }
        }
        return dp[n][m];
    }

    private static String sha256(byte[] data) {
        try {
            return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(data));
        } catch (Exception e) {
            return UUID.nameUUIDFromBytes(data).toString().replace("-", "");
        }
    }
}
