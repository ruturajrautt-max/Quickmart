package com.quickmart.service;

import com.quickmart.dsa.Trie;
import com.quickmart.model.Item;
import com.quickmart.repository.ItemRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;

/** Product autocomplete backed by a Trie that is built from the items table and kept in sync. */
@Service
public class SearchService {
    @Autowired
    private ItemRepository itemRepository;

    private final Trie trie = new Trie();
    private final Map<Long, Item> byId = new HashMap<>();
    private boolean built = false;

    private synchronized void ensureBuilt() {
        if (built) return;
        trie.clear();
        byId.clear();
        for (Item item : itemRepository.findAll()) index(item);
        built = true;
    }

    /** Called by vendors when they create a new product, so it is searchable immediately. */
    public synchronized void index(Item item) {
        byId.put(item.getItemId(), item);
        for (String word : Item.normalize(item.getName()).split("[^a-z0-9]+")) {
            if (!word.isEmpty()) trie.insert(word, item.getItemId());
        }
    }

    public synchronized List<Item> suggest(String query, int limit) {
        ensureBuilt();
        String q = Item.normalize(query);
        if (q.isEmpty()) return List.of();
        // the Trie matches on the first typed word; extra words narrow the result by substring
        String[] parts = q.split(" ", 2);
        List<Item> out = new ArrayList<>();
        for (Long id : trie.withPrefix(parts[0], limit * 5)) {
            Item item = byId.get(id);
            if (item != null && (parts.length == 1 || item.getNormalizedName().contains(parts[1]))) out.add(item);
        }
        // names that START with the query rank above names that merely contain a matching word
        out.sort(Comparator.comparing((Item i) -> !i.getNormalizedName().startsWith(q)).thenComparing(Item::getName));
        return out.size() > limit ? out.subList(0, limit) : out;
    }
}
