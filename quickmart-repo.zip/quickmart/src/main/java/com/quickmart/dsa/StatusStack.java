package com.quickmart.dsa;

import java.util.*;

/**
 * LIFO stack of an order's status changes. push = new status, peek = current status,
 * pop = undo the last status change, listing top-first = history, newest event first.
 */
public class StatusStack<T> {
    private final Deque<T> stack = new ArrayDeque<>();

    public void push(T item) { stack.push(item); }
    public T pop() { return stack.pop(); }
    public T peek() { return stack.peek(); }
    public int size() { return stack.size(); }
    public boolean isEmpty() { return stack.isEmpty(); }
    public List<T> topFirst() { return new ArrayList<>(stack); }  // ArrayDeque iterates top -> bottom
}
