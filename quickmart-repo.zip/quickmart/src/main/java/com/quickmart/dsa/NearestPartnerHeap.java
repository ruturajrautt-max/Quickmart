package com.quickmart.dsa;

import java.util.*;

/**
 * Min-heap (PriorityQueue) of available delivery partners keyed by road distance to the store.
 * poll() returns the nearest partner in O(log n); the rest stay ordered as fall-backs.
 */
public class NearestPartnerHeap {
    public record Candidate(Long partnerId, double km) {}

    private final PriorityQueue<Candidate> heap = new PriorityQueue<>(Comparator.comparingDouble(Candidate::km));

    public void add(Long partnerId, double km) { heap.offer(new Candidate(partnerId, km)); }
    public Candidate pollNearest() { return heap.poll(); }
    public boolean isEmpty() { return heap.isEmpty(); }
}
