package com.quickmart.dsa;

import java.util.*;

/**
 * Weighted graph of the delivery network (adjacency list). Nodes = stores, the customer and
 * delivery partners; edge weight = road km. Dijkstra (min-heap) gives shortest distances/routes.
 * Partners are "leaf" nodes (edges point INTO them only), so a route never passes through a rider.
 */
public class RoadGraph {
    public record Edge(String to, double km) {}
    public record Path(List<String> nodes, double km) {}
    private record State(String node, double dist) {}

    private static final double ROAD_FACTOR = 1.3;  // roads are ~30% longer than straight-line distance

    private final Map<String, List<Edge>> adj = new HashMap<>();
    private final Map<String, double[]> pos = new HashMap<>();
    private final Set<String> leaves = new HashSet<>();

    public void addNode(String id, double lat, double lng) {
        adj.putIfAbsent(id, new ArrayList<>());
        pos.put(id, new double[]{lat, lng});
    }

    public boolean hasNode(String id) { return adj.containsKey(id); }

    public void addEdge(String a, String b, double km) {          // undirected
        if (a.equals(b) || hasEdge(a, b)) return;
        adj.get(a).add(new Edge(b, km));
        adj.get(b).add(new Edge(a, km));
    }

    private boolean hasEdge(String a, String b) {
        for (Edge e : adj.get(a)) if (e.to().equals(b)) return true;
        return false;
    }

    public static double haversineKm(double lat1, double lng1, double lat2, double lng2) {
        double dLat = Math.toRadians(lat2 - lat1), dLng = Math.toRadians(lng2 - lng1);
        double a = Math.sin(dLat / 2) * Math.sin(dLat / 2)
                + Math.cos(Math.toRadians(lat1)) * Math.cos(Math.toRadians(lat2)) * Math.sin(dLng / 2) * Math.sin(dLng / 2);
        return 6371 * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    }

    private double roadKm(String a, String b) {
        double[] p = pos.get(a), q = pos.get(b);
        return haversineKm(p[0], p[1], q[0], q[1]) * ROAD_FACTOR;
    }

    /** Link every (non-leaf) node to its k nearest neighbours, then bridge components so the graph is connected. */
    public void connectRoads(int k) {
        List<String> ids = new ArrayList<>();
        for (String n : adj.keySet()) if (!leaves.contains(n)) ids.add(n);
        for (String a : ids) {
            ids.stream().filter(b -> !b.equals(a))
                    .sorted(Comparator.comparingDouble(b -> roadKm(a, b)))
                    .limit(k).forEach(b -> addEdge(a, b, roadKm(a, b)));
        }
        while (true) {                                         // join separate components by their closest pair
            Set<String> comp = component(ids.get(0));
            if (comp.size() == ids.size()) return;
            String bestA = null, bestB = null; double best = Double.MAX_VALUE;
            for (String a : comp) for (String b : ids) {
                if (comp.contains(b)) continue;
                double d = roadKm(a, b);
                if (d < best) { best = d; bestA = a; bestB = b; }
            }
            addEdge(bestA, bestB, best);
        }
    }

    private Set<String> component(String start) {
        Set<String> seen = new HashSet<>(List.of(start));
        Deque<String> q = new ArrayDeque<>(List.of(start));
        while (!q.isEmpty()) {
            for (Edge e : adj.get(q.poll())) {
                if (!leaves.contains(e.to()) && seen.add(e.to())) q.add(e.to());
            }
        }
        return seen;
    }

    /** Attach a partner: one-way edges from its k nearest road nodes into the partner node. */
    public void attachLeaf(String id, double lat, double lng, int k) {
        List<String> roads = new ArrayList<>();
        for (String n : adj.keySet()) if (!leaves.contains(n)) roads.add(n);
        addNode(id, lat, lng);
        leaves.add(id);
        roads.stream().sorted(Comparator.comparingDouble(n -> roadKm(n, id))).limit(k)
                .forEach(n -> adj.get(n).add(new Edge(id, roadKm(n, id))));
    }

    /** Dijkstra from src: shortest road km to every reachable node; fills prev[] to rebuild routes. */
    public Map<String, Double> dijkstra(String src, Map<String, String> prev) {
        Map<String, Double> dist = new HashMap<>();
        PriorityQueue<State> pq = new PriorityQueue<>(Comparator.comparingDouble(State::dist));
        dist.put(src, 0.0);
        pq.offer(new State(src, 0.0));
        while (!pq.isEmpty()) {
            State s = pq.poll();
            if (s.dist() > dist.getOrDefault(s.node(), Double.MAX_VALUE)) continue;   // stale heap entry
            for (Edge e : adj.getOrDefault(s.node(), List.of())) {
                double nd = s.dist() + e.km();
                if (nd < dist.getOrDefault(e.to(), Double.MAX_VALUE)) {
                    dist.put(e.to(), nd);
                    if (prev != null) prev.put(e.to(), s.node());
                    pq.offer(new State(e.to(), nd));
                }
            }
        }
        return dist;
    }

    public Path shortestPath(String src, String dst) {
        Map<String, String> prev = new HashMap<>();
        Map<String, Double> dist = dijkstra(src, prev);
        if (!dist.containsKey(dst)) return null;
        LinkedList<String> nodes = new LinkedList<>();
        for (String n = dst; n != null; n = prev.get(n)) nodes.addFirst(n);
        return new Path(nodes, dist.get(dst));
    }
}
