package com.quickmart.dsa;

import java.util.*;

/** FIFO queue of order ids waiting to be processed (oldest order is served first). */
public class OrderQueue {
    private final Deque<Long> q = new ArrayDeque<>();

    public synchronized void enqueue(Long id) { if (!q.contains(id)) q.addLast(id); }   // O(1) add at rear
    public synchronized Long dequeue() { return q.pollFirst(); }                         // O(1) remove from front
    public synchronized Long peek() { return q.peekFirst(); }
    public synchronized boolean remove(Long id) { return q.remove(id); }
    public synchronized int size() { return q.size(); }
    public synchronized List<Long> snapshot() { return new ArrayList<>(q); }
}
