package com.quickmart.dsa;

import java.util.*;

/**
 * Prefix tree (Trie) used for product search / autocomplete.
 * Each product-name word is inserted with the product id. A prefix lookup walks L nodes
 * (L = prefix length) and then collects ids below that node: O(L + k), independent of
 * how many products exist (a LIKE '%x%' scan is O(N * name length)).
 */
public class Trie {
    private static class Node {
        final Map<Character, Node> next = new TreeMap<>();   // TreeMap -> alphabetical traversal
        final Set<Long> ids = new LinkedHashSet<>();         // products having a word ending here
    }

    private Node root = new Node();

    public synchronized void clear() { root = new Node(); }

    public synchronized void insert(String word, Long id) {
        Node cur = root;
        for (char c : word.toLowerCase().toCharArray()) cur = cur.next.computeIfAbsent(c, k -> new Node());
        cur.ids.add(id);
    }

    /** Ids of products having a word that starts with prefix (at most `limit`, alphabetical by word). */
    public synchronized List<Long> withPrefix(String prefix, int limit) {
        Node cur = root;
        for (char c : prefix.toLowerCase().toCharArray()) {
            cur = cur.next.get(c);
            if (cur == null) return List.of();
        }
        Set<Long> out = new LinkedHashSet<>();
        Deque<Node> stack = new ArrayDeque<>();
        stack.push(cur);
        while (!stack.isEmpty() && out.size() < limit) {
            Node n = stack.pop();
            for (Long id : n.ids) { if (out.size() < limit) out.add(id); }
            // push children in reverse so the alphabetically smallest is popped first
            List<Node> kids = new ArrayList<>(n.next.values());
            for (int i = kids.size() - 1; i >= 0; i--) stack.push(kids.get(i));
        }
        return new ArrayList<>(out);
    }
}
