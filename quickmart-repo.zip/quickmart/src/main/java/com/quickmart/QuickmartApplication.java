package com.quickmart;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@EnableScheduling   // runs the order-queue processor
public class QuickmartApplication {
    public static void main(String[] args) {
        SpringApplication.run(QuickmartApplication.class, args);
    }
}
