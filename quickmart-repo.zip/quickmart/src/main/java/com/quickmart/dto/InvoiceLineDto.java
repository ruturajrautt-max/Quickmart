package com.quickmart.dto;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/**
 * One invoice row. The first block is what OCR read (the vendor may edit it), the second is the vendor's decision
 * about which product it is, the third is computed by the server and ignored when the client sends it back.
 */
public class InvoiceLineDto {
    // ── read from the bill (editable) ──
    public Integer lineId;
    public String sourceText;                // the OCR line it came from
    public String name, unit, packSize, hsn;
    public BigDecimal qty, rate, discountPct, gstPct, amount;
    public Double ocrConfidence;             // 0-100, view only
    public String check;                     // EXACT | DISCOUNT | GST | DISCOUNT+GST | APPROX | REPAIRED | NONE (view only)
    public boolean arithmeticVerified;       // view only

    // ── vendor's decision ──
    public String action;                    // ADD (to an existing product) | CREATE (new product) | SKIP
    public Long itemId;
    public String newCategory, newBrand, newUnitSize;
    public BigDecimal sellingPrice;          // required when the shop has never stocked the product
    public boolean packOverride;             // vendor confirms a pack-size difference is intended

    // ── computed (view only) ──
    public String itemName, itemUnitSize, matchStatus;   // matchStatus: MATCHED | REVIEW | UNMATCHED | MANUAL
    public Double matchConfidence;                       // 0-100
    public List<SuggestionDto> suggestions = new ArrayList<>();
    public Integer currentStock;
    public Integer stockUnits;               // packs that will be added to stock
}
