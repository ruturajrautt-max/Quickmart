package com.quickmart.dto;

import java.util.ArrayList;
import java.util.List;

/** Everything the vendor screen needs about one scanned bill. */
public class InvoiceView {
    public Long billId;
    public String status;                    // EXTRACTED | CONFIRMED | FAILED
    public String fileName, fileHash, ocrEngine, createdAt, confirmedAt;
    public Double ocrConfidence;             // 0-100
    public boolean reusedExisting;           // the same file was uploaded before and its draft was reused
    public InvoiceHeaderDto header = new InvoiceHeaderDto();
    public List<InvoiceLineDto> lines = new ArrayList<>();
    public List<IssueDto> issues = new ArrayList<>();
    public List<String> unreadable = new ArrayList<>();
    public int errorCount, warningCount;
    public boolean canConfirm;               // no ERROR issues and status is EXTRACTED
}
