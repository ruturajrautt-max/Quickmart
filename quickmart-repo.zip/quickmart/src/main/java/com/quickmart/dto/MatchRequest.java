package com.quickmart.dto;

/** "Search the catalog for this": either a row of the bill (lineId) or free text typed by the vendor. */
public class MatchRequest {
    public Integer lineId;
    public String text, packSize;
}
