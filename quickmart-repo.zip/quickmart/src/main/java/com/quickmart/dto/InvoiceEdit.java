package com.quickmart.dto;

import java.util.ArrayList;
import java.util.List;

/** Body of "save edits" and "confirm": the vendor's corrected header, lines and mapping decisions. */
public class InvoiceEdit {
    public InvoiceHeaderDto header;
    public List<InvoiceLineDto> lines = new ArrayList<>();
    public boolean acknowledgeWarnings;      // confirm only: the vendor has seen the warnings and still wants to proceed
}
