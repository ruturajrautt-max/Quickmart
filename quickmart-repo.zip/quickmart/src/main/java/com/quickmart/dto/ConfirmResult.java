package com.quickmart.dto;

import java.util.ArrayList;
import java.util.List;

/** What a confirmed bill did to the vendor's inventory. */
public class ConfirmResult {
    public static class Change {
        public Long itemId;
        public String name;
        public boolean created;              // a brand-new catalog product
        public int unitsAdded;
        public Integer oldStock, newStock;
    }
    public Long billId;
    public String status;
    public int productsUpdated, productsCreated, unitsAdded;
    public String message;
    public List<Change> changes = new ArrayList<>();
}
