package com.quickmart.dto;

import java.math.BigDecimal;

/** One row of the vendor's "recent scanned bills" list. */
public class BillSummaryDto {
    public Long billId;
    public String status, fileName, supplierName, invoiceNumber, invoiceDate, createdAt, confirmedAt;
    public BigDecimal grandTotal;
    public Double ocrConfidence;
    public int lineCount;
}
