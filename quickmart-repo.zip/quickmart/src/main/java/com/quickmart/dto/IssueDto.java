package com.quickmart.dto;

/** A problem found in the extracted data. ERROR blocks confirmation; WARNING needs the vendor's acknowledgement. */
public class IssueDto {
    public static final String ERROR = "ERROR", WARNING = "WARNING", INFO = "INFO";
    public String severity, code, field, message;
    public Integer lineId;             // null for invoice-level issues

    public IssueDto() {}
    public IssueDto(String severity, String code, Integer lineId, String field, String message) {
        this.severity = severity; this.code = code; this.lineId = lineId; this.field = field; this.message = message;
    }
    public static IssueDto error(String code, Integer lineId, String field, String msg) { return new IssueDto(ERROR, code, lineId, field, msg); }
    public static IssueDto warn(String code, Integer lineId, String field, String msg) { return new IssueDto(WARNING, code, lineId, field, msg); }
    public static IssueDto info(String code, Integer lineId, String field, String msg) { return new IssueDto(INFO, code, lineId, field, msg); }
    public boolean isError() { return ERROR.equals(severity); }
    public boolean isWarning() { return WARNING.equals(severity); }
}
