package com.quickmart.dto;

import java.math.BigDecimal;

public class StorePriceResult {
    private Long storeId;
    private String storeName;
    private BigDecimal price;
    private double distanceKm;

    public StorePriceResult(Long storeId, String storeName, BigDecimal price, double distanceKm) {
        this.storeId = storeId;
        this.storeName = storeName;
        this.price = price;
        this.distanceKm = distanceKm;
    }

    public Long getStoreId() { return storeId; }
    public String getStoreName() { return storeName; }
    public BigDecimal getPrice() { return price; }
    public double getDistanceKm() { return distanceKm; }

    @Override
    public String toString() {
        return storeName + " -> ₹" + price + " (" + String.format("%.2f", distanceKm) + " km)";
    }
}
