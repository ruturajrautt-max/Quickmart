package com.quickmart.dto;

/** One possible catalog product for a bill line. */
public class SuggestionDto {
    public Long itemId;
    public String name, unitSize, category, brand;
    public double confidence;          // 0-100
    public String pack;                // MATCH | MISMATCH | UNKNOWN
    public String reason;              // human readable, e.g. "different pack size (500 g vs 1 kg)"
    public Integer currentStock;       // this shop's stock, null if never stocked
}
