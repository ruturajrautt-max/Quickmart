package com.quickmart.dto;

import java.math.BigDecimal;

/** Invoice-level fields, as shown to and edited by the vendor. Dates are ISO strings (yyyy-MM-dd). */
public class InvoiceHeaderDto {
    public String supplierName, invoiceNumber, invoiceDate, gstin;
    public Boolean gstinChecksumValid;                       // view only
    public BigDecimal subtotal, discountTotal, cgst, sgst, igst, cess, taxTotal, roundOff, grandTotal;
    public BigDecimal cgstRate, sgstRate, igstRate;
    public java.util.List<String> notes = new java.util.ArrayList<>();   // view only: reading remarks
}
