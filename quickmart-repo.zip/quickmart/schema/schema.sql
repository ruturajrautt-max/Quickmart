-- ============================================================
-- QuickMart DB Schema
-- ============================================================

CREATE TABLE users (
    user_id       BIGINT AUTO_INCREMENT PRIMARY KEY,
    name          VARCHAR(100) NOT NULL,
    phone         VARCHAR(15) UNIQUE NOT NULL,
    latitude      DOUBLE,
    longitude     DOUBLE,
    created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE stores (
    store_id      BIGINT AUTO_INCREMENT PRIMARY KEY,
    name          VARCHAR(150) NOT NULL,
    latitude      DOUBLE NOT NULL,
    longitude     DOUBLE NOT NULL,
    address       VARCHAR(255),
    is_active     BOOLEAN DEFAULT TRUE
);

CREATE TABLE items (
    item_id       BIGINT AUTO_INCREMENT PRIMARY KEY,
    name          VARCHAR(150) NOT NULL,
    normalized_name VARCHAR(150) NOT NULL,   -- lowercase, trimmed, used for fuzzy match/Trie
    category      VARCHAR(80),
    brand         VARCHAR(80),
    unit_size     VARCHAR(30)                -- e.g. "1kg", "500ml"
);

-- Per-store price + stock for each item. This is the core comparison table.
CREATE TABLE store_inventory (
    store_id      BIGINT NOT NULL,
    item_id       BIGINT NOT NULL,
    price         DECIMAL(10,2) NOT NULL,
    stock_qty     INT NOT NULL DEFAULT 0,
    expiry_date   DATE,                      -- nullable, used for FIFO/expiry-priority module
    updated_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (store_id, item_id),
    FOREIGN KEY (store_id) REFERENCES stores(store_id),
    FOREIGN KEY (item_id) REFERENCES items(item_id)
);

CREATE TABLE orders (
    order_id      BIGINT AUTO_INCREMENT PRIMARY KEY,
    user_id       BIGINT NOT NULL,
    store_id      BIGINT NOT NULL,
    status        VARCHAR(30) DEFAULT 'PLACED',   -- PLACED, ASSIGNED, OUT_FOR_DELIVERY, DELIVERED
    is_express    BOOLEAN DEFAULT FALSE,           -- feeds priority-queue fulfillment
    total_amount  DECIMAL(10,2),
    placed_at     TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id),
    FOREIGN KEY (store_id) REFERENCES stores(store_id)
);

CREATE TABLE order_items (
    order_id      BIGINT NOT NULL,
    item_id       BIGINT NOT NULL,
    quantity      INT NOT NULL,
    price_at_order DECIMAL(10,2) NOT NULL,
    PRIMARY KEY (order_id, item_id),
    FOREIGN KEY (order_id) REFERENCES orders(order_id),
    FOREIGN KEY (item_id) REFERENCES items(item_id)
);

-- Purchase history log — separate from order_items so bill-scanned purchases
-- (which may not go through the app's own checkout) can feed it too.
CREATE TABLE purchase_history (
    purchase_id   BIGINT AUTO_INCREMENT PRIMARY KEY,
    user_id       BIGINT NOT NULL,
    store_id      BIGINT NOT NULL,
    item_id       BIGINT NOT NULL,
    quantity      INT NOT NULL,
    price         DECIMAL(10,2) NOT NULL,
    source        VARCHAR(20) DEFAULT 'ORDER',   -- 'ORDER' or 'BILL_SCAN'
    purchased_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id),
    FOREIGN KEY (store_id) REFERENCES stores(store_id),
    FOREIGN KEY (item_id) REFERENCES items(item_id)
);

CREATE TABLE riders (
    rider_id      BIGINT AUTO_INCREMENT PRIMARY KEY,
    name          VARCHAR(100),
    latitude      DOUBLE,
    longitude     DOUBLE,
    is_available  BOOLEAN DEFAULT TRUE
);

CREATE TABLE deliveries (
    delivery_id   BIGINT AUTO_INCREMENT PRIMARY KEY,
    order_id      BIGINT NOT NULL,
    rider_id      BIGINT,
    eta_minutes   INT,
    status        VARCHAR(30) DEFAULT 'PENDING',
    FOREIGN KEY (order_id) REFERENCES orders(order_id),
    FOREIGN KEY (rider_id) REFERENCES riders(rider_id)
);

-- Raw bill uploads + parsed line items (OCR module)
CREATE TABLE bills (
    bill_id       BIGINT AUTO_INCREMENT PRIMARY KEY,
    user_id       BIGINT NOT NULL,
    store_id      BIGINT,                     -- nullable, may be unresolved until parsed
    raw_ocr_text  TEXT,
    upload_date   TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    status        VARCHAR(20) DEFAULT 'PENDING', -- PENDING, PARSED, FAILED
    FOREIGN KEY (user_id) REFERENCES users(user_id),
    FOREIGN KEY (store_id) REFERENCES stores(store_id)
);

CREATE TABLE bill_items (
    bill_item_id      BIGINT AUTO_INCREMENT PRIMARY KEY,
    bill_id           BIGINT NOT NULL,
    parsed_name       VARCHAR(150),           -- raw text as OCR read it
    matched_item_id   BIGINT,                 -- nullable, filled after fuzzy match
    match_confidence  DECIMAL(5,2),           -- 0-100, similarity score
    quantity          INT,
    price             DECIMAL(10,2),
    FOREIGN KEY (bill_id) REFERENCES bills(bill_id),
    FOREIGN KEY (matched_item_id) REFERENCES items(item_id)
);

-- Indexes for the query patterns you'll actually run
CREATE INDEX idx_inventory_item ON store_inventory(item_id);
CREATE INDEX idx_purchase_user_store ON purchase_history(user_id, store_id);
CREATE INDEX idx_items_normalized ON items(normalized_name);
