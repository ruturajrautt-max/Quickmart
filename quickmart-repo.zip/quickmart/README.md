# QuickMart — DSA project skeleton

## What's built so far
- `schema/schema.sql` — full DB schema (users, stores, items, inventory, orders, purchase history, bills)
- Spring Boot + JPA skeleton (`pom.xml`, entities, repositories)
- **Price comparison** (`PriceComparisonService`) — bounded max-heap, top-k cheapest stores, O(n log k)
- **Cart optimization** (`CartOptimizationService`) — split cart across ≤2 stores, bitmask combos + greedy per-item assignment
- **Frequently bought** (`FrequentlyBoughtService`) — HashMap count + min-heap top-N, O(m log N)
- **Bill OCR parsing** (`BillParsingService`) — Tesseract text extraction, regex line parsing, Levenshtein fuzzy matching to catalog items
- REST controllers for price comparison (`/api/price/compare`) and bill upload (`/api/bills/upload`)

## Not built yet (next up)
- Store locator (k-NN / geo search) — `distanceTo()` exists on `Store` but no ranking endpoint yet
- Trie-based search/autocomplete
- Substitute item suggestions (graph traversal)
- Delivery ETA (Dijkstra/A*) and rider assignment
- Order fulfillment priority queue (express vs scheduled)
- Expiry-based FIFO stock sorting
- Frontend (nothing yet — backend/API first)

## Running it
1. Install MySQL, create a `quickmart` database, run `schema/schema.sql`
2. Copy `src/main/resources/application-local.properties.example` to `application-local.properties` (git-ignored) and fill in your MySQL password and an admin key. Or set the environment variables `DB_USERNAME`, `DB_PASSWORD`, `QUICKMART_ADMIN_KEY`
3. Install Tesseract OCR (Windows: UB-Mannheim installer, Ubuntu: `sudo apt install tesseract-ocr`, macOS: `brew install tesseract`). The tessdata folder is auto-detected; override with `tesseract.datapath` in `application.properties` if needed. Then open `http://localhost:8080/api/bills/health` - it must say `"ok": true`
4. `mvn spring-boot:run`

Couldn't run `mvn` here since this sandbox only has npm/pip registries whitelisted, not Maven Central — you'll need to build it locally or I can switch us to a stack I can actually compile/test in here (e.g. Node/Express) if that matters to you.

## Viva talking points already baked in
- Price comparison: why a bounded max-heap beats a full sort when you only need top-k
- Cart optimization: why we cap store-count at 2 (NP-hard set-partition otherwise) and brute-force small combos + greedy assign
- Frequently bought: HashMap aggregation + min-heap top-N instead of sorting everything
- Bill parsing: regex for line classification, DP-based Levenshtein distance for fuzzy item matching, why full catalog scan is fine for now but would need Trie/bucketing at scale

---

## Vendors, delivery partners and order flow (new)

**Pages:** `index.html` (customer: autocomplete, checkout, Track) and `portal.html` (Vendor / Delivery Partner / Admin).
New tables (`vendors`, `delivery_partners`, `customer_orders`, `order_lines`, `order_status_events`) are created automatically (`ddl-auto=update`); existing tables are untouched.

**Try it end to end**
1. `portal.html#vendor` → *Apply* (shop, area, PIN). `portal.html#partner` → *Apply* as a rider.
2. `portal.html#admin` → key from `quickmart.admin.key` (the value you set in `application-local.properties` / `QUICKMART_ADMIN_KEY`) → **Approve** both. Approving a vendor adds a row to `stores`, so the shop appears in price comparison and the delivery graph.
3. Vendor logs in → add products (price, stock). Rider logs in → *Go online* (pick area).
4. `index.html` → search, add to cart, **Place Order** (name, phone, area) → **Track**.
5. Vendor: *Start preparing → Mark ready*. Rider: *Accept → Picked up → Mark delivered*.
Stores without a vendor account (your seeded stores) auto-mark orders READY so they still work end to end.

| DSA | Where | What it does |
|---|---|---|
| Trie | `dsa/Trie`, `SearchService`, `GET /api/search/suggest` | prefix autocomplete in O(L + k); new vendor products are inserted live |
| Queue (FIFO) | `dsa/OrderQueue`, `OrderService.processQueue` | oldest order is processed first; orders wait here until a partner is free |
| Stack (LIFO) | `dsa/StatusStack`, `OrderService.history/undoLast` | push = status change, peek = current status, pop = vendor "undo last step", list = history |
| Graph | `dsa/RoadGraph`, `DeliveryNetworkService` | stores + customer + riders, edges = road km (kNN + connectivity bridging) |
| Dijkstra | `RoadGraph.dijkstra/shortestPath` | store → customer route, and store → every rider distance |
| Min-heap | `dsa/NearestPartnerHeap` | poll() = nearest available rider; decliners are excluded and the order re-queued |

Existing features (price comparison heap, cart optimisation, frequently bought, OCR bill scan) are unchanged.

**Viva line:** a new order enters the FIFO queue; the processor checks stock, runs Dijkstra from the store, pushes every free rider into a min-heap by distance and polls the nearest; each status change is pushed on a stack, so history is the stack read top-first and "undo" is a pop.

## Maps & store finder
- `static/qm-map.js` – shared Leaflet helpers (OpenStreetMap tiles, OSRM public server for road routes; falls back to a dotted straight line if OSRM is unreachable).
- Customer **Track** modal and the partner portal show: all stores 🏪, the pickup store (orange ring), customer 🏠, partner 🛵, route partner → store (dashed orange) and store → customer (green).
- **🔎 Stores** button (index.html): search by store/area or by product; shows distance, units left, and per-item stock (`GET /api/stores?q=&lat=&lng=`, `GET /api/stores/{id}/stock?q=`).
- `OrderView` now also carries `storeLat/Lng`, `custLat/Lng`, `partnerLat/Lng`.


---

## Bill scanner (rebuilt)

**Two uses of one pipeline**
- **Vendor** (`portal.html` -> Vendor -> *Scan bill -> add stock*): upload the distributor's bill (JPG/PNG/PDF). Lines are matched to the catalog and shown with *current stock -> new stock*; **Add selected to stock** ADDS the quantities (bill rate is the cost price, so selling prices are not changed; new products need a category and selling price). `POST /api/vendors/bill/scan` reads only, `POST /api/vendors/bill/apply` writes. Each bill is fingerprinted (SHA-256, table `bill_imports`) so the same bill cannot be added twice.
- **Customer** (`index.html` -> *Scan Bill*): upload an old bill; each item is matched and put in the cart from the cheapest nearby store that has enough stock (store and quantity editable per row). `POST /api/bills/reorder`.

**Pipeline** (`ocr/` package + `BillOcrService`, `BillParsingService`)
1. `ImagePreprocessor` - grayscale, upscale to ~2400 px, contrast stretch. (A hard black/white threshold made photos worse, so it is not used.)
2. `BillScanner` - if nothing parses, retries rotated 90/270/180 (sideways phone photos).
3. `BillOcrService` - Tess4J first, plain `tesseract` command as fallback; tessdata path auto-detected.
4. `BillTextParser` - **a row is verified when qty x rate = amount**; that picks the quantity out of HSN codes, sizes ("500 g"), serial numbers and GST columns. Unverified rows are flagged "check quantity".
5. `BillParsingService.matchItems` - word-set overlap + per-word Levenshtein (DP) for OCR typos + pack-size check.

**Viva line:** "OCR gives noisy text, so instead of trusting one regex we cross-check the numbers: quantity x rate must equal the amount. That is a checksum for each row, and rows that fail it are shown to the user for review instead of being silently trusted."

**Tests:** `mvn test` runs `BillTextParserTest` (layouts + real OCR output).
